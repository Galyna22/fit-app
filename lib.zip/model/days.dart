class Day {
  String dayName;
  int dayNumber;

  Day({required this.dayName, required this.dayNumber});
}

List<Day> days = [
  Day(dayName: 'SUN', dayNumber: 1),
  Day(dayName: 'MON', dayNumber: 2),
  Day(dayName: 'TUE', dayNumber: 3),
  Day(dayName: 'WED', dayNumber: 4),
  Day(dayName: 'THU', dayNumber: 5),
  Day(dayName: 'FRI', dayNumber: 6),
  Day(dayName: 'SAT', dayNumber: 7),
];
