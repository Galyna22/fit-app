import 'package:hive/hive.dart';
import 'package:fitness_app/services/box_manager.dart';

class BoxOpeningAuditService {
  static final Map<String, DateTime> openingTimes = {};

  static void initSession() {
    print('🕵️ [Audit] Старт сессии аудита боксов...');
  }

  static void reportStatus(String stage) {
    print('📦 [Audit @ $stage] Статус боксов:');

    for (final name in BoxManager.allBoxNames) {
      final isOpen = Hive.isBoxOpen(name);
      print('🔍 $stage | "$name" => isOpen: $isOpen');

      if (isOpen && !openingTimes.containsKey(name)) {
        openingTimes[name] = DateTime.now();
        print('🕒 Впервые открыт: "$name" @ ${openingTimes[name]}');
      }
    }

    print('');
  }
}
