import 'package:hive/hive.dart';
import 'package:fitness_app/debug/box_audit_guard.dart';

class BoxInspectorService {
  static final List<String> _knownBoxes = [
    'workouts',
    'calendar',
    'activities',
    'cycling_activities',
    'strength_workouts',
    'settings',
  ];

  static List<String> get openBoxNames =>
      _knownBoxes.where((name) => Hive.isBoxOpen(name)).toList();

  static Map<String, String> getBoxTypes() {
    final types = <String, String>{};
    for (final name in openBoxNames) {
      try {
        final box = BoxAuditGuard.get<dynamic>(name);
        types[name] = box.runtimeType.toString();
      } catch (e) {
        types[name] = '❌ Ошибка доступа: $e';
      }
    }
    return types;
  }

  static Map<String, int> getBoxSizes() {
    final sizes = <String, int>{};
    for (final name in openBoxNames) {
      try {
        final box = BoxAuditGuard.get<dynamic>(name);
        sizes[name] = box.length;
      } catch (e) {
        sizes[name] = -1; // ❌ ошибка получения размера
      }
    }
    return sizes;
  }

  static void logSummary() {
    print('🧪 Box Summary:');
    for (final name in openBoxNames) {
      try {
        final box = BoxAuditGuard.get<dynamic>(name);
        print('📦 "$name" | Тип: ${box.runtimeType} | Размер: ${box.length}');
      } catch (e) {
        print('❌ "$name" не удалось получить: $e');
      }
    }
  }

  static void validateTypes(Map<String, Type> expected) {
    for (final entry in expected.entries) {
      final name = entry.key;
      final expectedType = entry.value;
      if (!Hive.isBoxOpen(name)) continue;

      try {
        final box = BoxAuditGuard.get<dynamic>(name);
        final actual = box.runtimeType.toString();
        final expectedStr = 'Box<$expectedType>';

        if (actual != expectedStr) {
          print(
            '⚠️ Несоответствие типа: "$name" ожидали $expectedStr, получили $actual',
          );
        }
      } catch (e) {
        print('❌ Ошибка проверки "$name": $e');
      }
    }
  }
}
