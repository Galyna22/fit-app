import 'dart:convert';
import 'dart:io';
import 'package:hive/hive.dart';

class BoxDumpService {
  static Future<void> dumpAllBoxesToTemp() async {
    final timestamp =
        DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final filename = 'hive_dump_$timestamp.json';
    final dir = await Directory.systemTemp.createTemp();
    final file = File('${dir.path}/$filename');

    final dump = <String, dynamic>{};

    for (final name in _knownBoxes) {
      if (Hive.isBoxOpen(name)) {
        final box = Hive.box(name);
        dump[name] = box.toMap();
      }
    }

    final json = const JsonEncoder.withIndent('  ').convert(dump);
    await file.writeAsString(json);
    print('🧠 Hive dump сохранён: ${file.path}');
  }

  static final List<String> _knownBoxes = [
    'workouts',
    'calendar',
    'activities',
    'cycling_activities',
    'strength_workouts',
    'settings',
  ];
}
