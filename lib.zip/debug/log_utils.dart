import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

enum LogLevel {
  info,
  warning,
  error,
  success,
  nav,
  userAction,
  debug,
  event,
  validation,
}

void logEvent(
  String message, {
  String? source,
  LogLevel level = LogLevel.info,
  Map<String, dynamic>? params,
  StackTrace? stackTrace,
}) {
  final event = {
    'timestamp': DateTime.now().toIso8601String(),
    'message': message,
    'source': source,
    'level': level.toString(),
    if (params != null) 'params': params,
    if (stackTrace != null) 'stackTrace': stackTrace.toString(),
  };

  // Handle different log levels
  switch (level) {
    case LogLevel.debug:
      debugPrint('[DEBUG] $event');
      break;
    case LogLevel.info:
      debugPrint('[INFO] $event');
      break;
    case LogLevel.warning:
      debugPrint('[WARNING] $event');
      break;
    case LogLevel.error:
      debugPrint('[ERROR] $event');
      break;
    case LogLevel.success:
      debugPrint('[SUCCESS] $event');
      break;
    case LogLevel.nav:
      debugPrint('[NAVIGATION] $event');
      break;
    case LogLevel.userAction:
      debugPrint('[USER ACTION] $event');
      break;
    case LogLevel.event:
      debugPrint('[EVENT] $event');
      break;
    case LogLevel.validation:
      debugPrint('[VALIDATION] $event');
      break;
  }
}
