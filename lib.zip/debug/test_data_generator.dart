import 'package:hive/hive.dart';
import 'package:fitness_app/data/strength_workout.dart';

class TestDataGenerator {
  static Future<void> generateAll() async {
    final box = await Hive.openBox<StrengthWorkout>('strength_workouts');

    final testWorkout = StrengthWorkout(
      id: 'test-${DateTime.now().millisecondsSinceEpoch}',
      date: DateTime.now(),
      durationSeconds: 1800,
      exercise: 'Приседания',
      sets: 3,
      repsPlanned: 10,
      repsActual: 10,
      weight: 50,
      heartRate: 100,
      restBetweenSetsSec: 60,
      pulseSeries: [80, 85, 90, 95, 100],
      maxHeartRate: 110,
      avgHeartRate: 90,
      notes: 'Тестовая тренировка',
    );

    await box.add(testWorkout);
  }
}
