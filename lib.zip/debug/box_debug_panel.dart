import 'package:flutter/material.dart';
import 'package:fitness_app/debug/box_inspector_service.dart';

class BoxDebugPanel extends StatelessWidget {
  const BoxDebugPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final boxTypes = BoxInspectorService.getBoxTypes();
    final boxSizes = BoxInspectorService.getBoxSizes();

    return Directionality(
      // ✅ Оборачиваем в Directionality
      textDirection: TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: const Text('Box Debug Panel')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              for (final name in boxTypes.keys)
                Card(
                  child: ListTile(
                    title: Text('📦 "$name"'),
                    subtitle: Text(
                        'Тип: ${boxTypes[name]}\nРазмер: ${boxSizes[name]}'),
                  ),
                ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: BoxInspectorService.logSummary,
                child: const Text('📊 Логировать Summary'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
