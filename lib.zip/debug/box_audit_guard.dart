import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class BoxAuditGuard {
  static final Map<String, DateTime> accessLog = {};
  static final Map<String, Box<dynamic>> _boxCache = {};

  /// 💾 Установка кеша при открытии
  static void setCache(String name, Box<dynamic> box) {
    _boxCache[name] = box;
  }

  /// 🛡️ Безопасное получение бокса
  static Box<T> get<T>(String name) {
    final now = DateTime.now();
    final formattedTime = DateFormat('HH:mm:ss.SSS').format(now);
    final stackLines = StackTrace.current.toString().split('\n');
    final callerShort = stackLines.first;
    final callerFull = stackLines.take(5).join('\n');

    print('🛡️ [BoxAuditGuard] Запрос "$name" @ $formattedTime');
    print('📞 Вызов из: $callerShort');

    final box = _boxCache[name];
    if (box == null) {
      print('⛔️ "$name" отсутствует в BoxAuditGuard._boxCache');
      print('📦 Стек вызова:\n$callerFull');
      throw HiveError('❌ "$name" не найден. Сначала вызови openBox().');
    }

    accessLog[name] = now;

    print('✅ "$name" получен из кеша. Тип: ${box.runtimeType}');

    if (box is! Box<T>) {
      throw HiveError(
        '❌ Неверный тип: ожидался Box<$T>, получен ${box.runtimeType}',
      );
    }

    return box as Box<T>;
  }

  /// 📊 Вывод аудита
  static void printSummary() {
    print('\n📊 BoxAccess Summary:');
    final sorted = accessLog.entries.toList()
      ..sort((a, b) => a.value.compareTo(b.value));

    for (final entry in sorted) {
      final time = DateFormat('HH:mm:ss.SSS').format(entry.value);
      print('📦 "${entry.key}" доступ @ $time');
    }
  }
}
