// lib/debug/route_logger.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fitness_app/debug/log_utils.dart';

class RouteLogger extends NavigatorObserver {
  static final RouteLogger _instance = RouteLogger._internal();
  factory RouteLogger() => _instance;
  RouteLogger._internal();

  @override
  void didPush(Route route, Route? previousRoute) {
    logEvent(
      'Navigated to ${route.settings.name}',
      level: LogLevel.nav,
      source: 'RouteLogger',
    );
  }

  void logButton(String buttonName, {String? source}) {
    logEvent(
      'BUTTON_PRESS',
      source: source ?? 'RouteLogger',
      params: {'button': buttonName},
    );
  }

  void logCustomEvent(String eventName, {Map<String, dynamic>? params}) {
    logEvent(
      eventName,
      source: 'RouteLogger',
      params: params,
    );
  }

  void logScreenView(String screenName, {Map<String, dynamic>? params}) {
    logEvent(
      'SCREEN_VIEW',
      source: screenName,
      params: params,
    );
  }

  void logNavigation(String from, String to) {
    logEvent(
      'NAVIGATION',
      source: 'RouteLogger',
      params: {'from': from, 'to': to},
    );
  }

  void logError(String error, {String? source, StackTrace? stackTrace}) {
    logEvent(
      'ERROR',
      source: source ?? 'RouteLogger',
      params: {'error': error},
      level: LogLevel.error,
      stackTrace: stackTrace,
    );
  }
}
