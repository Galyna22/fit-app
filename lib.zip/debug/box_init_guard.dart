import 'package:hive/hive.dart';

class BoxInitGuard {
  /// Проверяет, открыт ли бокс
  static bool isOpen(String name) => Hive.isBoxOpen(name);

  /// Безопасное получение бокса
  static Box<T> getSafe<T>(String name) {
    print('🛡️ [BoxInitGuard] Проверка "$name"...');

    if (!Hive.isBoxOpen(name)) {
      final stack =
          StackTrace.current.toString().split('\n').take(5).join('\n');
      print('⛔️ Бокс "$name" ещё НЕ открыт. 🚫 Доступ блокирован!');
      print('📦 Попытка из:\n$stack');

      throw HiveError(
          '❌ "$name" запрошен до открытия. Используй openBox() первым!');
    }

    final box = Hive.box(name);
    print('✅ Бокс "$name" открыт. Получен как ${box.runtimeType}');

    if (box is! Box<T>) {
      throw HiveError(
          '❌ Тип бокса "$name" не совпадает: ожидался Box<$T>, получен ${box.runtimeType}');
    }

    return box as Box<T>;
  }
}
