import 'package:hive/hive.dart';
import 'package:fitness_app/debug/box_audit_guard.dart';

class BoxAccessTracker {
  static final Map<String, String> accessMap = {};
  static final Map<String, String> openStackMap = {};

  static Future<Box<T>> openBox<T>(String name) async {
    if (Hive.isBoxOpen(name)) {
      final box = Hive.box(name);
      BoxAuditGuard.setCache(name, box); // ✅ Кешируем уже открытый
      _logAccess(name, box.runtimeType.toString(), alreadyOpen: true);
      if (box is! Box<T>) {
        throw HiveError(
          '❌ "$name" уже открыт, но не как Box<$T>. Получено: ${box.runtimeType}',
        );
      }
      return box;
    } else {
      final box = await Hive.openBox<T>(name);
      BoxAuditGuard.setCache(name, box); // ✅ Кешируем только что открытый
      _logAccess(name, 'Box<$T>', alreadyOpen: false);
      return box;
    }
  }

  static void _logAccess(String name, String type,
      {required bool alreadyOpen}) {
    final stack = StackTrace.current.toString().split('\n');

    final callerFrame = stack.firstWhere(
      (line) =>
          line.contains('package:') &&
          !line.contains('box_access_tracker.dart'),
      orElse: () => '🕵️ Не удалось определить файл вызова',
    );

    final caller = callerFrame.trim();
    final status = alreadyOpen ? '🔁 уже открыт' : '📦 открыт';

    accessMap[name] = caller;
    openStackMap[name] = stack.join('\n');

    print('📋 $status "$name" как $type');
    print('🧭 открыт из: $caller\n');
  }

  static void reportAccess() {
    print('📡 Box Access Tracker:');
    for (final entry in accessMap.entries) {
      print('📦 "${entry.key}" открыт из: ${entry.value}');
    }
    print('');
  }

  static void dumpStack(String name) {
    final stack = openStackMap[name];
    if (stack == null) {
      print('📦 "$name" не найден в логах стека.');
    } else {
      print('🧠 Стек открытия "$name":\n$stack');
    }
  }
}
