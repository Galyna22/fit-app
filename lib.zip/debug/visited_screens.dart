import 'package:flutter/foundation.dart';

final Set<String> visitedScreens = {};

void trackScreen(String name) {
  visitedScreens.add(name);
  debugPrint('🛰️ Посещён экран: $name');
}

void printVisitedScreens() {
  debugPrint('📋 Посещённые экраны:');
  for (final name in visitedScreens) {
    debugPrint('  • $name');
  }
}
