import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/screens/run_result_screen.dart';
import 'package:fitness_app/debug/log_utils.dart';

class RunTimerScreen extends StatefulWidget {
  const RunTimerScreen({super.key});

  @override
  State<RunTimerScreen> createState() => _RunTimerScreenState();
}

class _RunTimerScreenState extends State<RunTimerScreen> {
  late DateTime _startTime;
  Duration _elapsed = Duration.zero;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _startTime = DateTime.now();
    logEvent('⏱️ Тренировка началась', source: 'RunTimerScreen');
  }

  Future<void> _stopAndSave() async {
    logEvent('🔘 [_stopAndSave()] вызывается', source: 'RunTimerScreen');
    setState(() => _isSaving = true);

    final endTime = DateTime.now();
    _elapsed = endTime.difference(_startTime);

    final activity = RunActivity(
      id: 'run-${DateTime.now().millisecondsSinceEpoch}',
      date: endTime,
      durationSeconds: _elapsed.inSeconds,
      distance: 5.4, // Пример — подставь своё значение
      steps: 6250,
      caloriesBurned: 320,
      avgHeartRate: 134,
      maxHeartRate: 168,
      paceMinPerKm: 5.2,
      avgSpeed: 11.3,
      cadenceSpm: 166,
      strideLength: 1.25,
      vo2Max: 45.8,
      trainingLoad: 76.4,
      spo2: 97.0,
      groundContactTime: 214,
      recoveryTime: 85,
      maxSpeed: 14.3,
      elevationGain: 42,
      elevationLoss: 38,
      temperature: 22.4,
      strideSymmetry: 49.7,
      verticalOscillation: 6.8,
      stressLevel: 18,
      gpsTrack: const [], // добавь путь, если есть
      heartRateZones: {
        'Зона 1': 300,
        'Зона 2': 420,
        'Зона 3': 180,
        'Зона 4': 120,
        'Зона 5': 90,
      },
    );

    try {
      final box = Hive.box<RunActivity>('activities');
      await box.add(activity);
      logEvent('✅ RunActivity сохранён: ${activity.id}',
          source: 'RunTimerScreen', level: 'HIVE_SUCCESS');

      if (!mounted) {
        logEvent('⚠️ Контекст недоступен для навигации',
            source: 'RunTimerScreen', level: 'NAVIGATION_WARNING');
        return;
      }

      logNav(
        from: 'RunTimerScreen',
        to: 'RunResultScreen',
        activityId: activity.id,
        activityType: 'run',
        comment: 'Завершение тренировки вручную через [_stopAndSave()]',
      );

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RunResultScreen(run: activity),
          settings: RouteSettings(name: '/run_result', arguments: activity),
        ),
      );

      logEvent('🟢 Переход завершён',
          source: 'RunTimerScreen', level: 'NAVIGATION');
    } catch (e, stack) {
      logEvent('🛑 Ошибка при сохранении: $e',
          source: 'RunTimerScreen', level: 'ERR');
      debugPrintStack(stackTrace: stack);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('❌ Ошибка: ${e.toString()}')),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Бег в реальном времени')),
      body: Center(
        child: _isSaving
            ? const CircularProgressIndicator()
            : ElevatedButton(
                onPressed: _stopAndSave,
                child: const Text('⏹️ Завершить тренировку'),
              ),
      ),
    );
  }
}
