import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/services/backup_service.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/screens/home_screen.dart';

class MyFitnessApp extends StatelessWidget {
  final DatabaseHelper dbHelper;
  final BackupService backupService;
  final Box<RunActivity> activityBox;

  const MyFitnessApp({
    super.key,
    required this.dbHelper,
    required this.backupService,
    required this.activityBox,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fitness Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(
        dbHelper: dbHelper,
        backupService: backupService,
        activityBox: activityBox,
      ),
    );
  }
}

class ErrorApp extends StatelessWidget {
  const ErrorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                '❌ Ошибка инициализации',
                style: TextStyle(fontSize: 24),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => runApp(
                  const Center(child: CircularProgressIndicator()),
                ),
                child: const Text('Повторить запуск'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
