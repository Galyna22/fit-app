import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class ActivityCalendar extends StatefulWidget {
  final Map<DateTime, List<String>> activityMap; // Дата → ['run', 'bike']
  final Function(DateTime)? onDateSelected;

  const ActivityCalendar({
    super.key,
    required this.activityMap,
    this.onDateSelected,
  });

  @override
  State<ActivityCalendar> createState() => _ActivityCalendarState();
}

class _ActivityCalendarState extends State<ActivityCalendar> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ToggleButtons(
          isSelected: ['all', 'run', 'bike'].map((f) => _filter == f).toList(),
          onPressed: (index) {
            setState(() {
              _filter = ['all', 'run', 'bike'][index];
            });
          },
          children: const [
            Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('Все')),
            Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('Run')),
            Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('Bike')),
          ],
        ),
        const SizedBox(height: 8),
        TableCalendar(
          focusedDay: _focusedDay,
          firstDay: DateTime.utc(2020, 1, 1),
          lastDay: DateTime.utc(2030, 12, 31),
          selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
          onDaySelected: (selected, focused) {
            setState(() {
              _selectedDay = selected;
              _focusedDay = focused;
            });
            widget.onDateSelected?.call(selected);
          },
          calendarBuilders: CalendarBuilders(
            markerBuilder: (context, date, events) {
              final types = widget.activityMap[date] ?? [];
              final show = _filter == 'all' || types.contains(_filter);

              if (!show) return const SizedBox.shrink();
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: types
                    .map((type) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 1),
                          child: Icon(
                            type == 'run'
                                ? Icons.directions_run
                                : Icons.pedal_bike,
                            size: 12,
                            color: type == 'run' ? Colors.blue : Colors.orange,
                          ),
                        ))
                    .toList(),
              );
            },
          ),
        ),
      ],
    );
  }
}
