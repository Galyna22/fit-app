import 'package:flutter/material.dart';

class WeeklyExerciseStatsWidget extends StatelessWidget {
  final Map<String, Map<String, int>> weeklyStats;

  const WeeklyExerciseStatsWidget({super.key, required this.weeklyStats});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: weeklyStats.entries.map((weekEntry) {
        final week = weekEntry.key;
        final stats = weekEntry.value;

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('📅 Неделя с $week',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...stats.entries
                    .map((e) => Text('• ${e.key} — ${e.value} раз')),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}
