import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class WorkoutMapView extends StatelessWidget {
  final List<List<double>> gpsTrack;

  const WorkoutMapView({super.key, required this.gpsTrack});

  @override
  Widget build(BuildContext context) {
    if (gpsTrack.length < 2) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Text('Недостаточно GPS-точек для отображения маршрута'),
      );
    }

    final points = gpsTrack.map((e) => LatLng(e[0], e[1])).toList();

    return SizedBox(
      height: 300,
      child: FlutterMap(
        options: MapOptions(
          initialCenter: points.first,
          initialZoom: 15,
        ),
        children: [
          TileLayer(
            urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            subdomains: const ['a', 'b', 'c'],
          ),
          PolylineLayer(
            polylines: [
              Polyline(
                points: points,
                strokeWidth: 4.0,
                color: Colors.blueAccent,
              ),
            ],
          ),
          MarkerLayer(
            markers: [
              Marker(
                point: points.first,
                width: 40,
                height: 40,
                child: const Icon(Icons.play_arrow, color: Colors.green),
              ),
              Marker(
                point: points.last,
                width: 40,
                height: 40,
                child: const Icon(Icons.flag, color: Colors.red),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
