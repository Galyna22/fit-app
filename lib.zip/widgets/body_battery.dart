import 'package:flutter/material.dart';

class BodyBatteryWidget extends StatelessWidget {
  final double value; // 0-100

  const BodyBatteryWidget({
    Key? key,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blueGrey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          const Text('BODY BATTERY',
              style: TextStyle(color: Colors.grey, fontSize: 14)),
          const SizedBox(height: 8),
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 150,
                height: 150,
                child: CircularProgressIndicator(
                  value: value / 100,
                  strokeWidth: 12,
                  backgroundColor: Colors.blueGrey[800],
                  color: _getBatteryColor(value),
                ),
              ),
              Text(
                '${value.round()}%',
                style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            _getBatteryStatusText(value),
            style: const TextStyle(color: Colors.white, fontSize: 16),
          ),
        ],
      ),
    );
  }

  Color _getBatteryColor(double value) {
    if (value > 75) return Colors.greenAccent;
    if (value > 50) return Colors.lightGreen;
    if (value > 25) return Colors.yellow;
    return Colors.redAccent;
  }

  String _getBatteryStatusText(double value) {
    if (value > 75) return 'Fully charged';
    if (value > 50) return 'Moderate';
    if (value > 25) return 'Low';
    return 'Depleted';
  }
}
