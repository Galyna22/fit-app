import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class WorkoutChartWidget extends StatelessWidget {
  final List<int> pulseSeries;

  const WorkoutChartWidget({super.key, required this.pulseSeries});

  @override
  Widget build(BuildContext context) {
    final spots = pulseSeries
        .asMap()
        .entries
        .map((e) => FlSpot(e.key.toDouble(), e.value.toDouble()))
        .toList();

    return SizedBox(
      height: 200,
      child: LineChart(LineChartData(
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: Colors.red,
            dotData: FlDotData(show: false),
          )
        ],
        titlesData: FlTitlesData(show: false),
        gridData: FlGridData(show: false),
        borderData: FlBorderData(show: false),
      )),
    );
  }
}
