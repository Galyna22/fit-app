import 'package:flutter/material.dart';

class TodaySummaryCard extends StatelessWidget {
  final Duration totalDuration;
  final int totalCalories;
  final List<String> activityTypes; // пример: ['Run', 'Bike', 'Yoga']

  const TodaySummaryCard({
    super.key,
    required this.totalDuration,
    required this.totalCalories,
    required this.activityTypes,
  });

  @override
  Widget build(BuildContext context) {
    final types = activityTypes.join(' · ');

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Сегодня',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(types, style: const TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.access_time, size: 20),
                const SizedBox(width: 4),
                Text('${totalDuration.inMinutes} мин'),
                const SizedBox(width: 16),
                const Icon(Icons.local_fire_department, color: Colors.red, size: 20),
                const SizedBox(width: 4),
                Text('$totalCalories ккал'),
                const SizedBox(width: 16),
                const Icon(Icons.fitness_center, size: 20),
                const SizedBox(width: 4),
                Text('${activityTypes.length} тренировок'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}