import 'package:flutter/material.dart';
import 'package:fitness_app/data/workout_model.dart';

class WorkoutCardWidget extends StatelessWidget {
  final WorkoutModel workout;

  const WorkoutCardWidget({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    final custom = workout.customExercises ?? [];
    return Card(
      child: ListTile(
        leading: const Icon(Icons.fitness_center),
        title: Text(
            '${workout.activityType.toUpperCase()} – ${workout.date.toString().substring(0, 10)}'),
        subtitle: custom.isEmpty
            ? const Text('Нет упражнений')
            : Text(custom.map((e) => e.name).join(', ')),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => WorkoutDetailScreen(workout: workout),
              ));
        },
      ),
    );
  }
}
