import 'package:flutter/material.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/services/feed_label_resolver.dart';

class ActivityFeedCard extends StatelessWidget {
  final WorkoutModel workout;

  const ActivityFeedCard({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    final title = FeedLabelResolver.label(workout);
    final date = workout.date.toString().substring(0, 10);

    return Card(
      child: ListTile(
        leading: const Icon(Icons.fitness_center),
        title: Text(title),
        subtitle: Text('Дата: $date'),
      ),
    );
  }
}
