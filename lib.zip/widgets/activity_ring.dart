import 'package:flutter/material.dart';

class ActivityRing extends StatelessWidget {
  final int steps;
  final int stepsGoal;
  final int calories;
  final int caloriesGoal;
  final int activeMinutes;
  final int activeMinutesGoal;
  final double distanceKm;

  const ActivityRing({
    super.key,
    required this.steps,
    required this.stepsGoal,
    required this.calories,
    required this.caloriesGoal,
    required this.activeMinutes,
    required this.activeMinutesGoal,
    required this.distanceKm,
  });

  @override
  Widget build(BuildContext context) {
    final stepsProgress = (steps / stepsGoal).clamp(0.0, 1.0);
    final calProgress = (calories / caloriesGoal).clamp(0.0, 1.0);
    final minProgress = (activeMinutes / activeMinutesGoal).clamp(0.0, 1.0);

    return LayoutBuilder(
      builder: (context, constraints) {
        final size = constraints.maxWidth * 0.7;
        return Center(
          child: SizedBox(
            width: size,
            height: size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(
                  value: stepsProgress,
                  strokeWidth: size * 0.12,
                  color: Colors.blue,
                  backgroundColor: Colors.blue.withOpacity(0.2),
                ),
                CircularProgressIndicator(
                  value: calProgress,
                  strokeWidth: size * 0.08,
                  color: Colors.red,
                  backgroundColor: Colors.red.withOpacity(0.2),
                ),
                CircularProgressIndicator(
                  value: minProgress,
                  strokeWidth: size * 0.05,
                  color: Colors.green,
                  backgroundColor: Colors.green.withOpacity(0.2),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$steps шагов',
                      style: TextStyle(
                        fontSize: size * 0.13,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    Text(
                      '(${distanceKm.toStringAsFixed(1)} км)',
                      style: TextStyle(
                        fontSize: size * 0.08,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
