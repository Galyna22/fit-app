import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class PulseChart extends StatelessWidget {
  final List<int> pulseSeries;

  const PulseChart({super.key, required this.pulseSeries});

  @override
  Widget build(BuildContext context) {
    final spots = <FlSpot>[];
    for (int i = 0; i < pulseSeries.length; i++) {
      spots.add(FlSpot(i.toDouble(), pulseSeries[i].toDouble()));
    }

    return LineChart(
      LineChartData(
        minY: 40,
        maxY: 200,
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 32,
              interval: 20,
              getTitlesWidget: (value, meta) => Text('${value.toInt()}'),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(show: true, horizontalInterval: 20),
        borderData: FlBorderData(show: true),
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: false, // 👈 Убираем сглаживание
            color: Colors.redAccent,
            barWidth: 2,
            isStrokeCapRound: false,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(show: false),
          ),
        ],
      ),
    );
  }
}
