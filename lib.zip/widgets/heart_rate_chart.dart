import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';

class HeartRateChart extends StatelessWidget {
  final List<int> pulseSeries;
  final HeartRateAnalysis analysis;

  const HeartRateChart({
    super.key,
    required this.pulseSeries,
    required this.analysis,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('📈 Пульс по времени', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 12),
        SizedBox(
          height: 160,
          child: LineChart(
            LineChartData(
              titlesData: FlTitlesData(show: false),
              gridData: FlGridData(show: false),
              borderData: FlBorderData(show: false),
              lineBarsData: [
                LineChartBarData(
                  spots: List.generate(
                    pulseSeries.length,
                    (i) => FlSpot(i.toDouble(), pulseSeries[i].toDouble()),
                  ),
                  isCurved: true,
                  color: Colors.redAccent,
                  dotData: FlDotData(show: false),
                  belowBarData: BarAreaData(show: false),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text('💡 Зоны ЧСС', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 12),
        SizedBox(
          height: 140,
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              barTouchData: BarTouchData(enabled: false),
              titlesData: FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
              barGroups: analysis.zones
                  .map(
                    (zone) => BarChartGroupData(
                      x: zone.name.hashCode,
                      barRods: [
                        BarChartRodData(
                          toY: zone.percent,
                          color: _zoneColor(zone.name),
                          width: 20,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ],
                    ),
                  )
                  .toList(),
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...analysis.zones.map(
          (zone) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              children: [
                Expanded(child: Text(zone.name)),
                Text(
                  '${zone.seconds}s • ${zone.percent.toStringAsFixed(1)}%',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Color _zoneColor(String zoneName) {
    switch (zoneName) {
      case 'Zone 1':
        return Colors.green;
      case 'Zone 2':
        return Colors.lightGreen;
      case 'Zone 3':
        return Colors.orange;
      case 'Zone 4':
        return Colors.deepOrange;
      case 'Zone 5':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
