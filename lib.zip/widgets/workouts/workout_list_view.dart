import 'package:flutter/material.dart';
import '../../data/activity_type.dart';

class WorkoutListView extends StatelessWidget {
  final void Function(ActivityType type) onSelect;

  const WorkoutListView({super.key, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final types = ActivityType.values;

    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: types.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, index) {
        final type = types[index];
        return ListTile(
          leading: Icon(type.icon, color: type.color),
          title: Text(type.displayName),
          onTap: () => onSelect(type),
        );
      },
    );
  }
}
