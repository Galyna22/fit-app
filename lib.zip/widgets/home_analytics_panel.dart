import 'package:flutter/material.dart';
import 'package:fitness_app/screens/training/activity_feed_screen.dart' as feed;
import 'package:fitness_app/screens/training/activity_summary_screen.dart'
    as summary;

class HomeAnalyticsPanel extends StatelessWidget {
  const HomeAnalyticsPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 16),
        _buildNavigationCard(
          icon: Icons.timeline,
          label: 'Лента тренировок',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => feed.ActivityFeedScreen()),
          ),
        ),
        const SizedBox(height: 8),
        _buildNavigationCard(
          icon: Icons.bar_chart,
          label: 'Сводка активности',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => summary.ActivitySummaryScreen()),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildNavigationCard({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Card(
        child: ListTile(
          leading: Icon(icon),
          title: Text(label),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
          onTap: onTap,
        ),
      ),
    );
  }
}
