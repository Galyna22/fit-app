import 'package:flutter/material.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

class ActivityScreen extends StatelessWidget {
  final DatabaseHelper dbHelper;
  final Box<RunActivity> activityBox;
  final DateTime? filterDate; // 🔍 позволяет фильтровать по дню

  const ActivityScreen({
    super.key,
    required this.dbHelper,
    required this.activityBox,
    this.filterDate,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🏃 Активности')),
      body: ValueListenableBuilder(
        valueListenable: activityBox.listenable(),
        builder: (context, Box<RunActivity> box, _) {
          final List<RunActivity> activities = box.values
              .where((a) =>
                  filterDate == null ||
                  (a.date.year == filterDate!.year &&
                      a.date.month == filterDate!.month &&
                      a.date.day == filterDate!.day))
              .toList()
            ..sort((a, b) => b.date.compareTo(a.date)); // 🕒 последние сверху

          if (activities.isEmpty) {
            return const Center(child: Text('Нет активностей'));
          }

          return ListView.builder(
            itemCount: activities.length,
            itemBuilder: (context, index) {
              final a = activities[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                elevation: 2,
                child: ExpansionTile(
                  title: Text(
                    '${a.distance.toStringAsFixed(2)} км • ${a.formattedDuration}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(DateFormat('dd.MM.yyyy HH:mm').format(a.date)),
                  children: [
                    _detail('Шаги', '${a.steps}'),
                    _detail('Калории', a.caloriesBurned.toStringAsFixed(0)),
                    _detail('Средний пульс',
                        '${a.avgHeartRate.toStringAsFixed(0)} уд/мин'),
                    _detail('Макс. пульс', a.maxHeartRate.toStringAsFixed(0)),
                    _detail(
                        'Темп', '${a.paceMinPerKm.toStringAsFixed(1)} мин/км'),
                    _detail(
                        'Скорость', '${a.avgSpeed.toStringAsFixed(1)} км/ч'),
                    _detail('Каденс', '${a.cadenceSpm} шаг/мин'),
                    _detail(
                        'Длина шага', '${a.strideLength.toStringAsFixed(2)} м'),
                    _detail('VO₂ Max', a.vo2Max.toStringAsFixed(1)),
                    _detail('Нагрузка', a.trainingLoad.toStringAsFixed(1)),
                    _detail('SpO₂', '${a.spo2.toStringAsFixed(0)} %'),
                    _detail('Контакт с землёй', '${a.groundContactTime} мс'),
                    _detail('Восстановление', '${a.recoveryTime} мин'),
                    _detail('Макс. скорость',
                        '${a.maxSpeed.toStringAsFixed(1)} км/ч'),
                    _detail(
                        'Подъём', '${a.elevationGain.toStringAsFixed(0)} м'),
                    _detail('Спуск', '${a.elevationLoss.toStringAsFixed(0)} м'),
                    _detail('Температура',
                        '${a.temperature.toStringAsFixed(1)} °C'),
                    _detail('Симметрия шага',
                        '${a.strideSymmetry.toStringAsFixed(1)} %'),
                    _detail('Вертик. колебания',
                        '${a.verticalOscillation.toStringAsFixed(1)} см'),
                    _detail('Стресс', a.stressLevel.toStringAsFixed(0)),
                    _detail('Длительность',
                        '${Duration(seconds: a.durationSeconds)}'),
                    _detail('GPS точек', '${a.gpsTrack.length}'),
                    const Padding(
                      padding: EdgeInsets.only(top: 8, bottom: 4),
                      child: Text('Зоны пульса:',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    ...a.heartRateZones.entries.map(
                      (e) => _detail(
                          e.key, '${e.value ~/ 60} мин ${e.value % 60} сек'),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _detail(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
