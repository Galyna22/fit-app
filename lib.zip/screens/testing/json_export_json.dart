import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/workout_model.dart';

class JsonExportScreen extends StatelessWidget {
  const JsonExportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = Hive.box<WorkoutModel>('workouts').values.toList();
    final jsonString = jsonEncode(workouts.map((w) => w.toJson()).toList());

    return Scaffold(
      appBar: AppBar(title: const Text('🧪 JSON Экспорт')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: SelectableText(jsonString),
        ),
      ),
    );
  }
}
