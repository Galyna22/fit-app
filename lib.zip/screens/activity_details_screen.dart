import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart'; // Пакет для графиков

class ActivityDetailsScreen extends StatelessWidget {
  final int steps;
  final double calories;
  final int activeMinutes;

  const ActivityDetailsScreen({
    super.key,
    required this.steps,
    required this.calories,
    required this.activeMinutes,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Детали активности')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildCircularChart('Шаги', steps.toDouble(), 12000, Colors.blue),
            _buildCircularChart('Калории', calories, 500, Colors.red),
            _buildCircularChart(
                'Активные минуты', activeMinutes.toDouble(), 180, Colors.green),
          ],
        ),
      ),
    );
  }

  Widget _buildCircularChart(
      String label, double value, double maxValue, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        children: [
          Text('$label: ${value.toInt()} / ${maxValue.toInt()}',
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(
              height: 150,
              child: PieChart(
                PieChartData(
                  sections: [
                    PieChartSectionData(value: value, color: color, radius: 60),
                    PieChartSectionData(
                        value: maxValue - value,
                        color: Colors.grey[300]!,
                        radius: 40),
                  ],
                  borderData: FlBorderData(show: false),
                  sectionsSpace: 0,
                  centerSpaceRadius: 40,
                ),
              )),
        ],
      ),
    );
  }
}
