import 'package:flutter/material.dart';

class HomeAnalyticsPanel extends StatelessWidget {
  const HomeAnalyticsPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blueGrey.shade900,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('📈 Мотивация недели', style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            'Ты уже сделал 72% от цели по шагам — осталась последняя прогулка 💪',
            style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white70),
          ),
        ],
      ),
    );
  }
}
