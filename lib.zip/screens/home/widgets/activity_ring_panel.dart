import 'package:flutter/material.dart';
import 'package:fitness_app/widgets/activity_ring.dart';

class ActivityRingPanel extends StatelessWidget {
  final int steps;
  final int stepsGoal;
  final int calories;
  final int caloriesGoal;
  final int activeMinutes;
  final int activeMinutesGoal;
  final double distanceKm;

  const ActivityRingPanel({
    super.key,
    required this.steps,
    required this.stepsGoal,
    required this.calories,
    required this.caloriesGoal,
    required this.activeMinutes,
    required this.activeMinutesGoal,
    required this.distanceKm,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 16),
        ActivityRing(
          steps: steps,
          stepsGoal: stepsGoal,
          calories: calories,
          caloriesGoal: caloriesGoal,
          activeMinutes: activeMinutes,
          activeMinutesGoal: activeMinutesGoal,
          distanceKm: distanceKm,
        ),
      ],
    );
  }
}
