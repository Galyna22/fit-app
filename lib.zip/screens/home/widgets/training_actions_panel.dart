import 'package:flutter/material.dart';

class TrainingActionsPanel extends StatelessWidget {
  final void Function(Object type) onStartWorkout;

  const TrainingActionsPanel({
    super.key,
    required this.onStartWorkout,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        ElevatedButton.icon(
          onPressed: () => onStartWorkout('run'),
          icon: const Icon(Icons.directions_run),
          label: const Text('Бег'),
        ),
        ElevatedButton.icon(
          onPressed: () => onStartWorkout('ride'),
          icon: const Icon(Icons.pedal_bike),
          label: const Text('Велотренировка'),
        ),
        ElevatedButton.icon(
          onPressed: () => onStartWorkout('strength'),
          icon: const Icon(Icons.fitness_center),
          label: const Text('Силовая'),
        ),
      ],
    );
  }
}
