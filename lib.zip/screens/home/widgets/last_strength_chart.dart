import 'package:flutter/material.dart';
import 'package:fitness_app/widgets/heart_rate_chart.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';
import 'package:fitness_app/data/strength_workout.dart';

class LastStrengthChart extends StatelessWidget {
  final StrengthWorkout? workout;

  const LastStrengthChart({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    if (workout?.pulseSeries == null || workout!.pulseSeries!.isEmpty) {
      return const SizedBox(); // ничего не рендерим
    }

    final pulse = workout!.pulseSeries!;
    final analysis = analyzeHeartRate(data: pulse);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: HeartRateChart(
            pulseSeries: pulse,
            analysis: analysis,
          ),
        ),
      ),
    );
  }
}
