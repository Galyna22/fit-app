import 'package:flutter/material.dart';

class TodayStatsPanel extends StatelessWidget {
  final int steps;
  final int calories;
  final double distanceKm;

  const TodayStatsPanel({
    super.key,
    required this.steps,
    required this.calories,
    required this.distanceKm,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _buildStatCard(Icons.directions_walk, '$steps', 'Шаги'),
        const SizedBox(width: 8),
        _buildStatCard(
            Icons.local_fire_department, '$calories ккал', 'Калории'),
        const SizedBox(width: 8),
        _buildStatCard(
            Icons.place, '${distanceKm.toStringAsFixed(1)} км', 'Дистанция'),
      ],
    );
  }

  Widget _buildStatCard(IconData icon, String value, String label) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Icon(icon, size: 24),
                const SizedBox(height: 8),
                Text(value,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
                Text(label, style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ),
      );
}
