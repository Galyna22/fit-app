import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fitness_app/data/strength_workout.dart';

// 📦 Основные панели
import 'package:fitness_app/screens/home/widgets/activity_ring_panel.dart';
import 'package:fitness_app/screens/home/widgets/today_stats_panel.dart';
import 'package:fitness_app/screens/home/widgets/body_battery_panel.dart';
import 'package:fitness_app/screens/home/widgets/last_strength_chart.dart';

// 🔥 Свежие фишки
import 'package:fitness_app/screens/home/widgets/home_analytics_panel.dart';
import 'package:fitness_app/screens/home/widgets/training_actions_panel.dart';
import 'package:fitness_app/screens/home/widgets/home_navigation_tiles.dart';

class HomeBodyContent extends StatelessWidget {
  final int todaySteps;
  final int todayCalories;
  final double todayDistanceKm;
  final int todayMinutes;
  final int todayHeartRate;
  final double bodyBatteryLevel;
  final StrengthWorkout? latestStrength;
  final void Function(Object type) onStartWorkout;

  const HomeBodyContent({
    super.key,
    required this.todaySteps,
    required this.todayCalories,
    required this.todayDistanceKm,
    required this.todayMinutes,
    required this.todayHeartRate,
    required this.bodyBatteryLevel,
    required this.latestStrength,
    required this.onStartWorkout,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dateFormat = DateFormat('EEEE, d MMMM', 'ru_RU');

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            dateFormat.format(DateTime.now()),
            style: theme.textTheme.bodySmall?.copyWith(color: Colors.white70),
          ),

          // 🔄 Кольца активности: шаги, калории, мин, км
          ActivityRingPanel(
            steps: todaySteps,
            stepsGoal: 10000,
            calories: todayCalories,
            caloriesGoal: 500,
            activeMinutes: todayMinutes,
            activeMinutesGoal: 30,
            distanceKm: todayDistanceKm,
          ),

          // 🔋 Батарея тела
          BodyBatteryPanel(value: bodyBatteryLevel),

          // 📊 Статистика дня
          TodayStatsPanel(
            steps: todaySteps,
            calories: todayCalories,
            distanceKm: todayDistanceKm,
          ),

          // 💓 Силовая тренировка — пульс
          if (latestStrength != null &&
              latestStrength!.pulseSeries != null &&
              latestStrength!.pulseSeries!.isNotEmpty)
            LastStrengthChart(workout: latestStrength!),

          const SizedBox(height: 16),

          // 📈 Аналитика + мотивация
          const HomeAnalyticsPanel(),

          const SizedBox(height: 16),

          // 🏁 Кнопки старта активности
          TrainingActionsPanel(onStartWorkout: onStartWorkout),

          const SizedBox(height: 16),

          // 📋 Переходы к экранам: Лента, Сводка
          const HomeNavigationTiles(),

          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
