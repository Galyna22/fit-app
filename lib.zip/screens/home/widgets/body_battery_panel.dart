import 'package:flutter/material.dart';
import 'package:fitness_app/widgets/body_battery.dart';

class BodyBatteryPanel extends StatelessWidget {
  final double value;

  const BodyBatteryPanel({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    return const SizedBox(height: 16);
  }
}
