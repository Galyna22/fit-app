import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/activity_log_day.dart';
import 'package:fitness_app/services/backup_service.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/ui/screens/workout_history_screen.dart';
import 'package:fitness_app/screens/heart_rate/daily_heart_rate_screen.dart';
import 'package:fitness_app/utils/log_service.dart';
import 'package:fitness_app/features/calendar/widgets/calendar_day_tile.dart';
import 'package:fitness_app/utils/log_service.dart';

class HomeScreen extends StatelessWidget {
  final DatabaseHelper dbHelper;
  final BackupService backupService;
  final Box<RunActivity> activityBox;

  const HomeScreen({
    super.key,
    required this.dbHelper,
    required this.backupService,
    required this.activityBox,
  });

  @override
  Widget build(BuildContext context) {
    LogService.info('🏠 Открыт HomeScreen', tag: 'UI');
    LogService.info('📦 dbHelper: ${dbHelper.runtimeType}', tag: 'DEBUG');
    LogService.info('📦 backupService: ${backupService.runtimeType}',
        tag: 'DEBUG');
    LogService.info('📦 activityBox: ${activityBox.name}', tag: 'DEBUG');

    final runBox = Hive.box<RunActivity>('activities');
    final cyclingBox = Hive.box<CyclingActivity>('cycling_activities');
    final workoutBox = Hive.box<WorkoutModel>('workouts');

    return Scaffold(
      appBar: AppBar(
        title: const Text('🏋️ Мои тренировки'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Лента тренировок',
            onPressed: () {
              final workouts = workoutBox.values.toList();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WorkoutHistoryScreen(workouts: workouts),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.favorite, color: Colors.redAccent),
            tooltip: 'Пульс за день',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DailyHeartRateScreen(),
                ),
              );
            },
          ),
        ],
      ),

      // ✅ ВСТАВЛЯЕМ FutureBuilder В ТЕЛО
      body: FutureBuilder<List<ActivityLogDay>>(
        future: LogService().fetchRecentLogs(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final logs = snapshot.data!;
          if (logs.isEmpty) {
            return const Center(child: Text('Нет данных активности 💤'));
          }

          return ListView.builder(
            itemCount: logs.length,
            itemBuilder: (_, index) => CalendarDayTile(log: logs[index]),
          );
        },
      ),
    );
  }
}
