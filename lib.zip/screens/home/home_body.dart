import 'dart:math';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/activity_type.dart' as app;
import 'package:fitness_app/screens/training/new_running_workout_screen.dart';
import 'package:fitness_app/screens/training/new_strength_workout_screen.dart';
import 'package:fitness_app/screens/training/new_cycling_workout_screen.dart';
import 'package:fitness_app/screens/home/widgets/home_body_content.dart';
import 'package:fitness_app/services/backup_service.dart';
import 'package:fitness_app/utils/log_service.dart';

class HomeBody extends StatefulWidget {
  final DatabaseHelper dbHelper;
  final BackupService backupService;
  final Box<RunActivity> runBox;
  final Box<CyclingActivity> cyclingBox;

  const HomeBody({
    super.key,
    required this.dbHelper,
    required this.backupService,
    required this.runBox,
    required this.cyclingBox,
  });

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  final Random random = Random();
  bool isLoading = false;

  int todaySteps = 6420;
  int todayCalories = 356;
  double todayDistanceKm = 4.3;
  int todayMinutes = 24;
  int todayHeartRate = 72;
  double bodyBatteryLevel = 75.0;

  StrengthWorkout? latestStrength;

  @override
  void initState() {
    super.initState();
    LogService.info('🏃‍♂️ HomeBody инициализирован', tag: 'LIFECYCLE');
    _loadTodayData();
  }

  Future<void> _loadTodayData() async {
    LogService.info('📊 Загрузка данных за сегодня', tag: 'DATA');
    setState(() => isLoading = true);

    await Future.delayed(const Duration(seconds: 1));
    final strength = await _getLatestStrengthWorkout();

    setState(() {
      todaySteps = 6420 + random.nextInt(1000);
      todayCalories = 356 + random.nextInt(50);
      todayDistanceKm = 4.3 + random.nextDouble();
      todayMinutes = 24 + random.nextInt(15);
      todayHeartRate = 72 + random.nextInt(10);
      bodyBatteryLevel = (60 + random.nextInt(40)).toDouble();
      latestStrength = strength;
      isLoading = false;
    });
  }

  Future<StrengthWorkout?> _getLatestStrengthWorkout() async {
    final box = Hive.isBoxOpen('strength_workouts')
        ? Hive.box<StrengthWorkout>('strength_workouts')
        : await Hive.openBox<StrengthWorkout>('strength_workouts');

    if (box.isEmpty) return null;

    final sorted = box.values.toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    return sorted.first;
  }

  void _startWorkout(app.ActivityType type) {
    LogService.info('👆 Старт тренировки: $type', tag: 'UI');

    Widget screen;
    switch (type) {
      case app.ActivityType.run:
        screen = const RunningWorkoutScreen();
        break;
      case app.ActivityType.strength:
        screen = StrengthWorkoutScreen(
          activityType: app.ActivityType.strength,
          workoutBox: Hive.box<StrengthWorkout>('strength_workouts'),
          activityBox: widget.runBox,
        );
        break;
      case app.ActivityType.cycling:
        screen = CyclingWorkoutScreen(
          activityType: app.ActivityType.cycling,
          activityBox: widget.cyclingBox,
        );
        break;
      default:
        screen = const Scaffold(
          body: Center(child: Text('Тип тренировки не поддерживается')),
        );
    }

    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : HomeBodyContent(
            todaySteps: todaySteps,
            todayCalories: todayCalories,
            todayDistanceKm: todayDistanceKm,
            todayMinutes: todayMinutes,
            todayHeartRate: todayHeartRate,
            bodyBatteryLevel: bodyBatteryLevel,
            latestStrength: latestStrength,
            onStartWorkout: _startWorkout,
          );
  }
}
