import 'package:flutter/material.dart';
import 'package:fitness_app/widgets/pulse_chart.dart';
import 'package:fitness_app/services/heart_rate_symulator.dart';
import 'package:fitness_app/screens/heart_rate/daily_heart_rate_screen.dart';

class DailyHeartRateScreen extends StatefulWidget {
  const DailyHeartRateScreen({super.key});

  @override
  State<DailyHeartRateScreen> createState() => _DailyHeartRateScreenState();
}

class _DailyHeartRateScreenState extends State<DailyHeartRateScreen> {
  late List<int> _pulseSeries;
  late DateTime _selectedDate;

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
    _pulseSeries = generateDailyHeartRateSeries(date: _selectedDate);
  }

  void _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _pulseSeries = generateDailyHeartRateSeries(date: picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('💓 Пульс за день'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: _pickDate,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              'Дата: ${_selectedDate.toLocal().toString().split(' ')[0]}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: PulseChart(pulseSeries: _pulseSeries),
            ),
          ],
        ),
      ),
    );
  }
}
