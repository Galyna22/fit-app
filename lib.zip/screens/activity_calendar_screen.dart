import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/screens/activity_screen.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

class ActivityCalendarScreen extends StatefulWidget {
  final Box<RunActivity> activityBox;
  final DatabaseHelper dbHelper;

  const ActivityCalendarScreen({
    super.key,
    required this.activityBox,
    required this.dbHelper,
  });

  @override
  State<ActivityCalendarScreen> createState() => _ActivityCalendarScreenState();
}

class _ActivityCalendarScreenState extends State<ActivityCalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
  }

  List<RunActivity> _getActivitiesForDay(DateTime day) {
    final dateOnly = DateTime(day.year, day.month, day.day);
    return widget.activityBox.values.where((a) {
      final aDate = DateTime(a.date.year, a.date.month, a.date.day);
      return aDate == dateOnly;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final activities = _getActivitiesForDay(_selectedDay!);

    return Scaffold(
      appBar: AppBar(
        title: const Text('📆 Календарь активности'),
      ),
      body: Column(
        children: [
          TableCalendar(
            locale: 'ru_RU',
            firstDay: DateTime(2020),
            lastDay: DateTime.now().add(const Duration(days: 365)),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onDaySelected: (selected, focused) {
              setState(() {
                _selectedDay = selected;
                _focusedDay = focused;
              });
            },
            calendarStyle: const CalendarStyle(
              todayDecoration: BoxDecoration(
                  color: Colors.blueAccent, shape: BoxShape.circle),
              selectedDecoration: BoxDecoration(
                  color: Colors.deepOrange, shape: BoxShape.circle),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: activities.isEmpty
                ? const Center(child: Text('Нет тренировок в выбранный день'))
                : ListView.builder(
                    itemCount: activities.length,
                    itemBuilder: (context, index) {
                      final a = activities[index];
                      return ListTile(
                        title: Text(
                          '${a.distance.toStringAsFixed(2)} км • ${a.formattedDuration}',
                        ),
                        subtitle: Text(
                          '${DateFormat('HH:mm').format(a.date)} | Пульс: ${a.avgHeartRate.toStringAsFixed(0)}',
                        ),
                        leading: const Icon(Icons.directions_run),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ActivityScreen(
                                dbHelper: widget.dbHelper,
                                activityBox: widget.activityBox,
                                filterDate: _selectedDay,
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
