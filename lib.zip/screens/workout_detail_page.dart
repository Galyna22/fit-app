import 'package:flutter/material.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:intl/intl.dart';

class WorkoutDetailPage extends StatelessWidget {
  final Workout workout;
  final DatabaseHelper? dbHelper;

  const WorkoutDetailPage({
    super.key,
    required this.workout,
    this.dbHelper,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(DateFormat.yMMMd().format(workout.date)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailItem('Duration', workout.formattedDuration),
            _buildDetailItem(
                'Distance', '${workout.distanceKm.toStringAsFixed(2)} km'),
            _buildDetailItem('Steps', workout.steps.toString()),
            _buildDetailItem('Calories', '${workout.calories} kcal'),
            if (workout.avgHeartRate != null)
              _buildDetailItem('Avg Heart Rate', '${workout.avgHeartRate} BPM'),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }
}
