import 'package:flutter/material.dart';
import 'package:logger/logger.dart';

class DashboardScreen extends StatefulWidget {
  final Color color1;
  final Color color2;
  final Color color3;
  final Color color4;
  final String metricType;
  final String metricCount1;

  const DashboardScreen({
    super.key,
    required this.color1,
    required this.color2,
    required this.color3,
    required this.color4,
    required this.metricType,
    required this.metricCount1,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final Logger _logger = Logger(
    printer: PrettyPrinter(
      methodCount: 0,
      errorMethodCount: 5,
      lineLength: 50,
      colors: true,
      printEmojis: true,
      noBoxingByDefault: true,
    ),
    filter: ProductionFilter(),
  );

  @override
  void initState() {
    super.initState();
    _logger.i(
        'DashboardScreen initialized - metricType: ${widget.metricType}, metricCount: ${widget.metricCount1}');
  }

  @override
  Widget build(BuildContext context) {
    _logger.d('DashboardScreen rebuild triggered');
    return Container(
      color: widget.color1,
      width: double.infinity,
      height: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '${widget.metricType}: ${widget.metricCount1}',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            width: 100,
            height: 100,
            color: widget.color2,
          ),
          const SizedBox(height: 20),
          Text(
            'Colors: Red, Yellow',
            style: TextStyle(
              fontSize: 16,
              color: widget.color3,
              backgroundColor: widget.color4,
            ),
          ),
        ],
      ),
    );
  }
}
