import 'package:flutter/material.dart';
import 'package:fitness_app/data/strength_set.dart';
import 'package:fitness_app/widgets/heart_rate_chart.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';
import 'package:fitness_app/utils/log_service.dart';

class StrengthResultScreen extends StatelessWidget {
  final List<StrengthSet> sets;
  final List<int> pulseSeries;
  final int avgHeartRate;
  final int maxHeartRate;
  final Map<String, double> heartRateZones;
  final int hrv;

  const StrengthResultScreen({
    super.key,
    required this.sets,
    required this.pulseSeries,
    required this.avgHeartRate,
    required this.maxHeartRate,
    required this.heartRateZones,
    required this.hrv,
  });

  @override
  Widget build(BuildContext context) {
    LogService.info(
      '📊 Строим StrengthResultScreen. Подходов: ${sets.length}',
      tag: 'UI',
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("📊 Завершено ${sets.length} подходов"),
          duration: const Duration(seconds: 2),
        ),
      );
      LogService.info(
        '🎉 SnackBar показан с результатом: ${sets.length} подходов',
        tag: 'UI',
      );
    });

    final analysis =
        pulseSeries.length >= 5 ? analyzeHeartRate(data: pulseSeries) : null;

    return Scaffold(
      appBar: AppBar(title: const Text("📊 Результаты силы")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            _section('💪 Подходы (${sets.length})'),
            ...sets.map((s) => ListTile(
                  title: Text("${s.exercise} — ${s.reps} повторов"),
                  subtitle: Text(
                    "Пульс: ${s.heartRate} | ${s.timestamp.toLocal().toString().substring(0, 16)}",
                  ),
                )),
            const SizedBox(height: 16),
            _section('💓 Пульсовая статистика'),
            _stat('Ср. пульс', '$avgHeartRate bpm'),
            _stat('Макс. пульс', '$maxHeartRate bpm'),
            _stat('HRV (вариабельность)', '$hrv ms'), // ✅ HRV встроен тут
            if (heartRateZones.isNotEmpty) ...[
              const SizedBox(height: 8),
              ...heartRateZones.entries
                  .map((e) => _stat(e.key, '${e.value.toStringAsFixed(1)}%')),
            ],
            if (analysis != null) ...[
              const SizedBox(height: 24),
              HeartRateChart(
                pulseSeries: pulseSeries,
                analysis: analysis,
              )
            ],
            const SizedBox(height: 32),
            ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Закрыть'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );

  Widget _section(String title) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      );
}
