import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:uuid/uuid.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/activity_type.dart' as app;
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/models/gps_point.dart';
import 'package:fitness_app/screens/training/new_cycling_result_screen.dart';
import 'package:fitness_app/services/heart_rate_provider_manager.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';
import 'package:fitness_app/utils/log_service.dart';

// импорты (оставляем как есть — они у тебя корректные)

// импорты (оставляем как есть — они у тебя корректные)

class CyclingWorkoutScreen extends StatefulWidget {
  final app.ActivityType activityType;
  final Box<CyclingActivity> activityBox;

  const CyclingWorkoutScreen({
    super.key,
    required this.activityType,
    required this.activityBox,
  });

  @override
  State<CyclingWorkoutScreen> createState() => _CyclingWorkoutScreenState();
}

class _CyclingWorkoutScreenState extends State<CyclingWorkoutScreen> {
  final Stopwatch _stopwatch = Stopwatch();
  final List<List<double>> _gpsTrack = [];
  final List<int> _pulseSeries = [];

  StreamSubscription<Position>? _positionStream;
  StreamSubscription<int>? _heartRateSub;
  Timer? _uiTimer;

  int currentPulse = 125;
  bool isCycling = false;

  @override
  void initState() {
    super.initState();
    LogService.info('🚴 Старт велотренировки', tag: 'LIFECYCLE');
    _initLocation();
    _initHeartRate();
    _startUiTimer();
  }

  void _initLocation() async {
    final permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always) {
      _positionStream = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 5,
        ),
      ).listen((pos) {
        _gpsTrack.add([pos.latitude, pos.longitude]);
      });
    }
  }

  void _initHeartRate() async {
    final provider = await HeartRateProviderManager.selectProvider();
    _heartRateSub = provider.getStream().listen((hr) {
      currentPulse = hr;
      _pulseSeries.add(hr);
      if (isCycling) setState(() {});
    });
  }

  void _startUiTimer() {
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_stopwatch.isRunning) setState(() {});
    });
  }

  void _startStop() {
    setState(() {
      if (_stopwatch.isRunning) {
        _stopwatch.stop();
        isCycling = false;
      } else {
        _stopwatch.start();
        isCycling = true;
      }
    });
  }

  void _finishWorkout() async {
    final elapsed = _stopwatch.elapsed;
    final durationSec = elapsed.inSeconds;
    final distanceKm = (_gpsTrack.length / 40).clamp(0.2, 50.0);
    final speedKmh = distanceKm / (elapsed.inMinutes / 60.0 + 0.1);
    final analysis = analyzeHeartRate(data: _pulseSeries);

    final ftp = 230.0;
    final avgPower = speedKmh * 8.0;
    final normalizedPower = speedKmh * 9.5;
    final intensityFactor = normalizedPower / ftp;
    final tss =
        (durationSec * normalizedPower * intensityFactor) / (ftp * 3600) * 100;

    final workout = WorkoutModel(
      id: const Uuid().v4(),
      date: DateTime.now(),
      activityType: 'cycling',
      steps: 0,
      distance: distanceKm,
      durationSeconds: durationSec,
      calories: (durationSec * 0.12).round(),
      avgHeartRate: analysis.avg.toDouble(),
      maxHeartRate: analysis.max,
      hrv: analysis.hrv ?? 0,
      avgSpeed: speedKmh,
      maxSpeed: speedKmh + Random().nextDouble() * 3,
      avgPace: (durationSec / (distanceKm * 60 + 0.1)).round(),
      maxPace: (durationSec / ((distanceKm - 0.1) * 60 + 0.1)).round(),
      cadenceSpm: 85,
      strideLengthM: null,
      elevationGainM: 12.0,
      elevationLossM: 11.0,
      groundContactTimeMs: null,
      verticalOscillationCm: null,
      recoveryTimeHr: 10.0,
      vo2Max: 47.5,
      temperatureC: 20.0,
      trainingLoad: 42.0,
      strideSymmetry: null,
      stressLevel: 3,
      spo2: 98.0,
      heartRateZones: {
        for (final z in analysis.zones) z.name: z.percent.toDouble(),
      },
      pulseSeries: _pulseSeries,
      gpsTrack: _gpsTrack,
      recoveryHeartRate: analysis.recovery ?? 0,
      ftp: ftp,
      avgPower: avgPower,
      normalizedPower: normalizedPower,
      tss: tss,
      ctl: null,
      atl: null,
      tsb: null,
    );

    final gpsPoints = _gpsTrack
        .map((e) => GpsPoint(
              lat: e[0],
              lng: e[1],
              timestamp: DateTime.now(),
            ))
        .toList();

    final activity = CyclingActivity(
      date: DateTime.now(),
      durationSeconds: durationSec,
      distance: distanceKm,
      avgSpeed: speedKmh,
      maxSpeed: speedKmh + Random().nextDouble() * 3,
      calories: durationSec * 0.12,
      avgHeartRate: analysis.avg.toDouble(),
      maxHeartRate: analysis.max.toDouble(),
      hrv: (analysis.hrv ?? 0).toDouble(),
      pulseSeries: _pulseSeries,
      heartRateZones: {
        for (final z in analysis.zones) z.name: z.percent.round(),
      },
      gpsTrack: gpsPoints,
      vo2Max: 47.5,
      recoveryHeartRate: analysis.recovery ?? 0,
      ftp: ftp,
      avgPower: avgPower,
      normalizedPower: normalizedPower,
      intensityFactor: intensityFactor,
      tss: tss,
      type: widget.activityType,
    );

    await Hive.box<WorkoutModel>('workouts').add(workout);
    await widget.activityBox.add(activity);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => CyclingResultScreen(runData: workout),
      ),
    );
  }

  String _format(Duration d) {
    final min = d.inMinutes.toString().padLeft(2, '0');
    final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$min:$sec';
  }

  @override
  void dispose() {
    _stopwatch.stop();
    _positionStream?.cancel();
    _heartRateSub?.cancel();
    _uiTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = _stopwatch.elapsed;

    return Scaffold(
      appBar: AppBar(title: const Text('🚴 Велотренировка')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 32),
            Text(_format(elapsed),
                style: Theme.of(context).textTheme.displayLarge),
            const SizedBox(height: 16),
            Text('❤️ $currentPulse bpm',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              icon: Icon(isCycling ? Icons.pause : Icons.play_arrow),
              label: Text(isCycling ? 'Пауза' : 'Старт'),
              onPressed: _startStop,
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Завершить'),
              onPressed: elapsed.inSeconds > 15 ? _finishWorkout : null,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
          ],
        ),
      ),
    );
  }
}
