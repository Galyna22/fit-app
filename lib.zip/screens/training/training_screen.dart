import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/screens/training/new_cycling_workout_screen.dart';

import 'package:fitness_app/data/activity_type.dart' as app;

import 'package:fitness_app/data/run_activity.dart';

class CyclingWorkoutScreen extends StatelessWidget {
  final app.ActivityType activityType;
  final Box<RunActivity> activityBox;

  const CyclingWorkoutScreen({
    super.key,
    required this.activityType,
    required this.activityBox,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚴 Велотренировка'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Тип тренировки: ${activityType.name}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            Text(
              'Всего записей: ${activityBox.length}',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 32),
            const Center(
              child: Text(
                'Здесь будет экран велотренировки 🚴‍♂️',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
