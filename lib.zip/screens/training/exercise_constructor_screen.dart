class ExerciseConstructorScreen extends StatefulWidget {
  const ExerciseConstructorScreen({super.key});

  @override
  State<ExerciseConstructorScreen> createState() =>
      _ExerciseConstructorScreenState();
}

class _ExerciseConstructorScreenState extends State<ExerciseConstructorScreen> {
  final nameController = TextEditingController();
  final repsController = TextEditingController();
  final weightController = TextEditingController();
  final heartController = TextEditingController();
  final vo2Controller = TextEditingController();
  final noteController = TextEditingController();

  void saveExercise() {
    final custom = CustomExerciseModel(
      name: nameController.text,
      reps: int.tryParse(repsController.text),
      weight: double.tryParse(weightController.text),
      avgHeartRate: int.tryParse(heartController.text),
      vo2Max: double.tryParse(vo2Controller.text),
      note: noteController.text,
    );
    final json = jsonEncode(custom.toMap());
    print('📦 Exercise saved:\n$json');

    Navigator.pop(context, custom); // отправим назад
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('➕ Добавить упражнение')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Название')),
            TextField(
                controller: repsController,
                decoration: const InputDecoration(labelText: 'Повторения'),
                keyboardType: TextInputType.number),
            TextField(
                controller: weightController,
                decoration: const InputDecoration(labelText: 'Вес, кг'),
                keyboardType: TextInputType.number),
            TextField(
                controller: heartController,
                decoration: const InputDecoration(labelText: 'Средний пульс'),
                keyboardType: TextInputType.number),
            TextField(
                controller: vo2Controller,
                decoration: const InputDecoration(labelText: 'VO₂ Max'),
                keyboardType: TextInputType.number),
            TextField(
                controller: noteController,
                decoration: const InputDecoration(labelText: 'Примечание')),
            const SizedBox(height: 16),
            ElevatedButton(
                onPressed: saveExercise, child: const Text('✅ Сохранить')),
          ],
        ),
      );
}
