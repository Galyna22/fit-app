import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/services/training_load_service.dart';
import 'package:fitness_app/data/metric_descriptions.dart';

class TrainingStatusScreen extends StatelessWidget {
  const TrainingStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = Hive.box<WorkoutModel>('workouts').values.toList();
    final result = TrainingLoadService.calculate(workouts);

    final ctl = result.ctl;
    final atl = result.atl;
    final tsb = result.tsb;

    return Scaffold(
      appBar: AppBar(title: const Text('📊 Тренировочная форма')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _metricCard('CTL', ctl, Colors.blueAccent),
            _metricCard('ATL', atl, Colors.orangeAccent),
            _metricCard('TSB', tsb, tsb >= 0 ? Colors.green : Colors.redAccent),
            const SizedBox(height: 24),
            const Text(
              '🧠 Что это значит?',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            _description('CTL'),
            _description('ATL'),
            _description('TSB'),
          ],
        ),
      ),
    );
  }

  Widget _metricCard(String label, double value, Color color) {
    return Card(
      color: color.withOpacity(0.1),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color, child: Text(label)),
        title: Text('$label: ${value.toStringAsFixed(1)}'),
      ),
    );
  }

  Widget _description(String key) {
    final text = metricDescriptions[key] ?? '–';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('• ', style: TextStyle(fontSize: 20)),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
