import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/services/weekly_exercise_stats_service.dart';
import 'package:fitness_app/widgets/weekly_exercise_stats_widget.dart';

class ExerciseStatsScreen extends StatelessWidget {
  const ExerciseStatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = Hive.box<WorkoutModel>('workouts').values.toList();
    final weeklyStats = WeeklyExerciseStatsService.groupByWeek(workouts);

    return Scaffold(
      appBar: AppBar(title: const Text('📊 Статистика по упражнениям')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          WeeklyExerciseStatsWidget(weeklyStats: weeklyStats),
        ],
      ),
    );
  }
}
