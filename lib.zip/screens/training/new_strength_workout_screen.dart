import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/activity_type.dart';

import 'package:fitness_app/data/activity_type.dart' as app;

import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/strength_set.dart';

import 'package:fitness_app/services/heart_rate_provider_manager.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';
import 'package:fitness_app/utils/log_service.dart';
import 'new_strength_result_screen.dart';

class StrengthWorkoutScreen extends StatefulWidget {
  final app.ActivityType activityType;
  final Box<StrengthWorkout> workoutBox;
  final Box<RunActivity> activityBox;

  const StrengthWorkoutScreen({
    super.key,
    required this.activityType,
    required this.workoutBox,
    required this.activityBox,
  });

  @override
  State<StrengthWorkoutScreen> createState() => _StrengthWorkoutScreenState();
}

class _StrengthWorkoutScreenState extends State<StrengthWorkoutScreen> {
  final List<String> _exercises = [
    "Приседания",
    "Отжимания",
    "Подтягивания",
    "Жим лёжа",
  ];

  String _selected = "Приседания";
  final List<StrengthSet> _completedSets = [];

  final List<int> _pulseSeries = [];
  StreamSubscription<int>? _heartRateSub;
  int currentPulse = 110;

  @override
  void initState() {
    super.initState();
    LogService.info(
        '🚀 Открыт экран: StrengthWorkoutScreen (${widget.activityType})',
        tag: 'UI');
    _initHeartRate();
  }

  @override
  void dispose() {
    _heartRateSub?.cancel();
    LogService.info('🛑 Закрыт экран: StrengthWorkoutScreen', tag: 'UI');
    super.dispose();
  }

  void _initHeartRate() async {
    final provider = await HeartRateProviderManager.selectProvider();
    _heartRateSub = provider.getStream().listen((hr) {
      setState(() => currentPulse = hr);
      _pulseSeries.add(hr);
      LogService.info('❤️ Пульс: $hr bpm', tag: 'HEART');
    });
  }

  void _logSet() async {
    int reps = 0;
    final heart = currentPulse;

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Повторы"),
        content: TextField(
          keyboardType: TextInputType.number,
          onChanged: (val) => reps = int.tryParse(val) ?? 0,
          decoration: const InputDecoration(hintText: "Сколько повторов"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              LogService.info('❌ Отмена добавления подхода', tag: 'WORKOUT');
              Navigator.pop(ctx);
            },
            child: const Text("Отмена"),
          ),
          ElevatedButton(
            onPressed: () {
              if (reps > 0) {
                final set = StrengthSet(
                  exercise: _selected,
                  reps: reps,
                  heartRate: heart,
                  timestamp: DateTime.now(),
                );
                LogService.info(
                  '📦 Добавлен подход: $_selected $reps раз, пульс $heart',
                  tag: 'WORKOUT',
                );
                setState(() {
                  _completedSets.add(set);
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("💪 Подход сохранён")),
                );
              } else {
                LogService.warn('⚠️ Недопустимое количество повторов: $reps',
                    tag: 'WORKOUT');
              }
            },
            child: const Text("Сохранить"),
          ),
        ],
      ),
    );
  }

  void _finishWorkout() {
    LogService.info(
        '✅ Завершение тренировки. Всего подходов: ${_completedSets.length}',
        tag: 'WORKOUT');

    final analysis = analyzeHeartRate(data: _pulseSeries);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) {
          LogService.info('🧭 Переход на StrengthResultScreen',
              tag: 'NAVIGATION');
          return StrengthResultScreen(
            sets: _completedSets,
            pulseSeries: _pulseSeries,
            avgHeartRate: analysis.avg.round(),
            maxHeartRate: analysis.max,
            hrv: analysis.hrv ?? 0,
            heartRateZones: {
              for (final zone in analysis.zones) zone.name: zone.percent,
            },
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    LogService.info('🧱 Построение StrengthWorkoutScreen', tag: 'UI');

    return Scaffold(
      appBar: AppBar(
        title: const Text("💪 Силовая тренировка"),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: _completedSets.isEmpty ? null : _finishWorkout,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Text('❤️ $currentPulse bpm',
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selected,
              items: _exercises
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (val) {
                setState(() => _selected = val!);
                LogService.info('🔄 Выбрано упражнение: $_selected', tag: 'UI');
              },
              decoration: const InputDecoration(labelText: "Упражнение"),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _logSet,
              child: const Text("➕ Добавить подход"),
            ),
          ],
        ),
      ),
    );
  }
}
