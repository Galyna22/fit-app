import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:geolocator/geolocator.dart';
import 'package:fitness_app/services/heart_rate_provider_manager.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/screens/training/new_running_result_screen.dart';
import 'package:fitness_app/utils/log_service.dart';

class RunningWorkoutScreen extends StatefulWidget {
  const RunningWorkoutScreen({super.key});

  @override
  State<RunningWorkoutScreen> createState() => _RunningWorkoutScreenState();
}

class _RunningWorkoutScreenState extends State<RunningWorkoutScreen> {
  final Stopwatch _stopwatch = Stopwatch();
  final List<int> _pulseSeries = [];
  final List<List<double>> _gpsTrack = [];

  Timer? _uiTimer;
  StreamSubscription<Position>? _positionStream;
  StreamSubscription<int>? _heartRateSub;

  int currentPulse = 130;
  bool isRunning = false;

  @override
  void initState() {
    super.initState();
    LogService.info('🚀 Открыт экран: RunningWorkoutScreen', tag: 'UI');
    _initLocation();
    _initHeartRate();
    _startUiTimer();
  }

  @override
  void dispose() {
    _uiTimer?.cancel();
    _stopwatch.stop();
    _positionStream?.cancel();
    _heartRateSub?.cancel();
    LogService.info('🛑 Закрыт экран: RunningWorkoutScreen', tag: 'UI');
    super.dispose();
  }

  void _initLocation() async {
    final permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always) {
      _positionStream = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 5,
        ),
      ).listen((pos) {
        final point = [pos.latitude, pos.longitude];
        _gpsTrack.add(point);
        LogService.info('📍 GPS точка: ${point.join(', ')}', tag: 'GPS');
      });
    } else {
      LogService.warn('❌ GPS не разрешён пользователем', tag: 'GPS');
    }
  }

  void _initHeartRate() async {
    final provider = await HeartRateProviderManager.selectProvider();
    _heartRateSub = provider.getStream().listen((hr) {
      currentPulse = hr;
      _pulseSeries.add(hr);
      LogService.info('❤️ Пульс: $hr bpm', tag: 'HEART');
      if (isRunning) setState(() {});
    });
  }

  void _startUiTimer() {
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_stopwatch.isRunning) setState(() {});
    });
  }

  void _startStop() {
    setState(() {
      if (_stopwatch.isRunning) {
        _stopwatch.stop();
        isRunning = false;
        LogService.info('⏸️ Тренировка на паузе', tag: 'WORKOUT');
      } else {
        _stopwatch.start();
        isRunning = true;
        LogService.info('▶️ Тренировка запущена', tag: 'WORKOUT');
      }
    });
  }

  void _confirmStopWorkout() async {
    final action = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Завершить тренировку?'),
        content: const Text('Ты хочешь сохранить пробежку или удалить её?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'cancel'),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'delete'),
            child: const Text('Удалить'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, 'save'),
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );

    if (action == 'delete') {
      LogService.warn('🗑 Удалена пробежка до сохранения', tag: 'WORKOUT');
      Navigator.pop(context);
    } else if (action == 'save') {
      _saveWorkout();
    }
  }

  void _saveWorkout() {
    final durationSec = _stopwatch.elapsed.inSeconds;
    final distanceKm = (_stopwatch.elapsed.inMinutes * 0.1);
    final speed = distanceKm / (_stopwatch.elapsed.inMinutes / 60.0 + 0.1);
    final analysis = analyzeHeartRate(data: _pulseSeries);

    final workout = WorkoutModel(
      id: const Uuid().v4(),
      activityType: 'run',
      date: DateTime.now(),
      steps: (_stopwatch.elapsed.inMinutes * 140).round(),
      distance: distanceKm,
      durationSeconds: durationSec,
      avgHeartRate: analysis.avg.toDouble(),
      calories: (durationSec * 0.14).round(),
      maxHeartRate: analysis.max,
      hrv: analysis.hrv ?? 0,
      avgSpeed: speed,
      maxSpeed: speed + Random().nextDouble(),
      avgPace: (durationSec / (distanceKm * 60 + 0.1)).round(),
      maxPace: (durationSec / ((distanceKm - 0.1) * 60 + 0.1)).round(),
      cadenceSpm: 160,
      strideLengthM: 1.0,
      elevationGainM: 2.5,
      elevationLossM: 2.0,
      groundContactTimeMs: 240,
      verticalOscillationCm: 7.3,
      recoveryTimeHr: 12.0,
      vo2Max: 42,
      temperatureC: 18.5,
      trainingLoad: 38.0,
      strideSymmetry: 49.5,
      stressLevel: 2,
      spo2: 97.0,
      heartRateZones: {
        for (final zone in analysis.zones) zone.name: zone.percent,
      },
      pulseSeries: _pulseSeries,
      gpsTrack: _gpsTrack,
    );

    LogService.info(
      '✅ Тренировка сохранена: ${durationSec}s, ${distanceKm.toStringAsFixed(2)} км, GPS точек: ${_gpsTrack.length}',
      tag: 'WORKOUT',
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) {
          LogService.info('🧭 Переход на RunResultScreen', tag: 'NAVIGATION');
          return NewRunResultScreen(runData: workout);
        },
      ),
    );
  }

  String _format(Duration d) {
    final min = d.inMinutes.toString().padLeft(2, '0');
    final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$min:$sec';
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = _stopwatch.elapsed;
    LogService.info('🧱 Построение RunningWorkoutScreen: ${_format(elapsed)}',
        tag: 'UI');

    return Scaffold(
      appBar: AppBar(title: const Text('🏃 Бег')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const SizedBox(height: 32),
            Text(_format(elapsed),
                style: Theme.of(context).textTheme.displayLarge),
            const SizedBox(height: 16),
            Text('❤️ $currentPulse bpm',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  icon: Icon(isRunning ? Icons.pause : Icons.play_arrow),
                  label: Text(isRunning ? 'Пауза' : 'Старт'),
                  onPressed: _startStop,
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  icon: const Icon(Icons.stop),
                  label: const Text('Стоп'),
                  onPressed: _confirmStopWorkout,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            ),
            const Spacer(),
            ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Сохранить тренировку'),
              onPressed: elapsed.inSeconds > 10 ? _saveWorkout : null,
              style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50)),
            ),
          ],
        ),
      ),
    );
  }
}
