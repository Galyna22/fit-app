import 'dart:math';
import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import 'package:fitness_app/models/unified_workout.dart';
import 'package:fitness_app/services/unified_workout_extractor.dart';
import 'package:fitness_app/data/activity_type.dart';

class ActivitySummaryScreen extends StatelessWidget {
  const ActivitySummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = UnifiedWorkoutExtractor.extractAll();

    // ✅ ПРАВИЛЬНО: сначала модель, потом ключ для группировки
    final grouped = groupBy<UnifiedWorkout, ActivityType>(
        workouts, (w) => w.type);

    return Scaffold(
      appBar: AppBar(title: const Text('📊 Сводка по активностям')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: grouped.entries.map((entry) {
          final ActivityType type = entry.key;
          final List<UnifiedWorkout> group = entry.value;

          final totalMinutes =
              group.fold<double>(0, (sum, w) => sum + w.durationSeconds / 60);

          final avgHR = group
                  .where((w) => w.avgHeartRate != null)
                  .map((w) => w.avgHeartRate!)
                  .fold<double>(0, (sum, hr) => sum + hr) /
              max(1, group.where((w) => w.avgHeartRate != null).length);

          final avgTSS = group
                  .where((w) => w.tss != null)
                  .map((w) => w.tss!)
                  .fold<double>(0, (sum, tss) => sum + tss) /
              max(1, group.where((w) => w.tss != null).length);

          final totalDistance = group
              .where((w) => w.distanceKm != null)
              .fold<double>(0, (sum, w) => sum + w.distanceKm!);

          return Card(
            child: ListTile(
              leading: Icon(type.icon),
              title: Text('${type.displayName} (${group.length} тренировок)'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('⏱ Всего: ${totalMinutes.toStringAsFixed(1)} мин'),
                  if (totalDistance > 0)
                    Text(
                        '📍 Дистанция: ${totalDistance.toStringAsFixed(2)} км'),
                  Text('❤️ Средний пульс: ${avgHR.toStringAsFixed(1)} bpm'),
                  Text('📊 Средняя нагрузка TSS: ${avgTSS.toStringAsFixed(1)}'),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
