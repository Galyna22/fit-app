import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/widgets/heart_rate_chart.dart';
import 'package:fitness_app/widgets/workout_map_view.dart';
import 'package:fitness_app/services/heart_rate_analyzer.dart';

class NewRunResultScreen extends StatelessWidget {
  final WorkoutModel runData;
  const NewRunResultScreen({super.key, required this.runData});

  @override
  Widget build(BuildContext context) {
    final dateFormatted = DateFormat.yMMMd().format(runData.date);

    return Scaffold(
      appBar: AppBar(title: Text('🏁 Результат — $dateFormatted')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            _sectionTitle(context, '📊 Общая статистика'),
            _stat('👣 Шаги', '${runData.steps}'),
            _stat(
                '📏 Дистанция', '${runData.distanceKm.toStringAsFixed(2)} км'),
            _stat('⏱ Время', runData.formattedDuration),
            _stat('🔥 Калории', '${runData.calories} kcal'),
            _stat('💓 Пульс (ср/макс)',
                '${runData.avgHeartRate ?? '—'} / ${runData.maxHeartRate ?? '—'} bpm'),
            _stat('💨 VO₂ Max', '${runData.vo2Max ?? '—'}'),
            const SizedBox(height: 12),
            _sectionTitle(context, '🚀 Скорость и темп'),
            _stat('🏃‍♂️ Темп',
                '${runData.paceMinPerKm.toStringAsFixed(2)} min/km'),
            _stat('🚀 Ср. скорость',
                '${runData.avgSpeedKmh.toStringAsFixed(2)} км/ч'),
            _stat('⚡ Макс. скорость',
                '${runData.maxSpeedKmh.toStringAsFixed(2)} км/ч'),
            const SizedBox(height: 12),
            _sectionTitle(context, '🦿 Биомеханика'),
            _stat('🔁 Cadence',
                runData.cadenceSpm != null ? '${runData.cadenceSpm} spm' : '—'),
            _stat(
                '🦶 Длина шага',
                runData.strideLengthM != null
                    ? '${runData.strideLengthM!.toStringAsFixed(2)} м'
                    : '—'),
            _stat('⛰ Подъём',
                '${runData.elevationGainM?.toStringAsFixed(2) ?? '—'} м'),
            _stat(
                '📉 Контакт с землёй',
                runData.groundContactTimeMs != null
                    ? '${runData.groundContactTimeMs} мс'
                    : '—'),
            _stat(
                '📈 Осцилляция',
                runData.verticalOscillationCm != null
                    ? '${runData.verticalOscillationCm!.toStringAsFixed(1)} см'
                    : '—'),
            _stat(
                '⚖️ Симметрия шага',
                runData.strideSymmetry != null
                    ? '${runData.strideSymmetry}%'
                    : '—'),
            const SizedBox(height: 12),
            _sectionTitle(context, '🧠 Физиология'),
            _stat(
                '⏳ Время восстановления',
                runData.recoveryTimeHr != null
                    ? '${runData.recoveryTimeHr} ч'
                    : '—'),
            _stat(
                '📊 Нагрузка',
                runData.trainingLoad != null
                    ? runData.trainingLoad!.toStringAsFixed(1)
                    : '—'),
            _stat(
                '🌡 Температура',
                runData.temperatureC != null
                    ? '${runData.temperatureC} °C'
                    : '—'),
            _stat(
                '😣 Стресс',
                runData.stressLevel != null
                    ? '${runData.stressLevel}/100'
                    : '—'),
            _stat('🩸 SpO₂', runData.spo2 != null ? '${runData.spo2}%' : '—'),
            const SizedBox(height: 20),
            if ((runData.pulseSeries?.length ?? 0) >= 5) ...[
              _sectionTitle(context, '💓 Динамика пульса'),
              HeartRateChart(
                pulseSeries: runData.pulseSeries!,
                analysis: analyzeHeartRate(data: runData.pulseSeries!),
              )
            ],
            const SizedBox(height: 20),
            if ((runData.heartRateZones?.entries ?? []).isNotEmpty) ...[
              _sectionTitle(context, '💡 Зоны пульса'),
              ...runData.heartRateZones!.entries
                  .map((e) => _stat(e.key, '${e.value.toStringAsFixed(1)}%')),
            ],
            const SizedBox(height: 24),
            if ((runData.gpsTrack?.length ?? 0) >= 2) ...[
              _sectionTitle(context, '🗺 Маршрут'),
              WorkoutMapView(gpsTrack: runData.gpsTrack!),
            ],
            const SizedBox(height: 32),
            ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Закрыть'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );

  Widget _sectionTitle(BuildContext context, String title) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 4),
        child: Text(title, style: Theme.of(context).textTheme.titleMedium),
      );
}
