import 'dart:math';
import 'package:flutter/material.dart';
import 'package:collection/collection.dart';
import 'package:fitness_app/models/unified_workout.dart';
import 'package:fitness_app/services/unified_workout_extractor.dart';
import 'package:fitness_app/data/activity_type.dart';

class ActivityFeedScreen extends StatelessWidget {
  const ActivityFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final allWorkouts = UnifiedWorkoutExtractor.extractAll();

    // ✅ ИСПРАВЛЕНИЕ: правильный порядок дженериков
    final grouped =
        groupBy<UnifiedWorkout, ActivityType>(allWorkouts, (w) => w.type);

    return Scaffold(
      appBar: AppBar(title: const Text('📦 Лента тренировок')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: grouped.entries.map((entry) {
          final ActivityType type = entry.key;
          final List<UnifiedWorkout> workouts = entry.value;

          final totalMinutes = workouts.fold<double>(
              0, (sum, w) => sum + w.durationSeconds / 60);

          final avgHR = workouts
                  .where((w) => w.avgHeartRate != null)
                  .map((w) => w.avgHeartRate!)
                  .fold<double>(0, (sum, hr) => sum + hr) /
              max(1, workouts.where((w) => w.avgHeartRate != null).length);

          final avgTSS = workouts
                  .where((w) => w.tss != null)
                  .map((w) => w.tss!)
                  .fold<double>(0, (sum, tss) => sum + tss) /
              max(1, workouts.where((w) => w.tss != null).length);

          final totalDistance = workouts
              .where((w) => w.distanceKm != null)
              .fold<double>(0, (sum, w) => sum + w.distanceKm!);

          return Card(
            child: ListTile(
              leading: Icon(type.icon),
              title:
                  Text('${type.displayName} (${workouts.length} тренировок)'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('⏱ Всего: ${totalMinutes.toStringAsFixed(1)} мин'),
                  if (totalDistance > 0)
                    Text(
                        '📍 Дистанция: ${totalDistance.toStringAsFixed(2)} км'),
                  Text('❤️ Средний пульс: ${avgHR.toStringAsFixed(1)} bpm'),
                  Text('📊 Средняя нагрузка TSS: ${avgTSS.toStringAsFixed(1)}'),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
