import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fitness_app/data/workout_model.dart';

class CyclingResultScreen extends StatelessWidget {
  final WorkoutModel runData;

  const CyclingResultScreen({super.key, required this.runData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🚴 Результат велотренировки')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _row('📅 Дата', DateFormat('dd.MM.yyyy HH:mm').format(runData.date)),
          _row('⏱️ Длительность', runData.formattedDuration),
          _row('📏 Расстояние',
              '${runData.distance?.toStringAsFixed(2) ?? '–'} км'),
          _row('🔥 Калории', '${runData.calories} ккал'),
          _row('💓 Средний пульс', '${runData.avgHeartRate ?? "-"} bpm'),
          _row('💥 Макс. пульс', '${runData.maxHeartRate ?? "-"} bpm'),
          _row('🚴 Ср. скорость',
              '${runData.avgSpeed?.toStringAsFixed(1) ?? "-"} км/ч'),
          _row('🚴 Макс. скорость',
              '${runData.maxSpeed?.toStringAsFixed(1) ?? "-"} км/ч'),
          _row('📈 Нагрузка',
              '${runData.trainingLoad?.toStringAsFixed(1) ?? "-"}'),
          _row('🫁 VO₂ max',
              '${runData.vo2Max?.toStringAsFixed(1) ?? "-"} мл/кг/мин'),
          _row('🌡 Температура',
              '${runData.temperatureC?.toStringAsFixed(1) ?? "-"} °C'),
          _row('🧘 Recovery Time',
              '${runData.recoveryTimeHr?.toStringAsFixed(1) ?? "-"} ч'),
          _row('📊 Stress Level', '${runData.stressLevel ?? "-"}'),
          _row('🩸 SPO2', '${runData.spo2?.toStringAsFixed(1) ?? "-"} %'),
          _row('⛰️ Набор высоты',
              '${runData.elevationGainM?.toStringAsFixed(0) ?? "-"} м'),
          _row('⛰️ Потеря высоты',
              '${runData.elevationLossM?.toStringAsFixed(0) ?? "-"} м'),
          _row('🚶 Каденс', '${runData.cadenceSpm ?? "-"} спм'),
          if (runData.hrv != null)
            _row('⚡ HRV', '${runData.hrv!.toString()} мс'),
          if (runData.recoveryHeartRate != null)
            _row('🔄 Восстановление',
                '${runData.recoveryHeartRate!.toString()} bpm'),
          const SizedBox(height: 12),
          const Text('📌 Зоны пульса:',
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...?runData.heartRateZones?.entries.map(
            (e) => _row(e.key, '${e.value.toStringAsFixed(1)} %'),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
