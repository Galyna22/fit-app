import 'package:flutter/material.dart';
import 'package:fitness_app/data/workout_model.dart';

class WorkoutDetailScreen extends StatelessWidget {
  final WorkoutModel workout;
  const WorkoutDetailScreen({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('📊 Подробности тренировки')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _infoTile('Тип активности', workout.activityType.toUpperCase()),
          _infoTile('Дата', workout.date.toLocal().toString().substring(0, 16)),
          _infoTile('Длительность',
              '${(workout.durationSeconds / 60).toStringAsFixed(0)} мин'),
          _infoTile('Пульс',
              'Средний: ${workout.avgHeartRate?.toStringAsFixed(1) ?? '--'} bpm\nМаксимальный: ${workout.maxHeartRate?.toStringAsFixed(1) ?? '--'} bpm'),
          _infoTile('TSS', workout.tss?.toStringAsFixed(1) ?? '--'),
          _infoTile('VO₂ max', workout.vo2Max?.toStringAsFixed(1) ?? '--'),
          _infoTile('SpO₂', '${workout.spo2?.toStringAsFixed(1) ?? '--'} %'),
          _infoTile('Стресс уровень', workout.stressLevel?.toString() ?? '--'),
          _infoTile('Калории', '${workout.calories}'),
          _infoTile('Упражнения', workout.exercises?.join(' + ') ?? '—'),
          if ((workout.pulseSeries ?? []).isNotEmpty)
            _infoTile(
              'Серийный пульс',
              '${(workout.pulseSeries ?? []).take(5).join(', ')}...',
            ),
          if ((workout.gpsTrack ?? []).isNotEmpty)
            _infoTile(
              'GPS Трек',
              'Точек: ${(workout.gpsTrack ?? []).length}',
            ),
        ],
      ),
    );
  }

  Widget _infoTile(String title, String subtitle) {
    return Card(
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
      ),
    );
  }
}
