import 'package:flutter/material.dart';

class SleepDetailsScreen extends StatelessWidget {
  final double lightSleepHours;
  final double deepSleepHours;
  final double remSleepHours;

  const SleepDetailsScreen({
    super.key,
    required this.lightSleepHours,
    required this.deepSleepHours,
    required this.remSleepHours,
  });

  String _getSleepRecommendation() {
    if (deepSleepHours < 1.5) {
      return "Попробуйте ложиться спать раньше и избегать экранов перед сном.";
    } else if (remSleepHours < 1) {
      return "Может помочь медитация или расслабляющая музыка перед сном.";
    } else {
      return "Ваш сон выглядит сбалансированным. Продолжайте придерживаться режима!";
    }
  }

  Widget _buildSleepPhase(
      String label, double value, double maxValue, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: ${value.toStringAsFixed(1)} / $maxValue',
            style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: value / maxValue,
          backgroundColor: Colors.grey[300],
          valueColor: AlwaysStoppedAnimation<Color>(color),
          minHeight: 8,
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Детали сна')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Фазы сна',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildSleepPhase('Легкий сон', lightSleepHours, 5, Colors.blue),
            _buildSleepPhase('Глубокий сон', deepSleepHours, 2, Colors.green),
            _buildSleepPhase('REM-сон', remSleepHours, 2, Colors.red),
            const SizedBox(height: 20),
            Text('Рекомендации',
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(_getSleepRecommendation(),
                style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
