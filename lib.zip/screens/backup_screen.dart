import 'package:flutter/material.dart';
import 'package:fitness_app/services/backup_service.dart';

class BackupScreen extends StatelessWidget {
  final BackupService backupService;

  const BackupScreen({super.key, required this.backupService});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Backup & Restore')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () async {
                try {
                  await backupService.exportToJson();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Backup created successfully!')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Backup failed: $e')),
                  );
                }
              },
              child: const Text('Create Backup'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // TODO: Реализовать восстановление
              },
              child: const Text('Restore from Backup'),
            ),
          ],
        ),
      ),
    );
  }
}
