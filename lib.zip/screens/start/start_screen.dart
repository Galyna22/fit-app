import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

// 📦 Модели активности
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/activity_type.dart' as app;

// 🔧 Экраны активности
import 'package:fitness_app/screens/training/new_running_workout_screen.dart';
import 'package:fitness_app/screens/training/new_cycling_workout_screen.dart';
import 'package:fitness_app/screens/training/new_strength_workout_screen.dart';

// 📊 Главный UI
import 'package:fitness_app/screens/home/widgets/home_body_content.dart';

class StartScreen extends StatelessWidget {
  final StrengthWorkout? latestStrength;
  final void Function(Object type) onStartWorkout;

  const StartScreen({
    super.key,
    required this.latestStrength,
    required this.onStartWorkout,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Моя тренировка'),
        centerTitle: true,
        actions: const [
          // 💓 Тут можно вернуть пульс-иконку позже
          // TodayHeartRateBadge(rate: 72),
        ],
      ),
      body: HomeBodyContent(
        todaySteps: 6420,
        todayCalories: 356,
        todayDistanceKm: 4.3,
        todayMinutes: 24,
        todayHeartRate: 72,
        bodyBatteryLevel: 75.0,
        latestStrength: latestStrength,
        onStartWorkout: onStartWorkout,
      ),
    );
  }
}
