import 'package:hive/hive.dart';

part 'custom_exercise_model.g.dart';

@HiveType(typeId: 3)
class CustomExerciseModel {
  @HiveField(0)
  final String name;

  @HiveField(1)
  final int? reps;

  @HiveField(2)
  final double? weight;

  @HiveField(3)
  final int? durationSeconds;

  @HiveField(4)
  final int? avgHeartRate;

  @HiveField(5)
  final double? vo2Max;

  @HiveField(6)
  final String? note;

  CustomExerciseModel({
    required this.name,
    this.reps,
    this.weight,
    this.durationSeconds,
    this.avgHeartRate,
    this.vo2Max,
    this.note,
  });

  Map<String, dynamic> toMap() => {
        'name': name,
        'reps': reps,
        'weight': weight,
        'durationSeconds': durationSeconds,
        'avgHeartRate': avgHeartRate,
        'vo2Max': vo2Max,
        'note': note,
      };

  static CustomExerciseModel fromMap(Map<String, dynamic> map) =>
      CustomExerciseModel(
        name: map['name'],
        reps: map['reps'],
        weight: (map['weight'] as num?)?.toDouble(),
        durationSeconds: map['durationSeconds'],
        avgHeartRate: map['avgHeartRate'],
        vo2Max: (map['vo2Max'] as num?)?.toDouble(),
        note: map['note'],
      );
}
