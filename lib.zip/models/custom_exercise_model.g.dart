// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'custom_exercise_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CustomExerciseModelAdapter extends TypeAdapter<CustomExerciseModel> {
  @override
  final int typeId = 3;

  @override
  CustomExerciseModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CustomExerciseModel(
      name: fields[0] as String,
      reps: fields[1] as int?,
      weight: fields[2] as double?,
      durationSeconds: fields[3] as int?,
      avgHeartRate: fields[4] as int?,
      vo2Max: fields[5] as double?,
      note: fields[6] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, CustomExerciseModel obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.name)
      ..writeByte(1)
      ..write(obj.reps)
      ..writeByte(2)
      ..write(obj.weight)
      ..writeByte(3)
      ..write(obj.durationSeconds)
      ..writeByte(4)
      ..write(obj.avgHeartRate)
      ..writeByte(5)
      ..write(obj.vo2Max)
      ..writeByte(6)
      ..write(obj.note);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomExerciseModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
