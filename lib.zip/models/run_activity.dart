import 'package:hive/hive.dart';
import 'package:fitness_app/models/gps_point.dart';
import 'package:fitness_app/data/activity_type.dart' as app; // ✅ с префиксом


@HiveField(27)
final app.ActivityType type;



@HiveType(typeId: 3)
class RunActivity extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final int steps;

  @HiveField(3)
  final double distance;

  @HiveField(4)
  final int durationSeconds;

  @HiveField(5)
  final double caloriesBurned;

  @HiveField(6)
  final double avgHeartRate;

  @HiveField(7)
  final double maxHeartRate;

  @HiveField(8)
  final Map<String, int> heartRateZones;

  @HiveField(9)
  final double paceMinPerKm;

  @HiveField(10)
  final double avgSpeed;

  @HiveField(11)
  final double maxSpeed;

  @HiveField(12)
  final int cadence;

  @HiveField(13)
  final double strideLength;

  @HiveField(14)
  final double elevationGain;

  @HiveField(15)
  final double elevationLoss;

  @HiveField(16)
  final List<GpsPoint> gpsTrack;

  @HiveField(17)
  final int groundContactTime;

  @HiveField(18)
  final double verticalOscillation;

  @HiveField(19)
  final double vo2Max;

  @HiveField(20)
  final int recoveryTime;

  @HiveField(21)
  final double trainingLoad;

  @HiveField(22)
  final double strideSymmetry;

  @HiveField(23)
  final double temperature;

  @HiveField(24)
  final double stressLevel;

  @HiveField(25)
  final double spo2;

  @HiveField(26)
  final DateTime updatedAt;

  @HiveField(27)
  final ActivityType type; // ❗️без префикса — чтобы Hive сгенерировал адаптер

  RunActivity({
    required this.id,
    required this.date,
    required this.steps,
    required this.distance,
    required this.durationSeconds,
    required this.caloriesBurned,
    required this.avgHeartRate,
    required this.maxHeartRate,
    required this.heartRateZones,
    required this.paceMinPerKm,
    required this.avgSpeed,
    required this.maxSpeed,
    required this.cadence,
    required this.strideLength,
    required this.elevationGain,
    required this.elevationLoss,
    required this.gpsTrack,
    required this.groundContactTime,
    required this.verticalOscillation,
    required this.vo2Max,
    required this.recoveryTime,
    required this.trainingLoad,
    required this.strideSymmetry,
    required this.temperature,
    required this.stressLevel,
    required this.spo2,
    required this.type,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? date;

  factory RunActivity.fromV1(Map<String, dynamic> json) {
    return RunActivity(
      id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      date: DateTime.parse(json['date']),
      steps: json['steps'] ?? 0,
      distance: (json['distance'] as num?)?.toDouble() ?? 0,
      durationSeconds: json['durationSeconds'] ?? 0,
      caloriesBurned: (json['caloriesBurned'] as num?)?.toDouble() ?? 0,
      avgHeartRate: (json['avgHeartRate'] as num?)?.toDouble() ?? 0,
      maxHeartRate: (json['maxHeartRate'] as num?)?.toDouble() ?? 0,
      heartRateZones: Map<String, int>.from(json['heartRateZones'] ?? {}),
      paceMinPerKm: (json['paceMinPerKm'] as num?)?.toDouble() ?? 0,
      avgSpeed: (json['avgSpeed'] as num?)?.toDouble() ?? 0,
      maxSpeed: (json['maxSpeed'] as num?)?.toDouble() ?? 0,
      cadence: json['cadence'] ?? 0,
      strideLength: (json['strideLength'] as num?)?.toDouble() ?? 0,
      elevationGain: (json['elevationGain'] as num?)?.toDouble() ?? 0,
      elevationLoss: (json['elevationLoss'] as num?)?.toDouble() ?? 0,
      gpsTrack: (json['gpsTrack'] as List? ?? [])
          .map((e) => GpsPoint.fromJson(e))
          .toList(),
      groundContactTime: json['groundContactTime'] ?? 0,
      verticalOscillation:
          (json['verticalOscillation'] as num?)?.toDouble() ?? 0,
      vo2Max: (json['vo2Max'] as num?)?.toDouble() ?? 0,
      recoveryTime: json['recoveryTime'] ?? 0,
      trainingLoad: (json['trainingLoad'] as num?)?.toDouble() ?? 0,
      strideSymmetry: (json['strideSymmetry'] as num?)?.toDouble() ?? 50,
      temperature: (json['temperature'] as num?)?.toDouble() ?? 20,
      stressLevel: (json['stressLevel'] as num?)?.toDouble() ?? 0,
      spo2: (json['spo2'] as num?)?.toDouble() ?? 98,
      type: ActivityType.running, // ✅ без префикса
      updatedAt: DateTime.parse(
        json['updatedAt'] ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'steps': steps,
        'distance': distance,
        'durationSeconds': durationSeconds,
        'caloriesBurned': caloriesBurned,
        'avgHeartRate': avgHeartRate,
        'maxHeartRate': maxHeartRate,
        'heartRateZones': heartRateZones,
        'paceMinPerKm': paceMinPerKm,
        'avgSpeed': avgSpeed,
        'maxSpeed': maxSpeed,
        'cadence': cadence,
        'strideLength': strideLength,
        'elevationGain': elevationGain,
        'elevationLoss': elevationLoss,
        'gpsTrack': gpsTrack.map((e) => e.toJson()).toList(),
        'groundContactTime': groundContactTime,
        'verticalOscillation': verticalOscillation,
        'vo2Max': vo2Max,
        'recoveryTime': recoveryTime,
        'trainingLoad': trainingLoad,
        'strideSymmetry': strideSymmetry,
        'temperature': temperature,
        'stressLevel': stressLevel,
        'spo2': spo2,
        'type': type.name,
        'updatedAt': updatedAt.toIso8601String(),
      };

  String get formattedDuration {
    final duration = Duration(seconds: durationSeconds);
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '$minutes мин $seconds сек';
  }
}
