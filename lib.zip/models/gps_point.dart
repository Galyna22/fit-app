import 'package:hive/hive.dart';
import 'package:fitness_app/constants/hive_type_ids.dart';

part 'gps_point.g.dart';

@HiveType(typeId: HiveTypeIds.gpsPoint)
class GpsPoint extends HiveObject {
  @HiveField(0)
  final double lat;

  @HiveField(1)
  final double lng;

  @HiveField(2)
  final DateTime timestamp;

  GpsPoint({
    required this.lat,
    required this.lng,
    required this.timestamp,
  });

  factory GpsPoint.fromJson(Map<String, dynamic> json) => GpsPoint(
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        timestamp: DateTime.parse(json['timestamp']),
      );

  Map<String, dynamic> toJson() => {
        'lat': lat,
        'lng': lng,
        'timestamp': timestamp.toIso8601String(),
      };
}
