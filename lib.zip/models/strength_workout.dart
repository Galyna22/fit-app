import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive/hive.dart';

part 'strength_workout.freezed.dart';
part 'strength_workout.g.dart';

@freezed
@HiveType(typeId: 1)
class StrengthWorkout with _$StrengthWorkout {
  const factory StrengthWorkout({
    @HiveField(0) required String id,
    @HiveField(1) required DateTime date,
    @HiveField(2) required String exercise,
    @HiveField(3) required int sets,
    @HiveField(4) required int repsPlanned,
    @HiveField(5) required int repsActual,
    @HiveField(6) required double weight,
    @HiveField(7) required int heartRate,
    @HiveField(8) required int durationSeconds,
    @HiveField(9) List<int>? pulseSeries,
    @HiveField(10) int? maxHeartRate,
    @HiveField(11) int? avgHeartRate,
    @HiveField(12) int? restBetweenSetsSec,
    @HiveField(13) String? notes,
  }) = _StrengthWorkout;

  factory StrengthWorkout.fromJson(Map<String, dynamic> json) =>
      _$StrengthWorkoutFromJson(json);
}
