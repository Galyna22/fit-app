import 'package:fitness_app/data/activity_type.dart';

class UnifiedWorkout {
  final DateTime date;
  final ActivityType type;
  final int durationSeconds;
  final double? distanceKm;
  final double? avgHeartRate;
  final double? tss;

  UnifiedWorkout({
    required this.date,
    required this.type,
    required this.durationSeconds,
    this.distanceKm,
    this.avgHeartRate,
    this.tss,
  });
}
