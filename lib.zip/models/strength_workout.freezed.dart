// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'strength_workout.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

StrengthWorkout _$StrengthWorkoutFromJson(Map<String, dynamic> json) {
  return _StrengthWorkout.fromJson(json);
}

/// @nodoc
mixin _$StrengthWorkout {
  @HiveField(0)
  String get id => throw _privateConstructorUsedError;
  @HiveField(1)
  DateTime get date => throw _privateConstructorUsedError;
  @HiveField(2)
  String get exercise => throw _privateConstructorUsedError;
  @HiveField(3)
  int get sets => throw _privateConstructorUsedError;
  @HiveField(4)
  int get repsPlanned => throw _privateConstructorUsedError;
  @HiveField(5)
  int get repsActual => throw _privateConstructorUsedError;
  @HiveField(6)
  double get weight => throw _privateConstructorUsedError;
  @HiveField(7)
  int get heartRate => throw _privateConstructorUsedError;
  @HiveField(8)
  int get durationSeconds => throw _privateConstructorUsedError;
  @HiveField(9)
  List<int>? get pulseSeries => throw _privateConstructorUsedError;
  @HiveField(10)
  int? get maxHeartRate => throw _privateConstructorUsedError;
  @HiveField(11)
  int? get avgHeartRate => throw _privateConstructorUsedError;
  @HiveField(12)
  int? get restBetweenSetsSec => throw _privateConstructorUsedError;
  @HiveField(13)
  String? get notes => throw _privateConstructorUsedError;

  /// Serializes this StrengthWorkout to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of StrengthWorkout
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $StrengthWorkoutCopyWith<StrengthWorkout> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StrengthWorkoutCopyWith<$Res> {
  factory $StrengthWorkoutCopyWith(
          StrengthWorkout value, $Res Function(StrengthWorkout) then) =
      _$StrengthWorkoutCopyWithImpl<$Res, StrengthWorkout>;
  @useResult
  $Res call(
      {@HiveField(0) String id,
      @HiveField(1) DateTime date,
      @HiveField(2) String exercise,
      @HiveField(3) int sets,
      @HiveField(4) int repsPlanned,
      @HiveField(5) int repsActual,
      @HiveField(6) double weight,
      @HiveField(7) int heartRate,
      @HiveField(8) int durationSeconds,
      @HiveField(9) List<int>? pulseSeries,
      @HiveField(10) int? maxHeartRate,
      @HiveField(11) int? avgHeartRate,
      @HiveField(12) int? restBetweenSetsSec,
      @HiveField(13) String? notes});
}

/// @nodoc
class _$StrengthWorkoutCopyWithImpl<$Res, $Val extends StrengthWorkout>
    implements $StrengthWorkoutCopyWith<$Res> {
  _$StrengthWorkoutCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of StrengthWorkout
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? date = null,
    Object? exercise = null,
    Object? sets = null,
    Object? repsPlanned = null,
    Object? repsActual = null,
    Object? weight = null,
    Object? heartRate = null,
    Object? durationSeconds = null,
    Object? pulseSeries = freezed,
    Object? maxHeartRate = freezed,
    Object? avgHeartRate = freezed,
    Object? restBetweenSetsSec = freezed,
    Object? notes = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as DateTime,
      exercise: null == exercise
          ? _value.exercise
          : exercise // ignore: cast_nullable_to_non_nullable
              as String,
      sets: null == sets
          ? _value.sets
          : sets // ignore: cast_nullable_to_non_nullable
              as int,
      repsPlanned: null == repsPlanned
          ? _value.repsPlanned
          : repsPlanned // ignore: cast_nullable_to_non_nullable
              as int,
      repsActual: null == repsActual
          ? _value.repsActual
          : repsActual // ignore: cast_nullable_to_non_nullable
              as int,
      weight: null == weight
          ? _value.weight
          : weight // ignore: cast_nullable_to_non_nullable
              as double,
      heartRate: null == heartRate
          ? _value.heartRate
          : heartRate // ignore: cast_nullable_to_non_nullable
              as int,
      durationSeconds: null == durationSeconds
          ? _value.durationSeconds
          : durationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      pulseSeries: freezed == pulseSeries
          ? _value.pulseSeries
          : pulseSeries // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      maxHeartRate: freezed == maxHeartRate
          ? _value.maxHeartRate
          : maxHeartRate // ignore: cast_nullable_to_non_nullable
              as int?,
      avgHeartRate: freezed == avgHeartRate
          ? _value.avgHeartRate
          : avgHeartRate // ignore: cast_nullable_to_non_nullable
              as int?,
      restBetweenSetsSec: freezed == restBetweenSetsSec
          ? _value.restBetweenSetsSec
          : restBetweenSetsSec // ignore: cast_nullable_to_non_nullable
              as int?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StrengthWorkoutImplCopyWith<$Res>
    implements $StrengthWorkoutCopyWith<$Res> {
  factory _$$StrengthWorkoutImplCopyWith(_$StrengthWorkoutImpl value,
          $Res Function(_$StrengthWorkoutImpl) then) =
      __$$StrengthWorkoutImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@HiveField(0) String id,
      @HiveField(1) DateTime date,
      @HiveField(2) String exercise,
      @HiveField(3) int sets,
      @HiveField(4) int repsPlanned,
      @HiveField(5) int repsActual,
      @HiveField(6) double weight,
      @HiveField(7) int heartRate,
      @HiveField(8) int durationSeconds,
      @HiveField(9) List<int>? pulseSeries,
      @HiveField(10) int? maxHeartRate,
      @HiveField(11) int? avgHeartRate,
      @HiveField(12) int? restBetweenSetsSec,
      @HiveField(13) String? notes});
}

/// @nodoc
class __$$StrengthWorkoutImplCopyWithImpl<$Res>
    extends _$StrengthWorkoutCopyWithImpl<$Res, _$StrengthWorkoutImpl>
    implements _$$StrengthWorkoutImplCopyWith<$Res> {
  __$$StrengthWorkoutImplCopyWithImpl(
      _$StrengthWorkoutImpl _value, $Res Function(_$StrengthWorkoutImpl) _then)
      : super(_value, _then);

  /// Create a copy of StrengthWorkout
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? date = null,
    Object? exercise = null,
    Object? sets = null,
    Object? repsPlanned = null,
    Object? repsActual = null,
    Object? weight = null,
    Object? heartRate = null,
    Object? durationSeconds = null,
    Object? pulseSeries = freezed,
    Object? maxHeartRate = freezed,
    Object? avgHeartRate = freezed,
    Object? restBetweenSetsSec = freezed,
    Object? notes = freezed,
  }) {
    return _then(_$StrengthWorkoutImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as DateTime,
      exercise: null == exercise
          ? _value.exercise
          : exercise // ignore: cast_nullable_to_non_nullable
              as String,
      sets: null == sets
          ? _value.sets
          : sets // ignore: cast_nullable_to_non_nullable
              as int,
      repsPlanned: null == repsPlanned
          ? _value.repsPlanned
          : repsPlanned // ignore: cast_nullable_to_non_nullable
              as int,
      repsActual: null == repsActual
          ? _value.repsActual
          : repsActual // ignore: cast_nullable_to_non_nullable
              as int,
      weight: null == weight
          ? _value.weight
          : weight // ignore: cast_nullable_to_non_nullable
              as double,
      heartRate: null == heartRate
          ? _value.heartRate
          : heartRate // ignore: cast_nullable_to_non_nullable
              as int,
      durationSeconds: null == durationSeconds
          ? _value.durationSeconds
          : durationSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      pulseSeries: freezed == pulseSeries
          ? _value._pulseSeries
          : pulseSeries // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      maxHeartRate: freezed == maxHeartRate
          ? _value.maxHeartRate
          : maxHeartRate // ignore: cast_nullable_to_non_nullable
              as int?,
      avgHeartRate: freezed == avgHeartRate
          ? _value.avgHeartRate
          : avgHeartRate // ignore: cast_nullable_to_non_nullable
              as int?,
      restBetweenSetsSec: freezed == restBetweenSetsSec
          ? _value.restBetweenSetsSec
          : restBetweenSetsSec // ignore: cast_nullable_to_non_nullable
              as int?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StrengthWorkoutImpl implements _StrengthWorkout {
  const _$StrengthWorkoutImpl(
      {@HiveField(0) required this.id,
      @HiveField(1) required this.date,
      @HiveField(2) required this.exercise,
      @HiveField(3) required this.sets,
      @HiveField(4) required this.repsPlanned,
      @HiveField(5) required this.repsActual,
      @HiveField(6) required this.weight,
      @HiveField(7) required this.heartRate,
      @HiveField(8) required this.durationSeconds,
      @HiveField(9) final List<int>? pulseSeries,
      @HiveField(10) this.maxHeartRate,
      @HiveField(11) this.avgHeartRate,
      @HiveField(12) this.restBetweenSetsSec,
      @HiveField(13) this.notes})
      : _pulseSeries = pulseSeries;

  factory _$StrengthWorkoutImpl.fromJson(Map<String, dynamic> json) =>
      _$$StrengthWorkoutImplFromJson(json);

  @override
  @HiveField(0)
  final String id;
  @override
  @HiveField(1)
  final DateTime date;
  @override
  @HiveField(2)
  final String exercise;
  @override
  @HiveField(3)
  final int sets;
  @override
  @HiveField(4)
  final int repsPlanned;
  @override
  @HiveField(5)
  final int repsActual;
  @override
  @HiveField(6)
  final double weight;
  @override
  @HiveField(7)
  final int heartRate;
  @override
  @HiveField(8)
  final int durationSeconds;
  final List<int>? _pulseSeries;
  @override
  @HiveField(9)
  List<int>? get pulseSeries {
    final value = _pulseSeries;
    if (value == null) return null;
    if (_pulseSeries is EqualUnmodifiableListView) return _pulseSeries;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @HiveField(10)
  final int? maxHeartRate;
  @override
  @HiveField(11)
  final int? avgHeartRate;
  @override
  @HiveField(12)
  final int? restBetweenSetsSec;
  @override
  @HiveField(13)
  final String? notes;

  @override
  String toString() {
    return 'StrengthWorkout(id: $id, date: $date, exercise: $exercise, sets: $sets, repsPlanned: $repsPlanned, repsActual: $repsActual, weight: $weight, heartRate: $heartRate, durationSeconds: $durationSeconds, pulseSeries: $pulseSeries, maxHeartRate: $maxHeartRate, avgHeartRate: $avgHeartRate, restBetweenSetsSec: $restBetweenSetsSec, notes: $notes)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StrengthWorkoutImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.exercise, exercise) ||
                other.exercise == exercise) &&
            (identical(other.sets, sets) || other.sets == sets) &&
            (identical(other.repsPlanned, repsPlanned) ||
                other.repsPlanned == repsPlanned) &&
            (identical(other.repsActual, repsActual) ||
                other.repsActual == repsActual) &&
            (identical(other.weight, weight) || other.weight == weight) &&
            (identical(other.heartRate, heartRate) ||
                other.heartRate == heartRate) &&
            (identical(other.durationSeconds, durationSeconds) ||
                other.durationSeconds == durationSeconds) &&
            const DeepCollectionEquality()
                .equals(other._pulseSeries, _pulseSeries) &&
            (identical(other.maxHeartRate, maxHeartRate) ||
                other.maxHeartRate == maxHeartRate) &&
            (identical(other.avgHeartRate, avgHeartRate) ||
                other.avgHeartRate == avgHeartRate) &&
            (identical(other.restBetweenSetsSec, restBetweenSetsSec) ||
                other.restBetweenSetsSec == restBetweenSetsSec) &&
            (identical(other.notes, notes) || other.notes == notes));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      date,
      exercise,
      sets,
      repsPlanned,
      repsActual,
      weight,
      heartRate,
      durationSeconds,
      const DeepCollectionEquality().hash(_pulseSeries),
      maxHeartRate,
      avgHeartRate,
      restBetweenSetsSec,
      notes);

  /// Create a copy of StrengthWorkout
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$StrengthWorkoutImplCopyWith<_$StrengthWorkoutImpl> get copyWith =>
      __$$StrengthWorkoutImplCopyWithImpl<_$StrengthWorkoutImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StrengthWorkoutImplToJson(
      this,
    );
  }
}

abstract class _StrengthWorkout implements StrengthWorkout {
  const factory _StrengthWorkout(
      {@HiveField(0) required final String id,
      @HiveField(1) required final DateTime date,
      @HiveField(2) required final String exercise,
      @HiveField(3) required final int sets,
      @HiveField(4) required final int repsPlanned,
      @HiveField(5) required final int repsActual,
      @HiveField(6) required final double weight,
      @HiveField(7) required final int heartRate,
      @HiveField(8) required final int durationSeconds,
      @HiveField(9) final List<int>? pulseSeries,
      @HiveField(10) final int? maxHeartRate,
      @HiveField(11) final int? avgHeartRate,
      @HiveField(12) final int? restBetweenSetsSec,
      @HiveField(13) final String? notes}) = _$StrengthWorkoutImpl;

  factory _StrengthWorkout.fromJson(Map<String, dynamic> json) =
      _$StrengthWorkoutImpl.fromJson;

  @override
  @HiveField(0)
  String get id;
  @override
  @HiveField(1)
  DateTime get date;
  @override
  @HiveField(2)
  String get exercise;
  @override
  @HiveField(3)
  int get sets;
  @override
  @HiveField(4)
  int get repsPlanned;
  @override
  @HiveField(5)
  int get repsActual;
  @override
  @HiveField(6)
  double get weight;
  @override
  @HiveField(7)
  int get heartRate;
  @override
  @HiveField(8)
  int get durationSeconds;
  @override
  @HiveField(9)
  List<int>? get pulseSeries;
  @override
  @HiveField(10)
  int? get maxHeartRate;
  @override
  @HiveField(11)
  int? get avgHeartRate;
  @override
  @HiveField(12)
  int? get restBetweenSetsSec;
  @override
  @HiveField(13)
  String? get notes;

  /// Create a copy of StrengthWorkout
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$StrengthWorkoutImplCopyWith<_$StrengthWorkoutImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
