import 'package:hive_flutter/hive_flutter.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/settings_model.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/settings_model.dart';
import 'package:fitness_app/data/activity_type.dart';

void initHiveAdapters() {
  if (!Hive.isAdapterRegistered(5)) {
    Hive.registerAdapter(ActivityTypeAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(SettingsModelAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(WorkoutModelAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(CalendarEntryAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(RunActivityAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(CyclingActivityAdapter());
  }
  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(ActivityTypeAdapter());
  }
}
