import 'dart:io';

void main() async {
  final libDir = Directory('lib');

  if (!libDir.existsSync()) {
    print('❌ lib/ папка не найдена.');
    return;
  }

  final allDartFiles = libDir
      .listSync(recursive: true)
      .whereType<File>()
      .where((f) => f.path.endsWith('.dart'))
      .where((f) =>
          !f.path.contains(RegExp(r'_test\.dart|g\.dart')) &&
          !f.path.contains('main.dart') &&
          !f.path.contains('hive_initializer.dart'));

  final referencedFiles = <String>{};

  for (final file in allDartFiles) {
    final content = await file.readAsString();
    for (final other in allDartFiles) {
      if (file.path == other.path) continue;
      if (await other.readAsString().then((text) =>
          text.contains(file.uri.pathSegments.last.replaceAll(".dart", "")))) {
        referencedFiles.add(file.path);
        break;
      }
    }
  }

  final unusedFiles = allDartFiles
      .map((f) => f.path)
      .where((path) => !referencedFiles.contains(path))
      .toList();

  print('\n📦 Неиспользуемые файлы Dart в lib/:');
  if (unusedFiles.isEmpty) {
    print('✅ Все файлы используются!');
  } else {
    for (final path in unusedFiles) {
      print('🗑 $path');
    }
    print('\n💡 Проверь файлы вручную перед удалением.');
  }
}
