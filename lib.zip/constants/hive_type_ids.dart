class HiveTypeIds {
  // 🏃‍♂️ Обобщённая модель тренировки (WorkoutAdapter)
  static const workout = 1;

  // 💪 Силовая тренировка (StrengthWorkoutAdapter)
  static const strengthWorkout = 2;

  // 🏃 Пробежка с GPS и биометрией (RunActivityAdapter)
  static const runActivity = 3;

  // 🚴 Велотренировка — watts, cadence и т.д. (CyclingActivityAdapter)
  static const cyclingActivity = 4; // ✅ обновлено

  // 🧭 Тип активности: enum (ActivityTypeAdapter)
  static const activityType = 5;

  // 📍 GPS точка маршрута (GpsPointAdapter)
  static const gpsPoint = 6;

  // 📅 Шаги, пульс, калории по дням (CalendarDataAdapter)
  static const calendarData = 7;
}
