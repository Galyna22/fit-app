// 📦 AppConfig — глобальные флаги конфигурации окружения приложения
abstract class AppConfig {
  // ⚙️ Флаг режима разработчика:
  // true  → показываются логи, dev-фичи, отладочные экраны
  // false → поведение как на продакшене
  static const bool isDeveloperMode =
      true; // Переключить на false для продакшена
}
