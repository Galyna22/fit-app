import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/screens/home/home_screen.dart';
import 'package:fitness_app/services/backup_service.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/run_activity.dart';

class MyFitnessApp extends StatelessWidget {
  final DatabaseHelper dbHelper;
  final BackupService backupService;
  final Box<RunActivity> activityBox;

  const MyFitnessApp({
    super.key,
    required this.dbHelper,
    required this.backupService,
    required this.activityBox,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Fitness App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: HomeScreen(
        dbHelper: dbHelper,
        backupService: backupService,
        activityBox: activityBox,
      ),
    );
  }
}
