// 📦 Централизованный экспорт всех адаптеров Hive.

export 'activity_type_adapter.dart';
export 'calendar_data_adapter.dart';
export 'run_activity_adapter.dart';
export 'strength_workout_adapter.dart';
export 'workout_adapter.dart';
// export 'custom_exercise_model_adapter.dart'; // если используешь
