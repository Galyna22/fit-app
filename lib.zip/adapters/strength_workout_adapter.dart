import 'package:hive/hive.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/constants/hive_type_ids.dart';

class StrengthWorkoutAdapter extends TypeAdapter<StrengthWorkout> {
  @override
  final int typeId = HiveTypeIds.strengthWorkout;

  @override
  StrengthWorkout read(BinaryReader reader) {
    return StrengthWorkout(
      id: reader.readString(),
      date: DateTime.parse(reader.readString()),
      exercise: reader.readString(),
      sets: reader.readInt(),
      repsPlanned: reader.readInt(),
      repsActual: reader.readInt(),
      weight: reader.readDouble(),
      heartRate: reader.readInt(),
      durationSeconds: reader.readInt(),
      pulseSeries: reader.readList().cast<int>(),
      maxHeartRate: reader.readInt(),
      avgHeartRate: reader.readInt(),
      restBetweenSetsSec: reader.readInt(),
      notes: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, StrengthWorkout obj) {
    writer.writeString(obj.id);
    writer.writeString(obj.date.toIso8601String());
    writer.writeString(obj.exercise);
    writer.writeInt(obj.sets);
    writer.writeInt(obj.repsPlanned);
    writer.writeInt(obj.repsActual);
    writer.writeDouble(obj.weight);
    writer.writeInt(obj.heartRate);
    writer.writeInt(obj.durationSeconds);
    writer.writeList(obj.pulseSeries ?? []);
    writer.writeInt(obj.maxHeartRate ?? 0);
    writer.writeInt(obj.avgHeartRate ?? 0);
    writer.writeInt(obj.restBetweenSetsSec ?? 0);
    writer.writeString(obj.notes ?? '');
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is StrengthWorkoutAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
