import 'package:hive/hive.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/models/custom_exercise_model.dart';

class WorkoutAdapter extends TypeAdapter<WorkoutModel> {
  @override
  final int typeId = 1;

  @override
  void write(BinaryWriter writer, WorkoutModel obj) {
    writer
      ..writeString(obj.id)
      ..writeString(obj.date.toIso8601String())
      ..writeInt(obj.steps)
      ..writeDouble(obj.distance)
      ..writeInt(obj.durationSeconds)
      ..writeInt(obj.calories)
      ..writeBool(obj.avgHeartRate != null)
      ..writeInt(obj.avgHeartRate ?? 0)
      ..writeBool(obj.maxHeartRate != null)
      ..writeInt(obj.maxHeartRate ?? 0)
      ..writeBool(obj.vo2Max != null)
      ..writeDouble(obj.vo2Max ?? 0.0)
      ..writeBool(obj.stressLevel != null)
      ..writeInt(obj.stressLevel ?? 0)
      ..writeBool(obj.temperatureC != null)
      ..writeDouble(obj.temperatureC ?? 0.0)
      ..writeBool(obj.spo2 != null)
      ..writeDouble(obj.spo2 ?? 0.0)
      ..writeString(obj.activityType)
      ..writeInt(obj.cadenceSpm ?? 0)
      ..writeDouble(obj.strideLengthM ?? 0.0)
      ..writeDouble(obj.elevationGainM ?? 0.0)
      ..writeDouble(obj.elevationLossM ?? 0.0)
      ..writeInt(obj.groundContactTimeMs ?? 0)
      ..writeDouble(obj.verticalOscillationCm ?? 0.0)
      ..writeDouble(obj.recoveryTimeHr ?? 0.0)
      ..writeDouble(obj.trainingLoad ?? 0.0)
      ..writeDouble(obj.strideSymmetry ?? 0.0)
      ..writeMap(obj.heartRateZones ?? {})
      ..write(obj.pulseSeries)
      ..write(obj.gpsTrack)
      ..write(obj.exercises)
      ..write(obj.customExercises)
      ..writeDouble(obj.tss ?? 0.0); // ← ✅ точка в конце, всё красиво!
  }

  @override
  WorkoutModel read(BinaryReader reader) {
    return WorkoutModel(
      id: reader.readString(),
      date: DateTime.parse(reader.readString()),
      steps: reader.readInt(),
      distance: reader.readDouble(),
      durationSeconds: reader.readInt(),
      calories: reader.readInt(),
      avgHeartRate: reader.readBool() ? reader.readInt() : null,
      maxHeartRate: reader.readBool() ? reader.readInt() : null,
      vo2Max: reader.readBool() ? reader.readDouble() : null,
      stressLevel: reader.readBool() ? reader.readInt() : null,
      temperatureC: reader.readBool() ? reader.readDouble() : null,
      spo2: reader.readBool() ? reader.readDouble() : null,
      activityType: reader.readString(),
      cadenceSpm: reader.readInt(),
      strideLengthM: reader.readDouble(),
      elevationGainM: reader.readDouble(),
      elevationLossM: reader.readDouble(),
      groundContactTimeMs: reader.readInt(),
      verticalOscillationCm: reader.readDouble(),
      recoveryTimeHr: reader.readDouble(),
      trainingLoad: reader.readDouble(),
      strideSymmetry: reader.readDouble(),
      heartRateZones: Map<String, double>.from(reader.readMap() as Map),
      pulseSeries: reader.read() as List<int>?,
      gpsTrack: reader.read() as List<List<double>>?,
      exercises: reader.read() as List<String>?,
      customExercises: reader.read() as List<CustomExerciseModel>?,
      tss: reader.readDouble(),
    );
  }
}
