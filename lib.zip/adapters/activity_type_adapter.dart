import 'package:hive/hive.dart';
import 'package:fitness_app/data/activity_type.dart' as app;

// Адаптер для enum ActivityType, например: running, cycling, walking и т.д.
class ActivityTypeAdapter extends TypeAdapter<app.ActivityType> {
  @override
  final int typeId = 5; // Уникальный typeId согласно HiveTypeIds

  @override
  app.ActivityType read(BinaryReader reader) {
    return app.ActivityType.values[reader.readByte()];
  }

  @override
  void write(BinaryWriter writer, app.ActivityType obj) {
    writer.writeByte(obj.index);
  }
}
