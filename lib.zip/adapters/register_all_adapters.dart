import 'package:hive/hive.dart';

// Модели
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/models/gps_point.dart';

void registerAllAdapters() {
  Hive
    ..registerAdapter(ActivityTypeAdapter())
    ..registerAdapter(CalendarEntryAdapter())
    ..registerAdapter(RunActivityAdapter())
    ..registerAdapter(StrengthWorkoutAdapter())
    ..registerAdapter(CyclingActivityAdapter())
    ..registerAdapter(WorkoutModelAdapter())
    ..registerAdapter(GpsPointAdapter());
}
