import 'package:hive/hive.dart';
import 'package:fitness_app/data/calendar_data.dart'; // ✅ Імпорт моделі

class CalendarDataAdapter extends TypeAdapter<CalendarData> {
  @override
  final int typeId = 7; // Унікальний ID для Hive

  @override
  CalendarData read(BinaryReader reader) {
    final date = DateTime.parse(reader.readString());
    final steps = reader.readInt();
    final heartRate = reader.readDouble();
    final calories = reader.readInt();

    return CalendarData(
      date: date,
      steps: steps,
      heartRate: heartRate,
      calories: calories,
    );
  }

  @override
  void write(BinaryWriter writer, CalendarData obj) {
    writer.writeString(obj.date.toIso8601String());
    writer.writeInt(obj.steps);
    writer.writeDouble(obj.heartRate);
    writer.writeInt(obj.calories);
  }
}
