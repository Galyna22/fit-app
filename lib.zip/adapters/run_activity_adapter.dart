import 'package:hive/hive.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/models/gps_point.dart';
import 'package:fitness_app/data/activity_type.dart';

class RunActivityAdapter extends TypeAdapter<RunActivity> {
  @override
  final int typeId = 3;

  @override
  RunActivity read(BinaryReader reader) {
    return RunActivity(
      id: reader.readString(),
      date: DateTime.parse(reader.readString()),
      steps: reader.readInt(),
      distance: reader.readDouble(),
      durationSeconds: reader.readInt(),
      caloriesBurned: reader.readDouble(),
      avgHeartRate: reader.readDouble(),
      pulseSeries: reader.readList().cast<int>(),
      maxHeartRate: reader.readDouble(),
      heartRateZones: Map<String, int>.from(
        reader.readMap().map((k, v) => MapEntry(k as String, v as int)),
      ),
      paceMinPerKm: reader.readDouble(),
      avgSpeed: reader.readDouble(),
      maxSpeed: reader.readDouble(),
      cadenceSpm: reader.readInt(),
      strideLength: reader.readDouble(),
      elevationGain: reader.readDouble(),
      elevationLoss: reader.readDouble(),
      gpsTrack: (reader.readList() as List).cast<GpsPoint>(),
      groundContactTime: reader.readInt(),
      verticalOscillation: reader.readDouble(),
      vo2Max: reader.readDouble(),
      recoveryTime: reader.readInt(),
      trainingLoad: reader.readDouble(),
      strideSymmetry: reader.readDouble(),
      temperature: reader.readDouble(),
      stressLevel: reader.readDouble(),
      spo2: reader.readDouble(),
      updatedAt: DateTime.parse(reader.readString()),
      type: reader.read() as ActivityType,
    );
  }

  @override
  void write(BinaryWriter writer, RunActivity obj) {
    writer.writeString(obj.id);
    writer.writeString(obj.date.toIso8601String());
    writer.writeInt(obj.steps);
    writer.writeDouble(obj.distance);
    writer.writeInt(obj.durationSeconds);
    writer.writeDouble(obj.caloriesBurned);
    writer.writeDouble(obj.avgHeartRate);
    writer.writeList(obj.pulseSeries);
    writer.writeDouble(obj.maxHeartRate);
    writer.writeMap(obj.heartRateZones);
    writer.writeDouble(obj.paceMinPerKm);
    writer.writeDouble(obj.avgSpeed);
    writer.writeDouble(obj.maxSpeed);
    writer.writeInt(obj.cadenceSpm);
    writer.writeDouble(obj.strideLength);
    writer.writeDouble(obj.elevationGain);
    writer.writeDouble(obj.elevationLoss);
    writer.writeList(obj.gpsTrack);
    writer.writeInt(obj.groundContactTime);
    writer.writeDouble(obj.verticalOscillation);
    writer.writeDouble(obj.vo2Max);
    writer.writeInt(obj.recoveryTime);
    writer.writeDouble(obj.trainingLoad);
    writer.writeDouble(obj.strideSymmetry);
    writer.writeDouble(obj.temperature);
    writer.writeDouble(obj.stressLevel);
    writer.writeDouble(obj.spo2);
    writer.writeString(obj.updatedAt.toIso8601String());
    writer.write(obj.type);
  }
}
