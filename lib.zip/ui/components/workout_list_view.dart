// lib/ui/components/workout_list_view.dart
import 'package:flutter/material.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/ui/components/workout_filter_panel.dart';
import 'package:fitness_app/ui/components/workout_card.dart';

class WorkoutListView extends StatefulWidget {
  final List<WorkoutModel> workouts;

  const WorkoutListView({required this.workouts, super.key});

  @override
  State<WorkoutListView> createState() => _WorkoutListViewState();
}

class _WorkoutListViewState extends State<WorkoutListView> {
  ActivityTypeFilter _selectedFilter = ActivityTypeFilter.all;

  List<WorkoutModel> get filtered {
    return widget.workouts.where((w) {
      return switch (_selectedFilter) {
        ActivityTypeFilter.all => true,
        ActivityTypeFilter.run => w.activityType.toLowerCase() == 'run',
        ActivityTypeFilter.cycling => w.activityType.toLowerCase() == 'cycling',
        ActivityTypeFilter.strength =>
          w.activityType.toLowerCase() == 'strength',
      };
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        WorkoutFilterPanel(
          selected: _selectedFilter,
          onChanged: (filter) => setState(() => _selectedFilter = filter),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (_, index) {
              final workout = filtered[index];
              return WorkoutCard(
                workout: workout,
                onEdit: () {}, // 💡 подключи редактирование
                onDelete: () {}, // 💡 подключи удаление
                onExport: () {}, // 💡 подключи экспорт
              );
            },
          ),
        ),
      ],
    );
  }
}
