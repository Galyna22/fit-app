// lib/ui/components/workout_filter_panel.dart
import 'package:flutter/material.dart';

enum ActivityTypeFilter { all, run, cycling, strength }

class WorkoutFilterPanel extends StatelessWidget {
  final ActivityTypeFilter selected;
  final ValueChanged<ActivityTypeFilter> onChanged;

  const WorkoutFilterPanel({
    required this.selected,
    required this.onChanged,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      children: ActivityTypeFilter.values.map((type) {
        final label = switch (type) {
          ActivityTypeFilter.all => 'Все',
          ActivityTypeFilter.run => 'Бег 🏃‍♂️',
          ActivityTypeFilter.cycling => 'Вело 🚴',
          ActivityTypeFilter.strength => 'Силовая 🏋️',
        };
        return ChoiceChip(
          label: Text(label),
          selected: selected == type,
          onSelected: (_) => onChanged(type),
        );
      }).toList(),
    );
  }
}
