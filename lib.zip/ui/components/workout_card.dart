import 'package:flutter/material.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/data/workout_model.dart';

class WorkoutCard extends StatelessWidget {
  final WorkoutModel workout;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onExport;

  const WorkoutCard({
    required this.workout,
    required this.onEdit,
    required this.onDelete,
    required this.onExport,
    super.key,
  });

  IconData _iconForType(String type) {
    switch (type.toLowerCase()) {
      case 'run':
        return Icons.directions_run;
      case 'cycling':
        return Icons.pedal_bike;
      case 'strength':
        return Icons.fitness_center;
      default:
        return Icons.sports;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey(workout.id),
      background: Container(color: Colors.blue, child: const Icon(Icons.edit)),
      secondaryBackground:
          Container(color: Colors.red, child: const Icon(Icons.delete)),
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          onEdit();
        } else {
          final confirmed = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Удалить тренировку?'),
              content: const Text('Это действие нельзя отменить.'),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Отмена')),
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Удалить')),
              ],
            ),
          );
          if (confirmed == true) onDelete();
        }
        return false;
      },
      child: Card(
        elevation: 2,
        child: ListTile(
          leading: Icon(
            _iconForType(workout.activityType),
            size: 32,
            color: Colors.orange,
          ),
          title: Text(
            '${workout.activityType.toUpperCase()} • ${workout.formattedDuration}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
              '${workout.calories} ккал • ${workout.steps} шагов • ${workout.avgHeartRate ?? '-'} bpm'),
          trailing: IconButton(
            icon: const Icon(Icons.share),
            onPressed: onExport,
            tooltip: 'Экспортировать тренировку',
          ),
          onTap: () {
            // переход на экран детализации (можно реализовать)
          },
        ),
      ),
    );
  }
}
