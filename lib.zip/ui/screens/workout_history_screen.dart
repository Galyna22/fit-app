// lib/ui/screens/workout_history_screen.dart
import 'package:flutter/material.dart';
import 'package:fitness_app/ui/components/workout_list_view.dart';
import 'package:fitness_app/data/workout_model.dart';

class WorkoutHistoryScreen extends StatelessWidget {
  final List<WorkoutModel> workouts;

  const WorkoutHistoryScreen({required this.workouts, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('История тренировок')),
      body: WorkoutListView(workouts: workouts),
    );
  }
}
