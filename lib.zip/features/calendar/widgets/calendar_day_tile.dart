import 'package:flutter/material.dart';
import 'package:fitness_app/data/activity_log_day.dart';

class CalendarDayTile extends StatelessWidget {
  final ActivityLogDay log;

  const CalendarDayTile({super.key, required this.log});

  @override
  Widget build(BuildContext context) {
    final labels = log.activityLabels.join(', ');
    final calories = log.totalCalories;
    final minutes = (log.totalDurationSeconds / 60).round();
    final heartRate = log.avgHeartRate.toStringAsFixed(0);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      elevation: 2,
      child: ListTile(
        title: Text(
          _formatDate(log.date),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '$labels\n🔥 $calories ккал • 🕒 $minutes мин • 🫀 $heartRate уд/мин',
          style: const TextStyle(height: 1.5),
        ),
        leading: const Icon(Icons.fitness_center),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          // 👉 можно открыть экран с деталями дня: log.runs, log.rides и т.д.
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    final weekday =
        ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'][date.weekday - 1];
    return '$weekday, ${date.day}.${date.month}';
  }
}
