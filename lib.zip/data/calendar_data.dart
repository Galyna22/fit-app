class CalendarData {
  final DateTime date;
  final int steps;
  final double heartRate;
  final int calories;

  CalendarData({
    required this.date,
    required this.steps,
    required this.heartRate,
    required this.calories,
  });
}
