class StrengthSet {
  final String exercise;
  final int reps;
  final int heartRate;
  final DateTime timestamp;

  StrengthSet({
    required this.exercise,
    required this.reps,
    required this.heartRate,
    required this.timestamp,
  });
}
