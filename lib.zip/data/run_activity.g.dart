// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'run_activity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class RunActivityAdapter extends TypeAdapter<RunActivity> {
  @override
  final int typeId = 3;

  @override
  RunActivity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RunActivity(
      id: fields[0] as String?,
      pulseSeries: (fields[28] as List?)?.cast<int>(),
      date: fields[1] as DateTime,
      steps: fields[2] as int,
      distance: fields[3] as double,
      durationSeconds: fields[4] as int,
      caloriesBurned: fields[5] as double,
      avgHeartRate: fields[6] as double,
      maxHeartRate: fields[7] as double,
      heartRateZones: (fields[8] as Map).cast<String, int>(),
      paceMinPerKm: fields[9] as double,
      avgSpeed: fields[10] as double,
      maxSpeed: fields[11] as double,
      cadenceSpm: fields[12] as int,
      strideLength: fields[13] as double,
      elevationGain: fields[14] as double,
      elevationLoss: fields[15] as double,
      gpsTrack: (fields[16] as List).cast<GpsPoint>(),
      groundContactTime: fields[17] as int,
      verticalOscillation: fields[18] as double,
      vo2Max: fields[19] as double,
      recoveryTime: fields[20] as int,
      trainingLoad: fields[21] as double,
      strideSymmetry: fields[22] as double,
      temperature: fields[23] as double,
      stressLevel: fields[24] as double,
      spo2: fields[25] as double,
      type: fields[27] as ActivityType,
      updatedAt: fields[26] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, RunActivity obj) {
    writer
      ..writeByte(29)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.steps)
      ..writeByte(3)
      ..write(obj.distance)
      ..writeByte(4)
      ..write(obj.durationSeconds)
      ..writeByte(5)
      ..write(obj.caloriesBurned)
      ..writeByte(6)
      ..write(obj.avgHeartRate)
      ..writeByte(7)
      ..write(obj.maxHeartRate)
      ..writeByte(8)
      ..write(obj.heartRateZones)
      ..writeByte(9)
      ..write(obj.paceMinPerKm)
      ..writeByte(10)
      ..write(obj.avgSpeed)
      ..writeByte(11)
      ..write(obj.maxSpeed)
      ..writeByte(12)
      ..write(obj.cadenceSpm)
      ..writeByte(13)
      ..write(obj.strideLength)
      ..writeByte(14)
      ..write(obj.elevationGain)
      ..writeByte(15)
      ..write(obj.elevationLoss)
      ..writeByte(16)
      ..write(obj.gpsTrack)
      ..writeByte(17)
      ..write(obj.groundContactTime)
      ..writeByte(18)
      ..write(obj.verticalOscillation)
      ..writeByte(19)
      ..write(obj.vo2Max)
      ..writeByte(20)
      ..write(obj.recoveryTime)
      ..writeByte(21)
      ..write(obj.trainingLoad)
      ..writeByte(22)
      ..write(obj.strideSymmetry)
      ..writeByte(23)
      ..write(obj.temperature)
      ..writeByte(24)
      ..write(obj.stressLevel)
      ..writeByte(25)
      ..write(obj.spo2)
      ..writeByte(26)
      ..write(obj.updatedAt)
      ..writeByte(27)
      ..write(obj.type)
      ..writeByte(28)
      ..write(obj.pulseSeries);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RunActivityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
