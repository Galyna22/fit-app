import 'package:hive_flutter/hive_flutter.dart';
import 'package:fitness_app/data/workout_model.dart';

class HiveInit {
  static const String _boxName = 'workouts';

  static Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(WorkoutAdapter());
    await Hive.openBox<Workout>(_boxName);
  }
}
