import 'package:hive/hive.dart';
import 'package:fitness_app/constants/hive_type_ids.dart';

@HiveType(typeId: HiveTypeIds.cyclingActivity)
class CyclingWorkout extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final int durationSeconds;

  @HiveField(3)
  final double distanceKm;

  @HiveField(4)
  final int avgWatts;

  @HiveField(5)
  final int maxWatts;

  @HiveField(6)
  final double normalizedPower;

  @HiveField(7)
  final int cadenceRpm;

  @HiveField(8)
  final double avgSpeedKmh;

  @HiveField(9)
  final double maxSpeedKmh;

  @HiveField(10)
  final double elevationGainM;

  @HiveField(11)
  final double elevationLossM;

  @HiveField(12)
  final double airTempC;

  @HiveField(13)
  final double airPressureMmHg;

  @HiveField(14)
  final double trainingStressScore;

  @HiveField(15)
  final int ftpWatts;

  @HiveField(16)
  final Map<String, double> heartRateZones;

  @HiveField(17)
  final int? recoveryHeartRate;

  @HiveField(18)
  final int? hrv;

  @HiveField(19)
  final double? trainingEffect;

  CyclingWorkout({
    required this.id,
    required this.date,
    required this.durationSeconds,
    required this.distanceKm,
    required this.avgWatts,
    required this.maxWatts,
    required this.normalizedPower,
    required this.cadenceRpm,
    required this.avgSpeedKmh,
    required this.maxSpeedKmh,
    required this.elevationGainM,
    required this.elevationLossM,
    required this.airTempC,
    required this.airPressureMmHg,
    required this.trainingStressScore,
    required this.ftpWatts,
    required this.heartRateZones,
    this.recoveryHeartRate,
    this.hrv,
    this.trainingEffect,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'durationSeconds': durationSeconds,
        'distanceKm': distanceKm,
        'avgWatts': avgWatts,
        'maxWatts': maxWatts,
        'normalizedPower': normalizedPower,
        'cadenceRpm': cadenceRpm,
        'avgSpeedKmh': avgSpeedKmh,
        'maxSpeedKmh': maxSpeedKmh,
        'elevationGainM': elevationGainM,
        'elevationLossM': elevationLossM,
        'airTempC': airTempC,
        'airPressureMmHg': airPressureMmHg,
        'trainingStressScore': trainingStressScore,
        'ftpWatts': ftpWatts,
        'heartRateZones': heartRateZones,
        'recoveryHeartRate': recoveryHeartRate,
        'hrv': hrv,
        'trainingEffect': trainingEffect,
      };

  factory CyclingWorkout.fromJson(Map<String, dynamic> json) => CyclingWorkout(
        id: json['id'],
        date: DateTime.parse(json['date']),
        durationSeconds: json['durationSeconds'],
        distanceKm: (json['distanceKm'] as num).toDouble(),
        avgWatts: json['avgWatts'],
        maxWatts: json['maxWatts'],
        normalizedPower: (json['normalizedPower'] as num).toDouble(),
        cadenceRpm: json['cadenceRpm'],
        avgSpeedKmh: (json['avgSpeedKmh'] as num).toDouble(),
        maxSpeedKmh: (json['maxSpeedKmh'] as num).toDouble(),
        elevationGainM: (json['elevationGainM'] as num).toDouble(),
        elevationLossM: (json['elevationLossM'] as num).toDouble(),
        airTempC: (json['airTempC'] as num).toDouble(),
        airPressureMmHg: (json['airPressureMmHg'] as num).toDouble(),
        trainingStressScore: (json['trainingStressScore'] as num).toDouble(),
        ftpWatts: json['ftpWatts'],
        heartRateZones: Map<String, double>.from(json['heartRateZones']),
        recoveryHeartRate: json['recoveryHeartRate'],
        hrv: json['hrv'],
        trainingEffect: (json['trainingEffect'] as num?)?.toDouble(),
      );
}
