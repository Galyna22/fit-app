// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'strength_workout.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class StrengthWorkoutAdapter extends TypeAdapter<StrengthWorkout> {
  @override
  final int typeId = 41;

  @override
  StrengthWorkout read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return StrengthWorkout(
      id: fields[0] as String?,
      date: fields[1] as DateTime,
      exercise: fields[2] as String,
      sets: fields[3] as int,
      repsPlanned: fields[4] as int,
      repsActual: fields[5] as int,
      weight: fields[6] as double,
      heartRate: fields[7] as int,
      durationSeconds: fields[8] as int,
      pulseSeries: (fields[9] as List?)?.cast<int>(),
      maxHeartRate: fields[10] as int?,
      avgHeartRate: fields[11] as int?,
      restBetweenSetsSec: fields[12] as int?,
      notes: fields[13] as String?,
      hrv: fields[14] as int?,
    );
  }

  @override
  void write(BinaryWriter writer, StrengthWorkout obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.exercise)
      ..writeByte(3)
      ..write(obj.sets)
      ..writeByte(4)
      ..write(obj.repsPlanned)
      ..writeByte(5)
      ..write(obj.repsActual)
      ..writeByte(6)
      ..write(obj.weight)
      ..writeByte(7)
      ..write(obj.heartRate)
      ..writeByte(8)
      ..write(obj.durationSeconds)
      ..writeByte(9)
      ..write(obj.pulseSeries)
      ..writeByte(10)
      ..write(obj.maxHeartRate)
      ..writeByte(11)
      ..write(obj.avgHeartRate)
      ..writeByte(12)
      ..write(obj.restBetweenSetsSec)
      ..writeByte(13)
      ..write(obj.notes)
      ..writeByte(14)
      ..write(obj.hrv);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is StrengthWorkoutAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
