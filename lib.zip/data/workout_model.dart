import 'package:hive/hive.dart';
import 'package:fitness_app/mixins/with_safe_id_mixin.dart';

part 'workout_model.g.dart';

@HiveType(typeId: 2)
class WorkoutModel extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final DateTime date;
  @HiveField(2)
  final int steps;
  @HiveField(3)
  final int calories;
  @HiveField(4)
  final String? notes;
  @HiveField(5)
  final int? heartRate;
  @HiveField(6)
  final List<String>? tags;
  @HiveField(7)
  final String type;
  @HiveField(8)
  final double? distance;
  @HiveField(9)
  final int? durationSeconds;
  @HiveField(10)
  final int? maxHeartRate;
  @HiveField(11)
  final double? avgHeartRate;
  @HiveField(12)
  final int? hrv;
  @HiveField(13)
  final int? recoveryHeartRate;
  @HiveField(14)
  final double? recoveryTimeHr;
  @HiveField(15)
  final double? avgSpeed;
  @HiveField(16)
  final double? maxSpeed;
  @HiveField(17)
  final int? avgPace;
  @HiveField(18)
  final int? maxPace;
  @HiveField(19)
  final int? cadenceSpm;
  @HiveField(20)
  final double? strideLengthM;
  @HiveField(21)
  final double? strideSymmetry;
  @HiveField(22)
  final double? elevationGainM;
  @HiveField(23)
  final double? elevationLossM;
  @HiveField(24)
  final int? groundContactTimeMs;
  @HiveField(25)
  final double? verticalOscillationCm;
  @HiveField(26)
  final double? vo2Max;
  @HiveField(27)
  final double? temperatureC;
  @HiveField(28)
  final double? spo2;
  @HiveField(29)
  final int? stressLevel;
  @HiveField(30)
  final double? trainingLoad;
  @HiveField(31)
  final double? ftp;
  @HiveField(32)
  final double? avgPower;
  @HiveField(33)
  final double? normalizedPower;
  @HiveField(34)
  final double? intensityFactor;
  @HiveField(35)
  final double? tss;
  @HiveField(36)
  final double? ctl;
  @HiveField(37)
  final double? atl;
  @HiveField(38)
  final double? tsb;
  @HiveField(39)
  final List<int>? pulseSeries;
  @HiveField(40)
  final Map<String, double>? heartRateZones;
  @HiveField(41)
  final List<List<double>>? gpsTrack;
  @HiveField(42)
  final String? activityType;

  WorkoutModel({
    String? id,
    required this.date,
    required this.steps,
    required this.calories,
    this.notes,
    this.heartRate,
    this.tags,
    this.type = 'general',
    this.distance,
    this.durationSeconds,
    this.maxHeartRate,
    this.avgHeartRate,
    this.hrv,
    this.recoveryHeartRate,
    this.recoveryTimeHr,
    this.avgSpeed,
    this.maxSpeed,
    this.avgPace,
    this.maxPace,
    this.cadenceSpm,
    this.strideLengthM,
    this.strideSymmetry,
    this.elevationGainM,
    this.elevationLossM,
    this.groundContactTimeMs,
    this.verticalOscillationCm,
    this.vo2Max,
    this.temperatureC,
    this.spo2,
    this.stressLevel,
    this.trainingLoad,
    this.ftp,
    this.avgPower,
    this.normalizedPower,
    this.intensityFactor,
    this.tss,
    this.ctl,
    this.atl,
    this.tsb,
    this.pulseSeries,
    this.heartRateZones,
    this.gpsTrack,
    this.activityType,
  }) : id = WithSafeIdMixin.safeId(id);
  // 📊 Геттеры
  String get formattedDuration {
    final d = Duration(seconds: durationSeconds ?? 0);
    return '${d.inMinutes} мин ${d.inSeconds.remainder(60)} сек';
  }

  double get distanceKm => distance ?? steps / 1320;
  double get maxSpeedKmh => maxSpeed ?? 0.0;
  double get paceMinPerKm =>
      distanceKm < 0.001 ? 0 : (durationSeconds ?? 0) / (distanceKm * 60);
  double get avgSpeedKmh => distanceKm / ((durationSeconds ?? 1) / 3600);
  double get recoveryTimeHrValue => recoveryTimeHr ?? 0;

  // 🔄 JSON сериализация
  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'steps': steps,
        'calories': calories,
        'notes': notes,
        'heartRate': heartRate,
        'tags': tags,
        'type': type,
        'distance': distance,
        'durationSeconds': durationSeconds,
        'maxHeartRate': maxHeartRate,
        'avgHeartRate': avgHeartRate,
        'hrv': hrv,
        'recoveryHeartRate': recoveryHeartRate,
        'recoveryTimeHr': recoveryTimeHr,
        'avgSpeed': avgSpeed,
        'maxSpeed': maxSpeed,
        'avgPace': avgPace,
        'maxPace': maxPace,
        'cadenceSpm': cadenceSpm,
        'strideLengthM': strideLengthM,
        'strideSymmetry': strideSymmetry,
        'elevationGainM': elevationGainM,
        'elevationLossM': elevationLossM,
        'groundContactTimeMs': groundContactTimeMs,
        'verticalOscillationCm': verticalOscillationCm,
        'vo2Max': vo2Max,
        'temperatureC': temperatureC,
        'spo2': spo2,
        'stressLevel': stressLevel,
        'trainingLoad': trainingLoad,
        'ftp': ftp,
        'avgPower': avgPower,
        'normalizedPower': normalizedPower,
        'intensityFactor': intensityFactor,
        'tss': tss,
        'ctl': ctl,
        'atl': atl,
        'tsb': tsb,
        'pulseSeries': pulseSeries,
        'heartRateZones': heartRateZones,
        'gpsTrack': gpsTrack,
        'activityType': activityType,
      };

  factory WorkoutModel.fromJson(Map<String, dynamic> json) => WorkoutModel(
        id: json['id'],
        date: DateTime.parse(json['date']),
        steps: json['steps'],
        calories: json['calories'],
        notes: json['notes'],
        heartRate: json['heartRate'],
        tags: (json['tags'] as List?)?.map((e) => e.toString()).toList(),
        type: json['type'] ?? 'general',
        distance: (json['distance'] as num?)?.toDouble(),
        durationSeconds: json['durationSeconds'],
        maxHeartRate: json['maxHeartRate'],
        avgHeartRate: (json['avgHeartRate'] as num?)?.toDouble(),
        hrv: json['hrv'],
        recoveryHeartRate: json['recoveryHeartRate'],
        recoveryTimeHr: (json['recoveryTimeHr'] as num?)?.toDouble(),
        avgSpeed: (json['avgSpeed'] as num?)?.toDouble(),
        maxSpeed: (json['maxSpeed'] as num?)?.toDouble(),
        avgPace: json['avgPace'],
        maxPace: json['maxPace'],
        cadenceSpm: json['cadenceSpm'],
        strideLengthM: (json['strideLengthM'] as num?)?.toDouble(),
        strideSymmetry: (json['strideSymmetry'] as num?)?.toDouble(),
        elevationGainM: (json['elevationGainM'] as num?)?.toDouble(),
        elevationLossM: (json['elevationLossM'] as num?)?.toDouble(),
        groundContactTimeMs: json['groundContactTimeMs'],
        verticalOscillationCm:
            (json['verticalOscillationCm'] as num?)?.toDouble(),
        vo2Max: (json['vo2Max'] as num?)?.toDouble(),
        temperatureC: (json['temperatureC'] as num?)?.toDouble(),
        spo2: (json['spo2'] as num?)?.toDouble(),
        stressLevel: json['stressLevel'],
        trainingLoad: (json['trainingLoad'] as num?)?.toDouble(),
        ftp: (json['ftp'] as num?)?.toDouble(),
        avgPower: (json['avgPower'] as num?)?.toDouble(),
        normalizedPower: (json['normalizedPower'] as num?)?.toDouble(),
        intensityFactor: (json['intensityFactor'] as num?)?.toDouble(),
        tss: (json['tss'] as num?)?.toDouble(),
        ctl: (json['ctl'] as num?)?.toDouble(),
        atl: (json['atl'] as num?)?.toDouble(),
        tsb: (json['tsb'] as num?)?.toDouble(),
        pulseSeries:
            (json['pulseSeries'] as List?)?.map((e) => e as int).toList(),
        heartRateZones: (json['heartRateZones'] as Map?)?.map(
          (k, v) => MapEntry(k.toString(), (v as num).toDouble()),
        ),
        gpsTrack: (json['gpsTrack'] as List?)
            ?.map((e) => List<double>.from(e))
            .toList(),
        activityType: json['activityType'],
      );
}
