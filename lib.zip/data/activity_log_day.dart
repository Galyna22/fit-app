import 'package:hive/hive.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/workout_model.dart';

part 'activity_log_day.g.dart';

@HiveType(typeId: 99)
class ActivityLogDay extends HiveObject {
  @HiveField(0)
  final DateTime date;

  @HiveField(1)
  final List<RunActivity> runs;

  @HiveField(2)
  final List<CyclingActivity> rides;

  @HiveField(3)
  final List<StrengthWorkout> strength;

  @HiveField(4)
  final List<WorkoutModel> workouts;

  ActivityLogDay({
    required this.date,
    this.runs = const [],
    this.rides = const [],
    this.strength = const [],
    this.workouts = const [],
  });

  // ✅ Суммарные калории
  int get totalCalories {
    final runCal = runs.fold<double>(0, (sum, r) => sum + r.caloriesBurned);
    final rideCal = rides.fold<double>(0, (sum, c) => sum + c.calories);
    final strengthCal =
        strength.fold<double>(0, (sum, s) => sum + s.heartRate.toDouble());
    final workoutCal = workouts.fold<int>(0, (sum, w) => sum + w.calories);
    return (runCal + rideCal + strengthCal + workoutCal).toInt();
  }

  // ✅ Суммарная продолжительность
  int get totalDurationSeconds {
    final run = runs.fold<int>(0, (sum, r) => sum + r.durationSeconds);
    final ride = rides.fold<int>(0, (sum, c) => sum + c.durationSeconds);
    final strengthDur =
        strength.fold<int>(0, (sum, s) => sum + s.durationSeconds);
    return run + ride + strengthDur;
  }

  // ✅ Метки активности
  List<String> get activityLabels {
    final labels = <String>{};
    if (runs.isNotEmpty) labels.add('Бег');
    if (rides.isNotEmpty) labels.add('Велотренировка');
    if (strength.isNotEmpty) labels.add('Силовая');
    if (workouts.isNotEmpty) labels.add('Кардио/Общее');
    return labels.toList();
  }

  factory ActivityLogDay.fromJson(Map<String, dynamic> json) => ActivityLogDay(
        date: DateTime.parse(json['date']),
        runs: (json['runs'] as List<dynamic>)
            .map((e) => RunActivity.fromJson(e))
            .toList(),
        rides: (json['rides'] as List<dynamic>)
            .map((e) => CyclingActivity.fromJson(e))
            .toList(),
        strength: (json['strength'] as List<dynamic>)
            .map((e) => StrengthWorkout.fromJson(e))
            .toList(),
        workouts: (json['workouts'] as List<dynamic>)
            .map((e) => WorkoutModel.fromJson(e))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'date': date.toIso8601String(),
        'runs': runs.map((r) => r.toJson()).toList(),
        'rides': rides.map((b) => b.toJson()).toList(),
        'strength': strength.map((s) => s.toJson()).toList(),
        'workouts': workouts.map((w) => w.toJson()).toList(),
      };

  /// 🧠 Средний пульс
  double get avgHeartRate {
    final values = <double>[
      ...runs.map((r) => r.avgHeartRate),
      ...rides.map((c) => c.avgHeartRate),
      ...strength.map((s) => (s.avgHeartRate ?? s.heartRate).toDouble()),
      ...workouts.map((w) => (w.heartRate ?? 0).toDouble()),
    ].where((v) => v > 0).toList();

    if (values.isEmpty) return 0;
    return values.reduce((a, b) => a + b) / values.length;
  }

  /// 🧩 Сводка по зонам пульса (Map<zone, суммарное время>)
  Map<String, int> get zonesSummary {
    final zoneMap = <String, int>{};

    for (final r in runs) {
      r.heartRateZones.forEach((zone, duration) {
        zoneMap[zone] = (zoneMap[zone] ?? 0) + duration;
      });
    }

    for (final c in rides) {
      c.heartRateZones.forEach((zone, duration) {
        zoneMap[zone] = (zoneMap[zone] ?? 0) + duration;
      });
    }

    return zoneMap;
  }

  /// 🔥 Экспериментальный: нагрузка дня
  double get trainingLoadScore {
    final rideLoad = rides.fold<double>(0, (sum, r) => sum + r.tss);
    final runLoad = runs.fold<double>(0, (sum, r) => sum + r.trainingLoad);
    final strengthLoad =
        strength.fold<double>(0, (sum, s) => sum + (s.hrv ?? 0));
    return rideLoad + runLoad + strengthLoad;
  }
}
