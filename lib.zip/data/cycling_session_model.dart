import 'package:hive/hive.dart';

part 'cycling_session_model.g.dart';

@HiveType(typeId: 4)
class CyclingSessionModel extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final double distanceKm;

  @HiveField(3)
  final int durationSeconds;

  @HiveField(4)
  final double avgSpeedKmh;

  @HiveField(5)
  final double maxSpeedKmh;

  @HiveField(6)
  final int? avgHeartRate;

  @HiveField(7)
  final int? maxHeartRate;

  @HiveField(8)
  final Map<String, double>? heartRateZones;

  @HiveField(9)
  final List<int>? pulseSeries;

  @HiveField(10)
  final List<List<double>>? gpsTrack;

  @HiveField(11)
  final double? elevationGainM;

  @HiveField(12)
  final double? temperatureC;

  @HiveField(13)
  final double? vo2Max;

  CyclingSessionModel({
    required this.id,
    required this.date,
    required this.distanceKm,
    required this.durationSeconds,
    required this.avgSpeedKmh,
    required this.maxSpeedKmh,
    this.avgHeartRate,
    this.maxHeartRate,
    this.heartRateZones,
    this.pulseSeries,
    this.gpsTrack,
    this.elevationGainM,
    this.temperatureC,
    this.vo2Max,
  });
}
