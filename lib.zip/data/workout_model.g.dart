// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'workout_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class WorkoutModelAdapter extends TypeAdapter<WorkoutModel> {
  @override
  final int typeId = 2;

  @override
  WorkoutModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return WorkoutModel(
      id: fields[0] as String?,
      date: fields[1] as DateTime,
      steps: fields[2] as int,
      calories: fields[3] as int,
      notes: fields[4] as String?,
      heartRate: fields[5] as int?,
      tags: (fields[6] as List?)?.cast<String>(),
      type: fields[7] as String,
      distance: fields[8] as double?,
      durationSeconds: fields[9] as int?,
      maxHeartRate: fields[10] as int?,
      avgHeartRate: fields[11] as double?,
      hrv: fields[12] as int?,
      recoveryHeartRate: fields[13] as int?,
      recoveryTimeHr: fields[14] as double?,
      avgSpeed: fields[15] as double?,
      maxSpeed: fields[16] as double?,
      avgPace: fields[17] as int?,
      maxPace: fields[18] as int?,
      cadenceSpm: fields[19] as int?,
      strideLengthM: fields[20] as double?,
      strideSymmetry: fields[21] as double?,
      elevationGainM: fields[22] as double?,
      elevationLossM: fields[23] as double?,
      groundContactTimeMs: fields[24] as int?,
      verticalOscillationCm: fields[25] as double?,
      vo2Max: fields[26] as double?,
      temperatureC: fields[27] as double?,
      spo2: fields[28] as double?,
      stressLevel: fields[29] as int?,
      trainingLoad: fields[30] as double?,
      ftp: fields[31] as double?,
      avgPower: fields[32] as double?,
      normalizedPower: fields[33] as double?,
      intensityFactor: fields[34] as double?,
      tss: fields[35] as double?,
      ctl: fields[36] as double?,
      atl: fields[37] as double?,
      tsb: fields[38] as double?,
      pulseSeries: (fields[39] as List?)?.cast<int>(),
      heartRateZones: (fields[40] as Map?)?.cast<String, double>(),
      gpsTrack: (fields[41] as List?)
          ?.map((dynamic e) => (e as List).cast<double>())
          ?.toList(),
      activityType: fields[42] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, WorkoutModel obj) {
    writer
      ..writeByte(43)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.steps)
      ..writeByte(3)
      ..write(obj.calories)
      ..writeByte(4)
      ..write(obj.notes)
      ..writeByte(5)
      ..write(obj.heartRate)
      ..writeByte(6)
      ..write(obj.tags)
      ..writeByte(7)
      ..write(obj.type)
      ..writeByte(8)
      ..write(obj.distance)
      ..writeByte(9)
      ..write(obj.durationSeconds)
      ..writeByte(10)
      ..write(obj.maxHeartRate)
      ..writeByte(11)
      ..write(obj.avgHeartRate)
      ..writeByte(12)
      ..write(obj.hrv)
      ..writeByte(13)
      ..write(obj.recoveryHeartRate)
      ..writeByte(14)
      ..write(obj.recoveryTimeHr)
      ..writeByte(15)
      ..write(obj.avgSpeed)
      ..writeByte(16)
      ..write(obj.maxSpeed)
      ..writeByte(17)
      ..write(obj.avgPace)
      ..writeByte(18)
      ..write(obj.maxPace)
      ..writeByte(19)
      ..write(obj.cadenceSpm)
      ..writeByte(20)
      ..write(obj.strideLengthM)
      ..writeByte(21)
      ..write(obj.strideSymmetry)
      ..writeByte(22)
      ..write(obj.elevationGainM)
      ..writeByte(23)
      ..write(obj.elevationLossM)
      ..writeByte(24)
      ..write(obj.groundContactTimeMs)
      ..writeByte(25)
      ..write(obj.verticalOscillationCm)
      ..writeByte(26)
      ..write(obj.vo2Max)
      ..writeByte(27)
      ..write(obj.temperatureC)
      ..writeByte(28)
      ..write(obj.spo2)
      ..writeByte(29)
      ..write(obj.stressLevel)
      ..writeByte(30)
      ..write(obj.trainingLoad)
      ..writeByte(31)
      ..write(obj.ftp)
      ..writeByte(32)
      ..write(obj.avgPower)
      ..writeByte(33)
      ..write(obj.normalizedPower)
      ..writeByte(34)
      ..write(obj.intensityFactor)
      ..writeByte(35)
      ..write(obj.tss)
      ..writeByte(36)
      ..write(obj.ctl)
      ..writeByte(37)
      ..write(obj.atl)
      ..writeByte(38)
      ..write(obj.tsb)
      ..writeByte(39)
      ..write(obj.pulseSeries)
      ..writeByte(40)
      ..write(obj.heartRateZones)
      ..writeByte(41)
      ..write(obj.gpsTrack)
      ..writeByte(42)
      ..write(obj.activityType);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is WorkoutModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
