import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

part 'activity_type.g.dart'; // 👈 для генерації адаптера через build_runner

/// Enum, определяющий типы активности в приложении
@HiveType(typeId: 5)
enum ActivityType {
  @HiveField(0)
  run,

  @HiveField(1)
  cycling,

  @HiveField(2)
  squats,

  @HiveField(3)
  strength,
}

/// Расширения для UI: текст, иконка и цвет
extension ActivityTypeX on ActivityType {
  String get displayName {
    switch (this) {
      case ActivityType.run:
        return 'Бег';
      case ActivityType.cycling:
        return 'Велосипед';
      case ActivityType.squats:
        return 'Приседания';
      case ActivityType.strength:
        return 'Силовая';
    }
  }

  IconData get icon {
    switch (this) {
      case ActivityType.run:
        return Icons.directions_run;
      case ActivityType.cycling:
        return Icons.directions_bike;
      case ActivityType.squats:
      case ActivityType.strength:
        return Icons.fitness_center;
    }
  }

  Color get color {
    switch (this) {
      case ActivityType.run:
        return Colors.deepOrange;
      case ActivityType.cycling:
        return Colors.indigo;
      case ActivityType.squats:
        return Colors.green;
      case ActivityType.strength:
        return Colors.red;
    }
  }
}
