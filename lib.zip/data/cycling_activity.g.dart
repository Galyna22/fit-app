// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cycling_activity.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CyclingActivityAdapter extends TypeAdapter<CyclingActivity> {
  @override
  final int typeId = 4;

  @override
  CyclingActivity read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CyclingActivity(
      id: fields[0] as String?,
      date: fields[1] as DateTime,
      durationSeconds: fields[2] as int,
      distance: fields[3] as double,
      avgSpeed: fields[4] as double,
      maxSpeed: fields[5] as double,
      calories: fields[6] as double,
      avgHeartRate: fields[7] as double,
      maxHeartRate: fields[8] as double,
      pulseSeries: (fields[9] as List).cast<int>(),
      heartRateZones: (fields[10] as Map).cast<String, int>(),
      gpsTrack: (fields[11] as List).cast<GpsPoint>(),
      vo2Max: fields[12] as double,
      hrv: fields[13] as double,
      recoveryHeartRate: fields[14] as int,
      ftp: fields[15] as double,
      avgPower: fields[16] as double,
      normalizedPower: fields[17] as double,
      intensityFactor: fields[18] as double,
      tss: fields[19] as double,
      type: fields[20] as ActivityType,
      updatedAt: fields[21] as DateTime?,
      createdAt: fields[22] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, CyclingActivity obj) {
    writer
      ..writeByte(23)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.durationSeconds)
      ..writeByte(3)
      ..write(obj.distance)
      ..writeByte(4)
      ..write(obj.avgSpeed)
      ..writeByte(5)
      ..write(obj.maxSpeed)
      ..writeByte(6)
      ..write(obj.calories)
      ..writeByte(7)
      ..write(obj.avgHeartRate)
      ..writeByte(8)
      ..write(obj.maxHeartRate)
      ..writeByte(9)
      ..write(obj.pulseSeries)
      ..writeByte(10)
      ..write(obj.heartRateZones)
      ..writeByte(11)
      ..write(obj.gpsTrack)
      ..writeByte(12)
      ..write(obj.vo2Max)
      ..writeByte(13)
      ..write(obj.hrv)
      ..writeByte(14)
      ..write(obj.recoveryHeartRate)
      ..writeByte(15)
      ..write(obj.ftp)
      ..writeByte(16)
      ..write(obj.avgPower)
      ..writeByte(17)
      ..write(obj.normalizedPower)
      ..writeByte(18)
      ..write(obj.intensityFactor)
      ..writeByte(19)
      ..write(obj.tss)
      ..writeByte(20)
      ..write(obj.type)
      ..writeByte(21)
      ..write(obj.updatedAt)
      ..writeByte(22)
      ..write(obj.createdAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CyclingActivityAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
