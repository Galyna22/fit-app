// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'activity_log_day.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ActivityLogDayAdapter extends TypeAdapter<ActivityLogDay> {
  @override
  final int typeId = 99;

  @override
  ActivityLogDay read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ActivityLogDay(
      date: fields[0] as DateTime,
      runs: (fields[1] as List).cast<RunActivity>(),
      rides: (fields[2] as List).cast<CyclingActivity>(),
      strength: (fields[3] as List).cast<StrengthWorkout>(),
      workouts: (fields[4] as List).cast<WorkoutModel>(),
    );
  }

  @override
  void write(BinaryWriter writer, ActivityLogDay obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.date)
      ..writeByte(1)
      ..write(obj.runs)
      ..writeByte(2)
      ..write(obj.rides)
      ..writeByte(3)
      ..write(obj.strength)
      ..writeByte(4)
      ..write(obj.workouts);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ActivityLogDayAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
