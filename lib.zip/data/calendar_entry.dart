import 'package:hive/hive.dart';

part 'calendar_entry.g.dart';

@HiveType(typeId: 10)
class CalendarEntry {
  @HiveField(0)
  final DateTime date;

  @HiveField(1)
  final String? notes;

  @HiveField(2)
  final List<String>? tags;

  @HiveField(3)
  final int steps;

  @HiveField(4)
  final int calories;

  @HiveField(5)
  final int heartRate;
  factory CalendarEntry.fromJson(Map<String, dynamic> json) {
    return CalendarEntry(
      date: DateTime.parse(json['date']),
      notes: json['notes'],
      tags: List<String>.from(json['tags'] ?? []),
      steps: json['steps'] ?? 0,
      calories: json['calories'] ?? 0,
      heartRate: json['heartRate'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'date': date.toIso8601String(),
      'notes': notes,
      'tags': tags,
      'steps': steps,
      'calories': calories,
      'heartRate': heartRate,
    };
  }

  CalendarEntry({
    required this.date,
    this.notes,
    this.tags,
    this.steps = 0,
    this.calories = 0,
    this.heartRate = 0,
  });
}
