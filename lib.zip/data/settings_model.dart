import 'package:hive/hive.dart';

@HiveType(typeId: 7)
class SettingsModel extends HiveObject {
  @HiveField(0)
  final bool notificationsEnabled;

  @HiveField(1)
  final String preferredUnit; // 'km' или 'mi'

  SettingsModel({
    required this.notificationsEnabled,
    required this.preferredUnit,
  });
}

class SettingsModelAdapter extends TypeAdapter<SettingsModel> {
  @override
  final int typeId = 7;

  @override
  SettingsModel read(BinaryReader reader) {
    return SettingsModel(
      notificationsEnabled: reader.readBool(),
      preferredUnit: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, SettingsModel obj) {
    writer.writeBool(obj.notificationsEnabled);
    writer.writeString(obj.preferredUnit);
  }
}
