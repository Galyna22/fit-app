import 'package:hive/hive.dart';
import 'package:fitness_app/models/gps_point.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/mixins/with_safe_id_mixin.dart';

part 'run_activity.g.dart';

@HiveType(typeId: 3)
class RunActivity extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final int steps;

  @HiveField(3)
  final double distance;

  @HiveField(4)
  final int durationSeconds;

  @HiveField(5)
  final double caloriesBurned;

  @HiveField(6)
  final double avgHeartRate;

  @HiveField(7)
  final double maxHeartRate;

  @HiveField(8)
  final Map<String, int> heartRateZones;

  @HiveField(9)
  final double paceMinPerKm;

  @HiveField(10)
  final double avgSpeed;

  @HiveField(11)
  final double maxSpeed;

  @HiveField(12)
  final int cadenceSpm;

  @HiveField(13)
  final double strideLength;

  @HiveField(14)
  final double elevationGain;

  @HiveField(15)
  final double elevationLoss;

  @HiveField(16)
  final List<GpsPoint> gpsTrack;

  @HiveField(17)
  final int groundContactTime;

  @HiveField(18)
  final double verticalOscillation;

  @HiveField(19)
  final double vo2Max;

  @HiveField(20)
  final int recoveryTime;

  @HiveField(21)
  final double trainingLoad;

  @HiveField(22)
  final double strideSymmetry;

  @HiveField(23)
  final double temperature;

  @HiveField(24)
  final double stressLevel;

  @HiveField(25)
  final double spo2;

  @HiveField(26)
  final DateTime updatedAt;

  @HiveField(27)
  final ActivityType type;

  @HiveField(28)
  final List<int> pulseSeries;

  RunActivity({
    String? id,
    List<int>? pulseSeries,
    required this.date,
    required this.steps,
    required this.distance,
    required this.durationSeconds,
    required this.caloriesBurned,
    required this.avgHeartRate,
    required this.maxHeartRate,
    required this.heartRateZones,
    required this.paceMinPerKm,
    required this.avgSpeed,
    required this.maxSpeed,
    required this.cadenceSpm,
    required this.strideLength,
    required this.elevationGain,
    required this.elevationLoss,
    required this.gpsTrack,
    required this.groundContactTime,
    required this.verticalOscillation,
    required this.vo2Max,
    required this.recoveryTime,
    required this.trainingLoad,
    required this.strideSymmetry,
    required this.temperature,
    required this.stressLevel,
    required this.spo2,
    required this.type,
    DateTime? updatedAt,
  })  : id = WithSafeIdMixin.safeId(id),
        pulseSeries = pulseSeries ?? [],
        updatedAt = updatedAt ?? date;

  factory RunActivity.fromJson(Map<String, dynamic> json) => RunActivity(
        id: json['id'],
        date: DateTime.parse(json['date']),
        steps: json['steps'],
        distance: (json['distance'] as num).toDouble(),
        durationSeconds: json['durationSeconds'],
        caloriesBurned: (json['caloriesBurned'] as num).toDouble(),
        avgHeartRate: (json['avgHeartRate'] as num).toDouble(),
        maxHeartRate: (json['maxHeartRate'] as num).toDouble(),
        heartRateZones: Map<String, int>.from(json['heartRateZones']),
        paceMinPerKm: (json['paceMinPerKm'] as num).toDouble(),
        avgSpeed: (json['avgSpeed'] as num).toDouble(),
        maxSpeed: (json['maxSpeed'] as num).toDouble(),
        cadenceSpm: json['cadenceSpm'],
        strideLength: (json['strideLength'] as num).toDouble(),
        elevationGain: (json['elevationGain'] as num).toDouble(),
        elevationLoss: (json['elevationLoss'] as num).toDouble(),
        gpsTrack: (json['gpsTrack'] as List)
            .map((e) => GpsPoint.fromJson(e))
            .toList(),
        groundContactTime: json['groundContactTime'],
        verticalOscillation: (json['verticalOscillation'] as num).toDouble(),
        vo2Max: (json['vo2Max'] as num).toDouble(),
        recoveryTime: json['recoveryTime'],
        trainingLoad: (json['trainingLoad'] as num).toDouble(),
        strideSymmetry: (json['strideSymmetry'] as num).toDouble(),
        temperature: (json['temperature'] as num).toDouble(),
        stressLevel: (json['stressLevel'] as num).toDouble(),
        spo2: (json['spo2'] as num).toDouble(),
        updatedAt: DateTime.parse(json['updatedAt']),
        type: ActivityType.values.firstWhere(
          (e) => e.name == json['type'],
          orElse: () => ActivityType.run,
        ),
        pulseSeries: List<int>.from(json['pulseSeries'] ?? []),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'steps': steps,
        'distance': distance,
        'durationSeconds': durationSeconds,
        'caloriesBurned': caloriesBurned,
        'avgHeartRate': avgHeartRate,
        'maxHeartRate': maxHeartRate,
        'heartRateZones': heartRateZones,
        'paceMinPerKm': paceMinPerKm,
        'avgSpeed': avgSpeed,
        'maxSpeed': maxSpeed,
        'cadenceSpm': cadenceSpm,
        'strideLength': strideLength,
        'elevationGain': elevationGain,
        'elevationLoss': elevationLoss,
        'gpsTrack': gpsTrack.map((e) => e.toJson()).toList(),
        'groundContactTime': groundContactTime,
        'verticalOscillation': verticalOscillation,
        'vo2Max': vo2Max,
        'recoveryTime': recoveryTime,
        'trainingLoad': trainingLoad,
        'strideSymmetry': strideSymmetry,
        'temperature': temperature,
        'stressLevel': stressLevel,
        'spo2': spo2,
        'updatedAt': updatedAt.toIso8601String(),
        'type': type.name,
        'pulseSeries': pulseSeries,
      };
}
