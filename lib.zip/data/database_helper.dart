import 'package:hive/hive.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/services/backup_service.dart';

class DatabaseHelper {
  final Box<WorkoutModel> workoutBox;
  final Box<RunActivity> activityBox;
  final Box<CalendarEntry> calendarBox;
  final Box<CyclingActivity> cyclingActivityBox;
  final BackupService backupService;

  DatabaseHelper({
    required this.workoutBox,
    required this.activityBox,
    required this.calendarBox,
    required this.cyclingActivityBox,
    required this.backupService,
  });

  Future<void> saveRun(RunActivity run) async =>
      await activityBox.put(run.id, run);

  Future<void> saveRide(CyclingActivity ride) async =>
      await cyclingActivityBox.put(ride.id, ride);

  Future<void> saveWorkout(WorkoutModel workout) async =>
      await workoutBox.put(workout.id, workout);

  Future<void> saveStrength(StrengthWorkout strength) async {
    final strengthBox = Hive.box<StrengthWorkout>('strength_workouts');
    await strengthBox.put(strength.id, strength);
  }

  Future<void> saveStrengthWorkout(StrengthWorkout workout) async {
    final box = Hive.box<StrengthWorkout>('strength_workouts');
    await box.add(workout);
  }

  Future<void> saveActivity(RunActivity run) async =>
      await activityBox.put(run.id, run);

  Future<void> saveCyclingActivity(CyclingActivity ride) async =>
      await cyclingActivityBox.put(ride.id, ride);

  List<WorkoutModel> getAllWorkouts() => workoutBox.values.toList();

  Future<void> clearAllData() async {
    await activityBox.clear();
    await cyclingActivityBox.clear();
    await workoutBox.clear();
    await Hive.box<StrengthWorkout>('strength_workouts').clear();
    await calendarBox.clear();
  }
}
