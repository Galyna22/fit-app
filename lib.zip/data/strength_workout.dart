import 'package:hive/hive.dart';
import 'package:fitness_app/mixins/with_safe_id_mixin.dart';

part 'strength_workout.g.dart';

@HiveType(typeId: 41)
class StrengthWorkout extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final String exercise;

  @HiveField(3)
  final int sets;

  @HiveField(4)
  final int repsPlanned;

  @HiveField(5)
  final int repsActual;

  @HiveField(6)
  final double weight;

  @HiveField(7)
  final int heartRate;

  @HiveField(8)
  final int durationSeconds;

  @HiveField(9)
  final List<int>? pulseSeries;

  @HiveField(10)
  final int? maxHeartRate;

  @HiveField(11)
  final int? avgHeartRate;

  @HiveField(12)
  final int? restBetweenSetsSec;

  @HiveField(13)
  final String? notes;

  @HiveField(14)
  final int? hrv;

  StrengthWorkout({
    String? id,
    required this.date,
    required this.exercise,
    required this.sets,
    required this.repsPlanned,
    required this.repsActual,
    required this.weight,
    required this.heartRate,
    required this.durationSeconds,
    this.pulseSeries,
    this.maxHeartRate,
    this.avgHeartRate,
    this.restBetweenSetsSec,
    this.notes,
    this.hrv,
  }) : id = WithSafeIdMixin.safeId(id);

  factory StrengthWorkout.fromJson(Map<String, dynamic> json) =>
      StrengthWorkout(
        id: json['id'],
        date: DateTime.parse(json['date']),
        exercise: json['exercise'],
        sets: json['sets'],
        repsPlanned: json['repsPlanned'],
        repsActual: json['repsActual'],
        weight: (json['weight'] as num).toDouble(),
        heartRate: json['heartRate'],
        durationSeconds: json['durationSeconds'],
        pulseSeries: (json['pulseSeries'] as List?)?.cast<int>(),
        maxHeartRate: json['maxHeartRate'],
        avgHeartRate: json['avgHeartRate'],
        restBetweenSetsSec: json['restBetweenSetsSec'],
        notes: json['notes'],
        hrv: json['hrv'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'exercise': exercise,
        'sets': sets,
        'repsPlanned': repsPlanned,
        'repsActual': repsActual,
        'weight': weight,
        'heartRate': heartRate,
        'durationSeconds': durationSeconds,
        'pulseSeries': pulseSeries,
        'maxHeartRate': maxHeartRate,
        'avgHeartRate': avgHeartRate,
        'restBetweenSetsSec': restBetweenSetsSec,
        'notes': notes,
        'hrv': hrv,
      };
}
