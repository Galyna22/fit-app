import 'package:hive/hive.dart';
import 'package:fitness_app/models/gps_point.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/constants/hive_type_ids.dart';
import 'package:fitness_app/mixins/with_safe_id_mixin.dart';

part 'cycling_activity.g.dart';

@HiveType(typeId: HiveTypeIds.cyclingActivity)
class CyclingActivity extends HiveObject with WithSafeIdMixin {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime date;

  @HiveField(2)
  final int durationSeconds;

  @HiveField(3)
  final double distance;

  @HiveField(4)
  final double avgSpeed;

  @HiveField(5)
  final double maxSpeed;

  @HiveField(6)
  final double calories;

  @HiveField(7)
  final double avgHeartRate;

  @HiveField(8)
  final double maxHeartRate;

  @HiveField(9)
  final List<int> pulseSeries;

  @HiveField(10)
  final Map<String, int> heartRateZones;

  @HiveField(11)
  final List<GpsPoint> gpsTrack;

  @HiveField(12)
  final double vo2Max;

  @HiveField(13)
  final double hrv;

  @HiveField(14)
  final int recoveryHeartRate;

  @HiveField(15)
  final double ftp;

  @HiveField(16)
  final double avgPower;

  @HiveField(17)
  final double normalizedPower;

  @HiveField(18)
  final double intensityFactor;

  @HiveField(19)
  final double tss;

  @HiveField(20)
  final ActivityType type;

  @HiveField(21)
  final DateTime updatedAt;

  @HiveField(22)
  final DateTime createdAt;

  CyclingActivity({
    String? id,
    required this.date,
    required this.durationSeconds,
    required this.distance,
    required this.avgSpeed,
    required this.maxSpeed,
    required this.calories,
    required this.avgHeartRate,
    required this.maxHeartRate,
    required this.pulseSeries,
    required this.heartRateZones,
    required this.gpsTrack,
    required this.vo2Max,
    required this.hrv,
    required this.recoveryHeartRate,
    required this.ftp,
    required this.avgPower,
    required this.normalizedPower,
    required this.intensityFactor,
    required this.tss,
    required this.type,
    DateTime? updatedAt,
    DateTime? createdAt,
  })  : id = WithSafeIdMixin.safeId(id),
        updatedAt = updatedAt ?? date,
        createdAt = createdAt ?? date;

  factory CyclingActivity.fromJson(Map<String, dynamic> json) =>
      CyclingActivity(
        id: json['id'],
        date: DateTime.parse(json['date']),
        durationSeconds: json['durationSeconds'],
        distance: (json['distance'] as num).toDouble(),
        avgSpeed: (json['avgSpeed'] as num).toDouble(),
        maxSpeed: (json['maxSpeed'] as num).toDouble(),
        calories: (json['calories'] as num).toDouble(),
        avgHeartRate: (json['avgHeartRate'] as num?)?.toDouble() ?? 0.0,
        maxHeartRate: (json['maxHeartRate'] as num?)?.toDouble() ?? 0.0,
        pulseSeries: List<int>.from(json['pulseSeries'] ?? []),
        heartRateZones: Map<String, int>.from(json['heartRateZones']),
        gpsTrack: (json['gpsTrack'] as List)
            .map((e) => GpsPoint.fromJson(e))
            .toList(),
        vo2Max: (json['vo2Max'] as num).toDouble(),
        hrv: (json['hrv'] as num).toDouble(),
        recoveryHeartRate: json['recoveryHeartRate'],
        ftp: (json['ftp'] as num).toDouble(),
        avgPower: (json['avgPower'] as num).toDouble(),
        normalizedPower: (json['normalizedPower'] as num).toDouble(),
        intensityFactor: (json['intensityFactor'] as num).toDouble(),
        tss: (json['tss'] as num).toDouble(),
        type: ActivityType.values.firstWhere(
          (e) => e.name == json['type'],
          orElse: () => ActivityType.cycling,
        ),
        updatedAt: DateTime.parse(json['updatedAt']),
        createdAt: DateTime.parse(json['createdAt']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'durationSeconds': durationSeconds,
        'distance': distance,
        'avgSpeed': avgSpeed,
        'maxSpeed': maxSpeed,
        'calories': calories,
        'avgHeartRate': avgHeartRate,
        'maxHeartRate': maxHeartRate,
        'pulseSeries': pulseSeries,
        'heartRateZones': heartRateZones,
        'gpsTrack': gpsTrack.map((e) => e.toJson()).toList(),
        'vo2Max': vo2Max,
        'hrv': hrv,
        'recoveryHeartRate': recoveryHeartRate,
        'ftp': ftp,
        'avgPower': avgPower,
        'normalizedPower': normalizedPower,
        'intensityFactor': intensityFactor,
        'tss': tss,
        'type': type.name,
        'updatedAt': updatedAt.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
      };
}
