// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cycling_session_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CyclingSessionModelAdapter extends TypeAdapter<CyclingSessionModel> {
  @override
  final int typeId = 4;

  @override
  CyclingSessionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CyclingSessionModel(
      id: fields[0] as String,
      date: fields[1] as DateTime,
      distanceKm: fields[2] as double,
      durationSeconds: fields[3] as int,
      avgSpeedKmh: fields[4] as double,
      maxSpeedKmh: fields[5] as double,
      avgHeartRate: fields[6] as int?,
      maxHeartRate: fields[7] as int?,
      heartRateZones: (fields[8] as Map?)?.cast<String, double>(),
      pulseSeries: (fields[9] as List?)?.cast<int>(),
      gpsTrack: (fields[10] as List?)
          ?.map((dynamic e) => (e as List).cast<double>())
          ?.toList(),
      elevationGainM: fields[11] as double?,
      temperatureC: fields[12] as double?,
      vo2Max: fields[13] as double?,
    );
  }

  @override
  void write(BinaryWriter writer, CyclingSessionModel obj) {
    writer
      ..writeByte(14)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.date)
      ..writeByte(2)
      ..write(obj.distanceKm)
      ..writeByte(3)
      ..write(obj.durationSeconds)
      ..writeByte(4)
      ..write(obj.avgSpeedKmh)
      ..writeByte(5)
      ..write(obj.maxSpeedKmh)
      ..writeByte(6)
      ..write(obj.avgHeartRate)
      ..writeByte(7)
      ..write(obj.maxHeartRate)
      ..writeByte(8)
      ..write(obj.heartRateZones)
      ..writeByte(9)
      ..write(obj.pulseSeries)
      ..writeByte(10)
      ..write(obj.gpsTrack)
      ..writeByte(11)
      ..write(obj.elevationGainM)
      ..writeByte(12)
      ..write(obj.temperatureC)
      ..writeByte(13)
      ..write(obj.vo2Max);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CyclingSessionModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
