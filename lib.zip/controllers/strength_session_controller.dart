import 'package:flutter/foundation.dart';
import 'package:fitness_app/data/strength_workout.dart';

// 💪 Контроллер для отслеживания одной силовой сессии в реальном времени
class StrengthSessionController {
  final DateTime startTime = DateTime.now(); // ⏱ Время старта тренировки
  final List<DateTime> _setTimestamps = []; // 📝 Метки времени для каждого сета

  // ➕ Добавляет новый сет с меткой времени
  void addSet() {
    _setTimestamps.add(DateTime.now());
    debugPrint('➕ Set added: ${_setTimestamps.last}');
  }

  // 🛑 Завершает тренировку и возвращает объект StrengthWorkout
  StrengthWorkout stopAndBuild() {
    final duration = DateTime.now().difference(startTime);

    return StrengthWorkout(
      id: DateTime.now().millisecondsSinceEpoch.toString(), // 🆔 Уникальный ID
      date: startTime, // 📅 Время начала
      durationSeconds: duration.inSeconds, // ⏱️ Продолжительность

      // 🔢 Подсчёты — пока захардкожены
      totalSets: _setTimestamps.length,
      totalReps: _setTimestamps.length * 10,
      totalWeight: _setTimestamps.length * 10 * 60,

      // 📝 Примечания — тоже пока фиксированы
      notes: 'Приседания: по 10 повторов, 60 кг',
    );
  }
}
