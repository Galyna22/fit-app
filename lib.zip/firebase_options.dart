import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return FirebaseOptions(
      apiKey: "AIzaSyB_a_crle1anPLWT05u54zqN8Yx2ORu42Q",
      authDomain: "fit-app-c7070.firebaseapp.com",
      projectId: "fit-app-c7070",
      storageBucket: "fit-app-c7070.appspot.com",
      messagingSenderId: "182853778216",
      appId: "1:182853778216:web:07b04804bec9987455ae1d",
      measurementId: "G-3TEDNEVG37",
    );
  }
}
