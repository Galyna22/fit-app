import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'firebase_options.dart';

// 📦 Модели
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/strength_workout.dart';

// 🔧 Сервисы
import 'package:fitness_app/adapters/register_all_adapters.dart';
import 'package:fitness_app/services/box_manager.dart';
import 'package:fitness_app/services/backup_service.dart';
import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/services/dev_snapshot_service.dart';

// 🛡️ Диагностика
import 'package:fitness_app/debug/box_opening_audit_service.dart';
import 'package:fitness_app/debug/box_audit_guard.dart';
import 'package:fitness_app/debug/box_inspector_service.dart';
import 'package:fitness_app/debug/box_dump_service.dart';
import 'package:fitness_app/debug/box_debug_panel.dart';

// 🎯 UI
import 'package:fitness_app/screens/start/start_screen.dart';
import 'error_app.dart';

/// Режимы запуска через --dart-define
const appMode = String.fromEnvironment('MODE', defaultValue: 'prod');
const restoreSnapshot = bool.fromEnvironment('RESTORE', defaultValue: false);
const debugUI = bool.fromEnvironment('DEBUG_UI', defaultValue: false);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ru_RU', null);

  final stopwatch = Stopwatch()..start();

  try {
    print('⏱ [1] Firebase init...');
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    print('⏱ [2] Hive init...');
    await Hive.initFlutter();

    print('⏱ [3] Регистрация адаптеров...');
    registerAllAdapters();

    print('⏱ [4] Запуск аудита...');
    BoxOpeningAuditService.initSession();
    BoxOpeningAuditService.reportStatus('PRE_OPEN');

    print('⏱ [5] Открытие боксов...');
    await BoxManager.openOnly([
      BoxManager.workouts,
      BoxManager.activities,
      BoxManager.calendar,
      BoxManager.cycling,
      BoxManager.strength,
    ]);
    BoxOpeningAuditService.reportStatus('POST_OPEN');

    final workoutBox = BoxAuditGuard.get<WorkoutModel>(BoxManager.workouts);
    final activityBox = BoxAuditGuard.get<RunActivity>(BoxManager.activities);
    final calendarBox = BoxAuditGuard.get<CalendarEntry>(BoxManager.calendar);
    final cyclingBox = BoxAuditGuard.get<CyclingActivity>(BoxManager.cycling);

    print('⏱ [6] Сборка сервисов...');
    final backupService = BackupService(
      workoutBox: workoutBox,
      calendarBox: calendarBox,
      activityBox: activityBox,
    );

    final dbHelper = DatabaseHelper(
      workoutBox: workoutBox,
      calendarBox: calendarBox,
      backupService: backupService,
      activityBox: activityBox,
      cyclingActivityBox: cyclingBox,
    );

    if (!kReleaseMode) {
      BoxInspectorService.logSummary();
      BoxInspectorService.validateTypes({
        BoxManager.workouts: WorkoutModel,
        BoxManager.activities: RunActivity,
        BoxManager.calendar: CalendarEntry,
        BoxManager.cycling: CyclingActivity,
      });
    }

    stopwatch.stop();
    print('✅ Startup завершён за ${stopwatch.elapsedMilliseconds} ms');
    BoxAuditGuard.printSummary();

    print(
        '🎛️ Режимы: MODE=$appMode RESTORE=$restoreSnapshot DEBUG_UI=$debugUI');

    if (restoreSnapshot) {
      print('🔄 RestoreSnapshotService активирован');
      // await RestoreSnapshotService.load(dbHelper);
    }

    if (appMode == 'dev') {
      print('🧪 DevMode активен');
      await DevSnapshotService.load(dbHelper);
    }

    if (debugUI && !kReleaseMode) {
      runApp(const BoxDebugPanel());
      return;
    }

    // 📦 Получаем последний StrengthWorkout из бокса
    final strengthBox = Hive.box<StrengthWorkout>('strength_workouts');
    final latestStrength =
        strengthBox.isNotEmpty ? strengthBox.values.last : null;

    void _startWorkout(Object type) {
      print('🚀 Старт тренировки: $type');
      // TODO: навигация на экран тренировки
    }

    runApp(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: StartScreen(
          latestStrength: latestStrength,
          onStartWorkout: _startWorkout,
        ),
      ),
    );
  } catch (e, stack) {
    print('❌ Ошибка при старте: $e');
    print(stack);
    BoxOpeningAuditService.reportStatus('FAIL');

    if (!kReleaseMode) {
      await BoxDumpService.dumpAllBoxesToTemp();
    }

    runApp(const ErrorApp());
  }
}
