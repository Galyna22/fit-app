import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_workout.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/init/hive_adapter_registry.dart';

late Box<Workout> workoutBox;
late Box<CalendarData> calendarBox;
late Box<RunActivity> activityBox;
late Box<CyclingWorkout> cyclingWorkoutBox;
late Box<StrengthWorkout> strengthWorkoutBox;

Future<void> initializeHive() async {
  await Hive.initFlutter();
  HiveAdapterRegistry.registerAdapters();

  workoutBox = await Hive.openBox<Workout>('workouts');
  calendarBox = await Hive.openBox<CalendarData>('calendar');
  activityBox = await Hive.openBox<RunActivity>('activities');
  cyclingWorkoutBox = await Hive.openBox<CyclingWorkout>('cycling_workouts');
  strengthWorkoutBox = await Hive.openBox<StrengthWorkout>('strength_workouts');
}
