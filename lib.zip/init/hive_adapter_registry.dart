import 'package:hive/hive.dart';
import 'package:flutter/foundation.dart';

import 'package:fitness_app/adapters/workout_adapter.dart';
import 'package:fitness_app/adapters/cycling_workout_adapter.dart';
import 'package:fitness_app/adapters/calendar_data_adapter.dart';
import 'package:fitness_app/adapters/run_activity_adapter.dart';
import 'package:fitness_app/adapters/gps_point_adapter.dart';

import 'package:fitness_app/data/activity_type.dart' as app;

import 'package:fitness_app/adapters/strength_workout_adapter.dart';

import 'package:fitness_app/constants/hive_type_ids.dart';

class HiveAdapterRegistry {
  static void registerAdapters() {
    _safeRegister(
      HiveTypeIds.workout,
      () => Hive.registerAdapter(WorkoutAdapter()),
      'WorkoutAdapter',
    );
    _safeRegister(
      HiveTypeIds.strengthWorkout,
      () => Hive.registerAdapter(StrengthWorkoutAdapter()),
      'StrengthWorkoutAdapter',
    );

    _safeRegister(
      HiveTypeIds.cyclingWorkout,
      () => Hive.registerAdapter(CyclingWorkoutAdapter()),
      'CyclingWorkoutAdapter',
    );

    _safeRegister(
      HiveTypeIds.calendarData,
      () => Hive.registerAdapter(CalendarDataAdapter()),
      'CalendarDataAdapter',
    );

    _safeRegister(
      HiveTypeIds.runActivity,
      () => Hive.registerAdapter(RunActivityAdapter()),
      'RunActivityAdapter',
    );

    _safeRegister(
      HiveTypeIds.gpsPoint,
      () => Hive.registerAdapter(GpsPointAdapter()),
      'GpsPointAdapter',
    );

    _safeRegister(
      HiveTypeIds.activityType,
      () => Hive.registerAdapter(ActivityTypeAdapter()),
      'ActivityTypeAdapter',
    );
  }

  static void _safeRegister(int typeId, VoidCallback registerFn, String label) {
    if (!Hive.isAdapterRegistered(typeId)) {
      registerFn();
      debugPrint('✅ Registered Hive adapter: $label (typeId: $typeId)');
    } else {
      debugPrint('ℹ️ Hive adapter already registered: $label');
    }
  }
}
