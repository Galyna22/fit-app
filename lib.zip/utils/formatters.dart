import 'package:intl/intl.dart';

/// Форматирует Duration в строку вида "MM:SS"
String formatDuration(Duration d) {
  final min = d.inMinutes.toString().padLeft(2, '0');
  final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$min:$sec';
}

/// Форматирует дату в читаемый вид
String formatDate(DateTime date) {
  return DateFormat.yMMMd().format(date);
}

/// Форматирует дистанцию в км с двумя знаками
String formatDistance(double km) {
  return '${km.toStringAsFixed(2)} km';
}

/// Форматирует скорость в км/ч
String formatSpeed(double kmh) {
  return '${kmh.toStringAsFixed(2)} km/h';
}

/// Форматирует темп в мин/км
String formatPace(double minPerKm) {
  return '${minPerKm.toStringAsFixed(2)} min/km';
}
