import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';

import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/activity_log_day.dart';

class LogService {
  Future<List<ActivityLogDay>> fetchRecentLogs() async {
    final now = DateTime.now();
    final logs = <ActivityLogDay>[];

    final runBox = Hive.box<RunActivity>('activities');
    final cyclingBox = Hive.box<CyclingActivity>('cycling_activities');
    final workoutBox = Hive.box<WorkoutModel>('workouts');
    final strengthBox = Hive.box<StrengthWorkout>('strength_workouts');

    for (int i = 0; i < 7; i++) {
      final date = DateTime(now.year, now.month, now.day - i);
      final runs =
          runBox.values.where((r) => _isSameDay(r.date, date)).toList();
      final rides =
          cyclingBox.values.where((c) => _isSameDay(c.date, date)).toList();
      final workouts =
          workoutBox.values.where((w) => _isSameDay(w.date, date)).toList();
      final strength =
          strengthBox.values.where((s) => _isSameDay(s.date, date)).toList();

      if (runs.isNotEmpty ||
          rides.isNotEmpty ||
          workouts.isNotEmpty ||
          strength.isNotEmpty) {
        logs.add(ActivityLogDay(
          date: date,
          runs: runs,
          rides: rides,
          workouts: workouts,
          strength: strength,
        ));
      }
    }

    return logs;
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  // ✅ Логгирование
  static void info(String message, {String tag = 'INFO'}) => _log(tag, message);
  static void warn(String message, {String tag = 'WARN'}) => _log(tag, message);
  static void error(String message, {String tag = 'ERROR'}) =>
      _log(tag, message);

  static void _log(String tag, String message) {
    final timestamp = DateTime.now().toIso8601String();
    final output = '[$tag] $timestamp ➜ $message';
    print(output);
    debugPrint(output);
  }
}
