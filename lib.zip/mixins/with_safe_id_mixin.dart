import 'package:uuid/uuid.dart';

mixin WithSafeIdMixin {
  static final _uuid = Uuid();

  static String safeId(String? id) {
    return (id != null && id.isNotEmpty) ? id : _uuid.v4();
  }
}
