import 'package:hive/hive.dart';

class HiveDiagService {
  static final List<String> knownBoxes = [
    'workouts',
    'calendar',
    'activities',
    'cycling_activities',
    'strength_workouts',
    'settings',
  ];

  static void runDiagnostic() {
    print('\n🧪 Hive Диагностика:');
    for (final name in knownBoxes) {
      if (!Hive.isBoxOpen(name)) {
        print('⚠️ Бокс "$name" не открыт');
        continue;
      }
      final box = Hive.box(name);
      print(
          '📦 "$name" открыт как ${box.runtimeType} | Кол-во записей: ${box.length}');
    }
    print('✅ Диагностика завершена\n');
  }

  static void checkType<T>(String name) {
    if (!Hive.isBoxOpen(name)) {
      print('⚠️ "$name" не открыт');
      return;
    }
    final box = Hive.box(name);
    final expected = 'Box<$T>';
    final actual = box.runtimeType.toString();

    if (actual != expected) {
      print('❌ Несовпадение типа "$name": ожидали $expected, получили $actual');
    } else {
      print('✅ Тип "$name" совпадает: $actual');
    }
  }
}
