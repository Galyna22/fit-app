import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/services/exercise_label_resolver.dart';

class StrengthDividerService {
  static Map<String, List<WorkoutModel>> divide(List<WorkoutModel> workouts) {
    final Map<String, List<WorkoutModel>> grouped = {};

    for (final w in workouts) {
      if (w.activityType == 'strength') {
        final exList = w.exercises ?? [];
        if (exList.isEmpty) {
          grouped.putIfAbsent('Силовая: (не указано)', () => []).add(w);
        } else {
          for (final ex in exList) {
            final label = ExerciseLabelResolver.label(ex);
            final key = 'Силовая: $label';
            grouped.putIfAbsent(key, () => []).add(w);
          }
        }
      } else {
        final key = w.activityType.toUpperCase();
        grouped.putIfAbsent(key, () => []).add(w);
      }
    }

    return grouped;
  }
}
