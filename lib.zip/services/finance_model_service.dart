class FinanceModelService {
  final int months;
  final double proPrice;
  final double elitePrice;
  final double monthlyExpenses;

  // Симуляция роста аудитории
  final int initialPro;
  final int initialElite;
  final double growthRate; // e.g. 1.5 = +50%/мес

  FinanceModelService({
    this.months = 12,
    this.proPrice = 4.99,
    this.elitePrice = 9.99,
    this.monthlyExpenses = 115.0,
    this.initialPro = 20,
    this.initialElite = 5,
    this.growthRate = 1.5,
  });

  List<FinanceMonthReport> generatePlan() {
    List<FinanceMonthReport> report = [];
    int pro = initialPro;
    int elite = initialElite;

    for (int i = 1; i <= months; i++) {
      double revenue = pro * proPrice + elite * elitePrice;
      double profit = revenue - monthlyExpenses;
      report.add(FinanceMonthReport(
        month: i,
        proUsers: pro,
        eliteUsers: elite,
        revenue: revenue,
        expenses: monthlyExpenses,
        profit: profit,
      ));
      pro = (pro * growthRate).round();
      elite = (elite * growthRate).round();
    }

    return report;
  }

  FinanceSummary generateSummary(List<FinanceMonthReport> report) {
    double totalRevenue = report.fold(0.0, (sum, r) => sum + r.revenue);
    double totalProfit = report.fold(0.0, (sum, r) => sum + r.profit);
    double totalExpenses = report.length * monthlyExpenses;

    double roi = totalExpenses > 0
        ? ((totalProfit - totalExpenses) / totalExpenses) * 100
        : 0.0;

    return FinanceSummary(
      totalRevenue: totalRevenue,
      totalProfit: totalProfit,
      totalExpenses: totalExpenses,
      roiPercent: roi,
      breakevenMonth: report.indexWhere((r) => r.profit >= 0) + 1,
    );
  }
}

class FinanceMonthReport {
  final int month;
  final int proUsers;
  final int eliteUsers;
  final double revenue;
  final double expenses;
  final double profit;

  FinanceMonthReport({
    required this.month,
    required this.proUsers,
    required this.eliteUsers,
    required this.revenue,
    required this.expenses,
    required this.profit,
  });
}

class FinanceSummary {
  final double totalRevenue;
  final double totalProfit;
  final double totalExpenses;
  final double roiPercent;
  final int breakevenMonth;

  FinanceSummary({
    required this.totalRevenue,
    required this.totalProfit,
    required this.totalExpenses,
    required this.roiPercent,
    required this.breakevenMonth,
  });
}
