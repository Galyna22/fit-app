class MockStrengthWorkoutGenerator {
  static final List<List<String>> combos = [
    ['приседания'],
    ['отжимания', 'подтягивания'],
    ['жим лёжа'],
    ['приседания', 'отжимания', 'жим лёжа'],
  ];

  static Future<void> generate({int count = 4}) async {
    final box = Hive.box<WorkoutModel>('workouts');
    final now = DateTime.now();

    for (int i = 0; i < count; i++) {
      final exercises = combos[i % combos.length];
      final workout = WorkoutModel(
        id: const Uuid().v4(),
        date: now.subtract(Duration(days: i)),
        steps: 0,
        distance: 0,
        durationSeconds: 1800 + i * 120,
        calories: 300 + i * 20,
        activityType: 'strength',
        exercises: exercises,
      );
      await box.add(workout);
    }
  }
}
