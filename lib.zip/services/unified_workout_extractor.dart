import 'package:hive/hive.dart';
import 'package:fitness_app/models/unified_workout.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/activity_type.dart';

class UnifiedWorkoutExtractor {
  static List<UnifiedWorkout> extractAll() {
    final List<UnifiedWorkout> result = [];

    // 🧠 Маппер строкового типа → ActivityType
    ActivityType parseActivityType(String raw) {
      switch (raw.toLowerCase()) {
        case 'run':
          return ActivityType.run;
        case 'cycling':
          return ActivityType.cycling;
        case 'strength':
          return ActivityType.strength;
        case 'squats':
          return ActivityType.squats;
        default:
          return ActivityType.strength;
      }
    }

    // 🏃 Бег
    final runBox = Hive.box<RunActivity>('activities');
    for (final run in runBox.values) {
      result.add(UnifiedWorkout(
        date: run.date,
        type: ActivityType.run,
        durationSeconds: run.durationSeconds,
        distanceKm: run.distance,
        avgHeartRate: run.avgHeartRate?.toDouble(),
        tss: null, // пока нет нагрузки для бега
      ));
    }

    // 🚴 Велотренировка
    final cyclingBox = Hive.box<CyclingActivity>('cycling_activities');
    for (final cycling in cyclingBox.values) {
      result.add(UnifiedWorkout(
        date: cycling.date,
        type: ActivityType.cycling,
        durationSeconds: cycling.durationSeconds,
        distanceKm: cycling.distance,
        avgHeartRate: cycling.avgHeartRate?.toDouble(),
        tss: cycling.tss,
      ));
    }

    // 🏋️ Силовая и другие (WorkoutModel)
    final workoutBox = Hive.box<WorkoutModel>('workouts');
    for (final workout in workoutBox.values) {
      result.add(UnifiedWorkout(
        date: workout.date,
        type: parseActivityType(workout.activityType), // ✅ Маппер
        durationSeconds: workout.durationSeconds,
        distanceKm: workout.distanceKm,
        avgHeartRate: workout.avgHeartRate?.toDouble(),
        tss: workout.tss,
      ));
    }

    // 📅 Сортировка ↓
    result.sort((a, b) => b.date.compareTo(a.date));
    return result;
  }
}
