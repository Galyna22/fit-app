class LocationService {
  Stream<List<double>> startTracking();
}
