import 'package:fitness_app/data/workout_model.dart';

class TrainingLoadResult {
  final double ctl;
  final double atl;
  final double tsb;

  TrainingLoadResult({
    required this.ctl,
    required this.atl,
    required this.tsb,
  });
}

class TrainingLoadService {
  // Exponential smoothing constants
  static const ctlFactor = 1 / 42;
  static const atlFactor = 1 / 7;

  static TrainingLoadResult calculate(List<WorkoutModel> workouts) {
    double ctl = 0;
    double atl = 0;

    workouts.sort((a, b) => a.date.compareTo(b.date));

    for (final workout in workouts) {
      final tss = workout.tss ?? 0;
      ctl += ctlFactor * (tss - ctl);
      atl += atlFactor * (tss - atl);
    }

    final tsb = ctl - atl;
    return TrainingLoadResult(ctl: ctl, atl: atl, tsb: tsb);
  }
}
