import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:hive/hive.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_workout.dart';
import 'dart:io' as io;

import 'dart:html' as html; // 👈 нужно только если ты под web

class BackupService {
  final Box<WorkoutModel> workoutBox;
  final Box<CalendarEntry> calendarBox;
  final Box<RunActivity> activityBox;

  BackupService({
    required this.workoutBox,
    required this.calendarBox,
    required this.activityBox,
  });

  Future<void> syncData() async {
    await exportAllDataToJson();
    print('✅ Синхронизация данных завершена');
  }

  Future<void> exportAllDataToJson() async {
    final cyclingBox = Hive.isBoxOpen('cycling_workouts')
        ? Hive.box<CyclingWorkout>('cycling_workouts')
        : await Hive.openBox<CyclingWorkout>('cycling_workouts');

    final backup = {
      'workouts': workoutBox.values
          .whereType<WorkoutModel>()
          .map((e) => e.toJson())
          .toList(),
      'calendar': calendarBox.values
          .whereType<CalendarEntry>()
          .map((e) => e.toJson())
          .toList(),
      'activities': activityBox.values
          .whereType<RunActivity>()
          .map((e) => e.toJson())
          .toList(),
      'cyclingWorkouts': cyclingBox.values
          .whereType<CyclingWorkout>()
          .map((e) => e.toJson())
          .toList(),
    };

    final jsonString = const JsonEncoder.withIndent('  ').convert(backup);
    final timestamp =
        DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final filename = 'fitness_backup_$timestamp.json';

    if (kIsWeb) {
      final blob = html.Blob([jsonString], 'application/json');
      final url = html.Url.createObjectUrlFromBlob(blob);
      html.AnchorElement(href: url)
        ..setAttribute('download', filename)
        ..click();
      html.Url.revokeObjectUrl(url);
    } else {
      final dir = await io.Directory.systemTemp.createTemp();
      final file = io.File('${dir.path}/$filename');
      await file.writeAsString(jsonString);
      print('✅ Сохранено в файл: ${file.path}');
    }
  }

  Future<void> importAllDataFromJson(String jsonString) async {
    final data = jsonDecode(jsonString) as Map<String, dynamic>;

    final activityList = data['activities'] as List<dynamic>? ?? [];
    for (var item in activityList) {
      final activity = RunActivity.fromJson(item as Map<String, dynamic>);
      await activityBox.put(activity.id, activity);
    }

    final cyclingBox = Hive.isBoxOpen('cycling_workouts')
        ? Hive.box<CyclingWorkout>('cycling_workouts')
        : await Hive.openBox<CyclingWorkout>('cycling_workouts');

    final cyclingList = data['cyclingWorkouts'] as List<dynamic>? ?? [];
    for (var item in cyclingList) {
      final workout = CyclingWorkout.fromJson(item as Map<String, dynamic>);
      await cyclingBox.put(workout.id, workout);
    }

    final workoutList = data['workouts'] as List<dynamic>? ?? [];
    for (var item in workoutList) {
      final workout = WorkoutModel.fromJson(item as Map<String, dynamic>);
      await workoutBox.put(workout.id, workout);
    }

    final calendarList = data['calendar'] as List<dynamic>? ?? [];
    for (var item in calendarList) {
      final entry = CalendarEntry.fromJson(item as Map<String, dynamic>);
      final dateKey = entry.date.toIso8601String();
      await calendarBox.put(dateKey, entry);
    }

    print(
        '✅ Импорт завершён: ${activityList.length} беговых, ${cyclingList.length} вело');
  }
}
