class FakeHeartRateProvider implements HeartRateProvider {
  @override
  Stream<int> getStream() => Stream.periodic(
        const Duration(seconds: 5),
        (_) => 120 + Random().nextInt(40) - 10,
      );
}
