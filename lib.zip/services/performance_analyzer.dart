class PerformanceMetrics {
  final double avgPower;
  final double normalizedPower;
  final double intensityFactor;
  final double tss;

  PerformanceMetrics({
    required this.avgPower,
    required this.normalizedPower,
    required this.intensityFactor,
    required this.tss,
  });
}

class PerformanceAnalyzer {
  static PerformanceMetrics compute({
    required double speedKmh,
    required int durationSeconds,
    required double ftpWatts,
  }) {
    final avgPower = speedKmh * 8.0;
    final normalizedPower = speedKmh * 9.5;
    final intensityFactor = normalizedPower / ftpWatts;
    final tss = (durationSeconds * normalizedPower * intensityFactor) /
        (ftpWatts * 3600) *
        100;

    return PerformanceMetrics(
      avgPower: avgPower,
      normalizedPower: normalizedPower,
      intensityFactor: intensityFactor,
      tss: tss,
    );
  }
}
