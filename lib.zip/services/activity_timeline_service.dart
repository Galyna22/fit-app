class ActivityTimelineService {
  final Box<WorkoutModel> workoutBox;
  final Box<RunActivity> activityBox;
  final Box<CyclingActivity> cyclingBox;
  final Box<CalendarEntry> calendarBox;

  ActivityTimelineService({
    required this.workoutBox,
    required this.activityBox,
    required this.cyclingBox,
    required this.calendarBox,
  });

  Future<void> importAllToCalendar() async {
    final timeline = <CalendarEntry>{};

    // Сбор всех источников
    final workouts = workoutBox.values;
    final runs = activityBox.values;
    final bikes = cyclingBox.values;

    // Комбинируем все активности
    for (var w in workouts) {
      timeline.add(_toCalendar(w.date, w.calories, w.steps));
    }
    for (var r in runs) {
      timeline.add(_toCalendar(r.date, r.calories, r.steps));
    }
    for (var b in bikes) {
      timeline.add(_toCalendar(b.date, b.calories, b.steps));
    }

    // Запись в календарь
    for (var entry in timeline) {
      final key = entry.date.toIso8601String();
      calendarBox.put(key, entry);
    }
  }

  CalendarEntry _toCalendar(DateTime date, int calories, int steps) {
    return CalendarEntry(
      date: DateTime(date.year, date.month, date.day),
      calories: calories,
      steps: steps,
      heartRate: 0,
      notes: "Импортировано из активности",
      tags: [],
    );
  }
}
