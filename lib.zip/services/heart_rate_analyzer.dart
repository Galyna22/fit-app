import 'dart:math';

class HeartRateZoneStat {
  final String name;
  final int seconds;
  final double percent;

  HeartRateZoneStat({
    required this.name,
    required this.seconds,
    required this.percent,
  });
}

class HeartRateAnalysis {
  final int avg;
  final int min;
  final int max;
  final List<HeartRateZoneStat> zones;
  final int? hrv; // ✅ добавлено
  final int? recovery; // ✅ добавлено

  HeartRateAnalysis({
    required this.avg,
    required this.min,
    required this.max,
    required this.zones,
    this.hrv,
    this.recovery,
  });
}

HeartRateAnalysis analyzeHeartRate({
  required List<int> data,
  int maxHR = 190,
  int sampleRateSec = 5,
}) {
  if (data.isEmpty) {
    return HeartRateAnalysis(
      avg: 0,
      min: 0,
      max: 0,
      zones: List.generate(
          5,
          (i) => HeartRateZoneStat(
                name: 'Zone ${i + 1}',
                seconds: 0,
                percent: 0.0,
              )),
    );
  }

  final avg = data.reduce((a, b) => a + b) ~/ data.length;
  final minValue = data.reduce(min);
  final maxValue = data.reduce(max);

  final zoneCounters = <String, int>{
    'Zone 1': 0,
    'Zone 2': 0,
    'Zone 3': 0,
    'Zone 4': 0,
    'Zone 5': 0,
  };

  for (final bpm in data) {
    final percent = bpm / maxHR;
    if (percent < 0.6) {
      zoneCounters['Zone 1'] = zoneCounters['Zone 1']! + 1;
    } else if (percent < 0.7) {
      zoneCounters['Zone 2'] = zoneCounters['Zone 2']! + 1;
    } else if (percent < 0.8) {
      zoneCounters['Zone 3'] = zoneCounters['Zone 3']! + 1;
    } else if (percent < 0.9) {
      zoneCounters['Zone 4'] = zoneCounters['Zone 4']! + 1;
    } else {
      zoneCounters['Zone 5'] = zoneCounters['Zone 5']! + 1;
    }
  }

  final totalSamples = data.length;
  final zones = zoneCounters.entries.map((e) {
    final seconds = e.value * sampleRateSec;
    final percent = (e.value / totalSamples) * 100;
    return HeartRateZoneStat(
      name: e.key,
      seconds: seconds,
      percent: percent,
    );
  }).toList();

  return HeartRateAnalysis(
    avg: avg,
    min: minValue,
    max: maxValue,
    zones: zones,
  );
}
