import 'heart_rate_provider.dart';

class HeartRateProviderManager {
  static Future<HeartRateProvider> selectProvider() async {
    // TODO: добавить BLE или телефон позже
    return FakeHeartRateProvider();
  }
}
