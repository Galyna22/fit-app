class BoxDebugPanel extends StatelessWidget {
  const BoxDebugPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final boxNames = [
      'workouts',
      'calendar',
      'activities',
      'cycling_activities',
      'strength_workouts',
      'settings',
    ].where((name) => Hive.isBoxOpen(name)).toList();

    return ListView.builder(
      itemCount: boxNames.length,
      itemBuilder: (_, i) {
        final name = boxNames[i];
        final box = Hive.box(name);
        return ListTile(
          title: Text(name),
          subtitle: Text('📦 ${box.length} записей | тип: ${box.runtimeType}'),
        );
      },
    );
  }
}
