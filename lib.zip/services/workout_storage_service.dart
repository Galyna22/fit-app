import 'package:fitness_app/models/workout_model.dart';
import 'package:fitness_app/services/hive_box_loader.dart';

class WorkoutStorageService {
  final HiveBoxLoader<WorkoutModel> activeBox =
      HiveBoxLoader<WorkoutModel>('workouts_active');

  final HiveBoxLoader<WorkoutModel> archiveBox =
      HiveBoxLoader<WorkoutModel>('workouts_archive');

  Future<void> saveWorkout(WorkoutModel workout) async {
    final box = isRecent(workout.date) ? activeBox : archiveBox;
    await box.put(workout.id, workout);
  }

  Future<WorkoutModel?> getWorkout(String id) async {
    return (await activeBox.get(id)) ?? (await archiveBox.get(id));
  }

  Future<List<WorkoutModel>> getAllWorkouts() async {
    final active = await activeBox.getAllValues();
    final archived = await archiveBox.getAllValues();
    return [...active, ...archived];
  }

  bool isRecent(DateTime date) {
    final now = DateTime.now();
    final oneYearAgo = DateTime(now.year - 1, now.month, now.day);
    return date.isAfter(oneYearAgo);
  }
}
