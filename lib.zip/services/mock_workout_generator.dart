import 'dart:math';
import 'package:uuid/uuid.dart';
import 'package:hive/hive.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/services/heart_rate_symulator.dart';

final pulseSeries = generateDailyHeartRateSeries();

class MockWorkoutGenerator {
  static Future<void> generate({int count = 7}) async {
    final box = Hive.box<WorkoutModel>('workouts');
    final now = DateTime.now();
    final rng = Random();

    for (int i = 0; i < count; i++) {
      final day = now.subtract(Duration(days: i));
      final duration = 1800 + rng.nextInt(600); // от 30 до 40 мин
      final tss = 40.0 + rng.nextInt(40); // от 40 до 80
      final ftp = 230.0;
      final avgPower = 180.0 + rng.nextDouble() * 20;
      final normalizedPower = avgPower + 10.0;
      final intensity = normalizedPower / ftp;

      final activityType = i % 3 == 0
          ? 'strength'
          : i % 2 == 0
              ? 'run'
              : 'cycling';
      final List<List<String>> combos = [
        ['приседания'],
        ['отжимания'],
        ['подтягивания'],
        ['жим лёжа'],
      ];

      final isStrength = activityType == 'strength';
      final exercises = isStrength ? combos[i % combos.length] : null;
      final workout = WorkoutModel(
        id: const Uuid().v4(),
        date: day,
        activityType: activityType,
        steps: activityType == 'run' ? 4500 + rng.nextInt(3000) : 0,
        distance: activityType == 'cycling' ? 20.0 + i : 5.0 + i,
        durationSeconds: duration,
        calories: (duration * 0.13).round(),
        avgHeartRate: 120 + rng.nextInt(25),
        maxHeartRate: 145 + rng.nextInt(20),
        cadenceSpm: activityType == 'cycling' ? 90 : null,
        vo2Max: activityType != 'strength' ? 45.0 + rng.nextDouble() * 5 : null,
        hrv: 60 + rng.nextInt(20),
        spo2: (97 + rng.nextInt(3)).toDouble(),
        stressLevel: 1 + rng.nextInt(4),
        ftp: ftp.round(),
        avgPower: avgPower.round(),
        normalizedPower: normalizedPower.round(),
        tss: tss,
        ctl: null,
        atl: null,
        tsb: null,
        pulseSeries:
            List.generate(duration ~/ 10, (_) => 120 + rng.nextInt(30)),
        gpsTrack: activityType != 'strength'
            ? List.generate(
                20 + i, (_) => [50 + rng.nextDouble(), 30 + rng.nextDouble()])
            : null,
        exercises: exercises,
      );

      await box.add(workout);
    }
  }
}
