import 'package:fitness_app/data/workout_model.dart';

class UnifiedActivityService {
  static Map<String, List<WorkoutModel>> groupByType(List<WorkoutModel> all) {
    final Map<String, List<WorkoutModel>> result = {};

    for (final w in all) {
      final type = w.activityType.toLowerCase();
      result[type] = (result[type] ?? [])..add(w);
    }

    return result;
  }

  static double getTotalDuration(List<WorkoutModel> list) {
    return list.fold(0.0, (sum, w) => sum + w.durationSeconds / 60.0);
  }

  static double getAvgHeartRate(List<WorkoutModel> list) {
    final valid = list.where((w) => w.avgHeartRate != null).toList();
    if (valid.isEmpty) return 0.0;

    final total = valid.fold(0, (sum, w) => sum + w.avgHeartRate!);
    return total / valid.length;
  }

  static double getAvgTSS(List<WorkoutModel> list) {
    final valid = list.where((w) => w.tss != null).toList();
    if (valid.isEmpty) return 0.0;

    final total = valid.fold(0.0, (sum, w) => sum + w.tss!);
    return total / valid.length;
  }

  static Map<String, dynamic> getStatsForType(
    List<WorkoutModel> all,
    String activityType,
  ) {
    final filtered =
        all.where((w) => w.activityType.toLowerCase() == activityType).toList();

    return {
      'count': filtered.length,
      'totalMinutes': getTotalDuration(filtered),
      'avgHR': getAvgHeartRate(filtered),
      'avgTSS': getAvgTSS(filtered),
    };
  }
}
