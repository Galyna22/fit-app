import 'package:fitness_app/data/database_helper.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/activity_type.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/models/gps_point.dart';

class DevSnapshotService {
  static Future<void> load(DatabaseHelper dbHelper) async {
    final now = DateTime.now();

    final strength = StrengthWorkout(
      date: now,
      exercise: 'Гантели: жим стоя',
      sets: 3,
      repsPlanned: 10,
      repsActual: 9,
      weight: 24.0,
      heartRate: 102,
      durationSeconds: 850,
      pulseSeries: [88, 90, 92, 95, 97, 100, 98],
      maxHeartRate: 112,
      avgHeartRate: 96,
      restBetweenSetsSec: 60,
      notes: 'На последнем подходе тяжело',
      hrv: 48,
    );

    final workout = WorkoutModel(
      id: 'dev-session-strength',
      date: now,
      steps: 5200,
      calories: 390,
      distance: 1.2,
      durationSeconds: 850,
      heartRate: 102,
      type: 'strength',
    );

    final run = RunActivity(
      date: now.subtract(const Duration(days: 1)),
      steps: 4800,
      distance: 3.8,
      durationSeconds: 1700,
      caloriesBurned: 315,
      avgHeartRate: 106,
      maxHeartRate: 134,
      heartRateZones: {'zone1': 250, 'zone2': 900},
      paceMinPerKm: 6.2,
      avgSpeed: 9.5,
      maxSpeed: 11.2,
      cadenceSpm: 160,
      strideLength: 1.2,
      elevationGain: 12.5,
      elevationLoss: 11.4,
      gpsTrack: [
        GpsPoint(
            lat: 50.0,
            lng: 30.0,
            timestamp: now.subtract(const Duration(seconds: 1700))),
        GpsPoint(
            lat: 50.0002,
            lng: 30.0003,
            timestamp: now.subtract(const Duration(seconds: 1600))),
      ],
      groundContactTime: 280,
      verticalOscillation: 7.2,
      vo2Max: 45.3,
      recoveryTime: 18,
      trainingLoad: 37.5,
      strideSymmetry: 49.7,
      temperature: 20.3,
      stressLevel: 3.5,
      spo2: 98.1,
      type: ActivityType.run,
    );

    final ride = CyclingActivity(
      date: now.subtract(const Duration(days: 2)),
      durationSeconds: 2400,
      distance: 6.8,
      avgSpeed: 14.2,
      maxSpeed: 21.5,
      calories: 275.4,
      avgHeartRate: 97,
      maxHeartRate: 122,
      pulseSeries: [92, 94, 96, 99],
      heartRateZones: {'zone1': 1200, 'zone2': 800},
      gpsTrack: [
        GpsPoint(
            lat: 50.0,
            lng: 30.0,
            timestamp: now.subtract(const Duration(seconds: 2400))),
        GpsPoint(
            lat: 50.0005,
            lng: 30.0004,
            timestamp: now.subtract(const Duration(seconds: 2300))),
      ],
      vo2Max: 47.1,
      hrv: 54.0,
      recoveryHeartRate: 58,
      ftp: 230.0,
      avgPower: 210.0,
      normalizedPower: 228.0,
      intensityFactor: 0.88,
      tss: 45.5,
      type: ActivityType.cycling,
    );

    await dbHelper.saveWorkout(workout);
    await dbHelper.saveStrengthWorkout(strength);
    await dbHelper.saveActivity(run);
    await dbHelper.saveCyclingActivity(ride);

    print('✅ DevSnapshotService: все мок-данные сохранены');
  }
}
