import 'dart:convert';
import 'package:hive/hive.dart';

@HiveType(typeId: 3)
class SleepData {
  final DateTime date;

  final List<SleepPhase> phases;

  final int totalSleepMinutes;

  SleepData({
    required this.date,
    required this.phases,
    required this.totalSleepMinutes,
  });

  factory SleepData.fromJson(Map<String, dynamic> json) {
    List<SleepPhase> parsedPhases = (json['sleepPhases'] as List)
        .map((phase) => SleepPhase.fromJson(phase))
        .toList();

    return SleepData(
      date: DateTime.parse(json['date']),
      phases: parsedPhases,
      totalSleepMinutes: json['totalSleepMinutes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'date': date.toIso8601String(),
      'sleepPhases': phases.map((phase) => phase.toJson()).toList(),
      'totalSleepMinutes': totalSleepMinutes,
    };
  }
}

class SleepPhase {
  final String phaseType; // deep, light, REM

  final DateTime startTime;

  final DateTime endTime;

  final int durationMinutes;

  SleepPhase({
    required this.phaseType,
    required this.startTime,
    required this.endTime,
    required this.durationMinutes,
  });

  factory SleepPhase.fromJson(Map<String, dynamic> json) {
    return SleepPhase(
      phaseType: json['phase'],
      startTime: DateTime.parse(json['startTime']),
      endTime: DateTime.parse(json['endTime']),
      durationMinutes: json['durationMinutes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'phase': phaseType,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'durationMinutes': durationMinutes,
    };
  }
}

class SleepDataService {
  final Box<SleepData> sleepBox;

  SleepDataService({required this.sleepBox});

  Future<void> saveSleepData(String jsonString) async {
    Map<String, dynamic> sleepData = jsonDecode(jsonString);
    SleepData parsedData = SleepData.fromJson(sleepData);
    await sleepBox.put(parsedData.date.toIso8601String(), parsedData);
  }

  List<SleepData> getSleepHistory() {
    return sleepBox.values.toList();
  }

  double calculateDeepSleepPercentage(SleepData data) {
    int deepSleepMinutes = data.phases
        .where((phase) => phase.phaseType == 'deep')
        .fold(0, (sum, phase) => sum + phase.durationMinutes);

    return (deepSleepMinutes / data.totalSleepMinutes) * 100;
  }
}
