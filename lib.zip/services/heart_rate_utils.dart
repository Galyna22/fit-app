// lib/services/heart_rate_utils.dart

Map<String, int> computeHeartRateZones({
  required List<int> heartRates,
  required int maxHR,
}) {
  Map<String, int> zones = {
    'Zone 1': 0,
    'Zone 2': 0,
    'Zone 3': 0,
    'Zone 4': 0,
    'Zone 5': 0,
  };

  for (var bpm in heartRates) {
    final percent = bpm / maxHR;
    if (percent < 0.6) {
      zones['Zone 1'] = zones['Zone 1']! + 1;
    } else if (percent < 0.7) {
      zones['Zone 2'] = zones['Zone 2']! + 1;
    } else if (percent < 0.8) {
      zones['Zone 3'] = zones['Zone 3']! + 1;
    } else if (percent < 0.9) {
      zones['Zone 4'] = zones['Zone 4']! + 1;
    } else {
      zones['Zone 5'] = zones['Zone 5']! + 1;
    }
  }

  return zones;
}
