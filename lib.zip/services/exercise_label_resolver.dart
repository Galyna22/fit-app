class ExerciseLabelResolver {
  static String label(String raw) {
    final normalized = raw.toLowerCase().trim();
    if (normalized.contains('присед')) return 'Приседания 🦵';
    if (normalized.contains('отжим')) return 'Отжимания 💪';
    if (normalized.contains('жим')) return 'Жим лёжа 🏋️';
    if (normalized.contains('подтяг')) return 'Подтягивания 🧗';
    return raw;
  }
}
