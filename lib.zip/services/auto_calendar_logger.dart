import 'package:hive/hive.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/activity_type.dart';

class AutoCalendarLogger {
  final Box<CalendarEntry> calendarBox;

  AutoCalendarLogger(this.calendarBox);

  Future<void> log(dynamic activity) async {
    final entry = _mapToCalendarEntry(activity);
    if (entry == null) return;

    final key = DateTime(entry.date.year, entry.date.month, entry.date.day)
        .toIso8601String();
    final existing = calendarBox.get(key);

    final merged = CalendarEntry(
      date: entry.date,
      steps: (existing?.steps ?? 0) + entry.steps,
      calories: (existing?.calories ?? 0) + entry.calories,
      heartRate: (existing?.heartRate ?? 0) + entry.heartRate,
      notes: [
        if (existing?.notes?.isNotEmpty ?? false) existing!.notes!,
        if (entry.notes?.isNotEmpty ?? false) entry.notes!,
      ].join('\n'),
      tags: <String>{
        ...?existing?.tags,
        ...?entry.tags,
      }.toList(),
    );

    await calendarBox.put(key, merged);
  }

  CalendarEntry? _mapToCalendarEntry(dynamic activity) {
    if (activity is RunActivity) {
      return CalendarEntry(
        date: activity.date,
        steps: activity.steps,
        calories: activity.caloriesBurned.toInt(),
        heartRate: activity.avgHeartRate.toInt(),
        notes: 'Бег: ${activity.distance.toStringAsFixed(1)} км',
        tags: ['run'],
      );
    }

    if (activity is CyclingActivity) {
      return CalendarEntry(
        date: activity.date,
        steps: 0,
        calories: activity.calories.toInt(), // ⚠️ corrected
        heartRate: activity.avgHeartRate.toInt(),
        notes: 'Вело: ${activity.distance.toStringAsFixed(1)} км',
        tags: ['cycling'],
      );
    }

    if (activity is StrengthWorkout) {
      return CalendarEntry(
        date: activity.date,
        steps: 0,
        calories: 0,
        heartRate: activity.avgHeartRate ?? activity.heartRate,
        notes:
            'Силовая: ${activity.exercise} ${activity.sets}×${activity.repsActual} @ ${activity.weight} кг',
        tags: ['strength'],
      );
    }

    if (activity is WorkoutModel) {
      final type = ActivityType.values.firstWhere(
        (t) => t.name == activity.activityType.toLowerCase(),
        orElse: () => ActivityType.strength,
      );
      return CalendarEntry(
        date: activity.date,
        steps: activity.steps,
        calories: activity.calories,
        heartRate: (activity.avgHeartRate ?? 0).round(),
        notes:
            '${type.displayName}: ${activity.distanceKm.toStringAsFixed(1)} км',
        tags: [type.name],
      );
    }

    return null;
  }
}
