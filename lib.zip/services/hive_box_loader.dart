import 'package:hive/hive.dart';

class HiveBoxLoader<T> {
  final String name;
  Box<T>? _box;

  HiveBoxLoader(this.name);

  Future<Box<T>> getBox() async {
    if (_box != null) return _box!;
    if (!Hive.isBoxOpen(name)) {
      _box = await Hive.openBox<T>(name);
    } else {
      final box = Hive.box(name);
      if (box is! Box<T>) {
        throw HiveError(
            '❌ Бокс "$name" не соответствует типу Box<$T>. Получено: ${box.runtimeType}');
      }
      _box = box;
    }
    return _box!;
  }

  Future<T?> get(dynamic key) async => (await getBox()).get(key);
  Future<void> put(dynamic key, T value) async =>
      (await getBox()).put(key, value);
  Future<void> delete(dynamic key) async => (await getBox()).delete(key);
  Future<void> clear() async => (await getBox()).clear();
  Future<List<T>> getAllValues() async => (await getBox()).values.toList();
  int get length => _box?.length ?? 0;
}
