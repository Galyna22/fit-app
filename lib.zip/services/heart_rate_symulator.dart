import 'dart:math';

List<int> generateDailyHeartRateSeries({
  DateTime? date,
  Duration interval = const Duration(minutes: 5),
}) {
  final now = date ?? DateTime.now();
  final start = DateTime(now.year, now.month, now.day);
  final end = start.add(const Duration(days: 1));
  final rng = Random();

  final List<int> series = [];
  DateTime t = start;

  while (t.isBefore(end)) {
    final hour = t.hour;
    int min = 50;
    int max = 60;

    if (hour >= 0 && hour < 6) {
      min = 45;
      max = 55;
    } else if (hour < 8) {
      min = 55;
      max = 70;
    } else if (hour < 12) {
      min = 65;
      max = 85;
    } else if (hour < 13) {
      min = 60;
      max = 75;
    } else if (hour < 17) {
      min = 65;
      max = 85;
    } else if (hour < 18) {
      min = 120;
      max = 170;
    } else if (hour < 21) {
      min = 65;
      max = 90;
    } else {
      min = 50;
      max = 65;
    }

    final hr = min + rng.nextInt(max - min + 1);
    series.add(hr);
    t = t.add(interval);
  }

  return series;
}
