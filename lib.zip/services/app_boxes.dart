import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/strength_workout.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/calendar_entry.dart';

class AppBoxes {
  static late Box<WorkoutModel> _workoutBox;
  static late Box<CalendarEntry> _calendarBox;
  static late Box<RunActivity> _activityBox;
  static late Box<CyclingActivity> _cyclingActivityBox;
  static late Box<StrengthWorkout> _strengthWorkoutBox;
  static late Box _settingsBox;
  static late String _userId;

  static Future<void> ensureAllBoxesOpened() async {
    final boxFutures = <Future<void>>[];

    if (!Hive.isBoxOpen('workouts')) {
      boxFutures.add(Hive.openBox<WorkoutModel>('workouts').then((box) {
        _workoutBox = box;
        print('📦 workouts открылся');
      }));
    } else {
      _workoutBox = Hive.box<WorkoutModel>('workouts');
      print('📦 workouts уже открыт');
    }

    if (!Hive.isBoxOpen('calendar')) {
      boxFutures.add(Hive.openBox<CalendarEntry>('calendar').then((box) {
        _calendarBox = box;
        print('📅 calendar открылся');
      }));
    } else {
      _calendarBox = Hive.box<CalendarEntry>('calendar');
      print('📅 calendar уже открыт');
    }

    if (!Hive.isBoxOpen('activities')) {
      boxFutures.add(Hive.openBox<RunActivity>('activities').then((box) {
        _activityBox = box;
        print('🏃 activities открылся');
      }));
    } else {
      _activityBox = Hive.box<RunActivity>('activities');
      print('🏃 activities уже открыт');
    }

    if (!Hive.isBoxOpen('cycling_activities')) {
      boxFutures
          .add(Hive.openBox<CyclingActivity>('cycling_activities').then((box) {
        _cyclingActivityBox = box;
        print('🚴‍♂️ cycling_activities открылся');
      }));
    } else {
      _cyclingActivityBox = Hive.box<CyclingActivity>('cycling_activities');
      print('🚴‍♂️ cycling_activities уже открыт');
    }

    if (!Hive.isBoxOpen('strength_workouts')) {
      boxFutures
          .add(Hive.openBox<StrengthWorkout>('strength_workouts').then((box) {
        _strengthWorkoutBox = box;
        print('🏋️ strength_workouts открылся');
      }));
    } else {
      _strengthWorkoutBox = Hive.box<StrengthWorkout>('strength_workouts');
      print('🏋️ strength_workouts уже открыт');
    }

    await Future.wait(boxFutures);

    if (!Hive.isBoxOpen('settings')) {
      _settingsBox = await Hive.openBox('settings');
      print('⚙️ settings открылся');
    } else {
      _settingsBox = Hive.box('settings');
      print('⚙️ settings уже открыт');
    }

    _userId = _settingsBox.get('userId') ?? Uuid().v4();
    await _settingsBox.put('userId', _userId);
    print('🆔 userId: $_userId');
  }

  static Box<WorkoutModel> get workoutBox => _workoutBox;
  static Box<CalendarEntry> get calendarBox => _calendarBox;
  static Box<RunActivity> get activityBox => _activityBox;
  static Box<CyclingActivity> get cyclingActivityBox => _cyclingActivityBox;
  static Box<StrengthWorkout> get strengthWorkoutBox => _strengthWorkoutBox;
  static Box get settingsBox => _settingsBox;
  static String get userId => _userId;
}
