import 'package:fitness_app/data/workout_model.dart';

class WeeklyExerciseStatsService {
  static Map<String, Map<String, int>> groupByWeek(
      List<WorkoutModel> workouts) {
    final Map<String, Map<String, int>> weeklyStats = {};

    for (final w in workouts) {
      if (w.activityType != 'strength') continue;

      final weekStart = getWeekStart(w.date);
      final weekLabel =
          '${weekStart.year}-${weekStart.month.toString().padLeft(2, '0')}-${weekStart.day.toString().padLeft(2, '0')}';

      final exercises = w.exercises ?? ['не указано'];
      final weekMap = weeklyStats.putIfAbsent(weekLabel, () => {});

      for (final ex in exercises) {
        weekMap.update(ex, (count) => count + 1, ifAbsent: () => 1);
      }
    }

    return weeklyStats;
  }

  static DateTime getWeekStart(DateTime date) =>
      date.subtract(Duration(days: date.weekday - 1));
}
