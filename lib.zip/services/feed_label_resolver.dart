import 'package:fitness_app/data/workout_model.dart';

class FeedLabelResolver {
  static String label(WorkoutModel w) {
    if (w.activityType == 'strength') {
      final raw = w.exercises?.join(' + ') ?? 'не указано';
      return 'Strength – $raw';
    }
    return w.activityType.toUpperCase();
  }
}