void registerAllAdapters() {
  Hive
    ..registerAdapter(RunActivityAdapter())
    ..registerAdapter(CyclingActivityAdapter())
    ..registerAdapter(WorkoutModelAdapter())
    ..registerAdapter(StrengthWorkoutAdapter());
}
