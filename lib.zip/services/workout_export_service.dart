class WorkoutExportService {
  static String exportExercise(CustomExerciseModel ex) =>
      jsonEncode(ex.toMap());

  static String exportAllExercises(List<CustomExerciseModel> list) =>
      jsonEncode(list.map((e) => e.toMap()).toList());
}
