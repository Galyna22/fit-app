import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:fitness_app/data/workout_model.dart';

class WorkoutLogger {
  static Future<void> logWorkout(Workout workout) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/workout_log.txt');

    final logEntry = '''
==== Workout: ${workout.id} ====
📅 Date: ${workout.date}
🚶‍♂️ Steps: ${workout.steps}
🔥 Calories: ${workout.calories}
❤️ Avg HR: ${workout.avgHeartRate}
📏 Distance: ${workout.distance} м
🕒 Duration: ${workout.durationSeconds} сек
===============================
''';

    await file.writeAsString(logEntry, mode: FileMode.append);
  }
}