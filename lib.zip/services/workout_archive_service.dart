import 'dart:convert';
import 'dart:io';
import 'package:fitness_app/models/workout_model.dart';
import 'package:hive/hive.dart';

class WorkoutArchiveService {
  Future<void> exportToArchive(Box<WorkoutModel> sourceBox) async {
    final now = DateTime.now();
    final threshold = DateTime(now.year - 3); // старше 3 лет

    final archive = <String, dynamic>{};

    for (final entry in sourceBox.toMap().entries) {
      final workout = entry.value;
      if (workout.date.isBefore(threshold)) {
        archive[entry.key] =
            workout.toJson(); // предполагаем, что есть toJson()
      }
    }

    final timestamp = now.toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final file = File('hive_archive_$timestamp.json');
    final json = const JsonEncoder.withIndent('  ').convert(archive);
    await file.writeAsString(json);

    print('📁 Архив экспортирован: ${file.path}');
  }
}
