import 'package:hive/hive.dart';

// 📦 Модели
import 'package:fitness_app/data/workout_model.dart';
import 'package:fitness_app/data/run_activity.dart';
import 'package:fitness_app/data/cycling_activity.dart';
import 'package:fitness_app/data/calendar_entry.dart';
import 'package:fitness_app/data/strength_workout.dart';

// 📊 Диагностика
import 'package:fitness_app/debug/box_access_tracker.dart';

class BoxManager {
  static const workouts = 'workouts';
  static const calendar = 'calendar';
  static const activities = 'activities';
  static const cycling = 'cycling_activities';
  static const strength = 'strength_workouts';
  static const settings = 'settings';
  static const allBoxNames = [
    workouts,
    activities,
    calendar,
    cycling,
    strength,
    settings,
  ];

  /// 💡 Открытие только нужных боксов
  static Future<void> openOnly(List<String> boxNames) async {
    for (final name in boxNames) {
      switch (name) {
        case workouts:
          await BoxAccessTracker.openBox<WorkoutModel>(workouts);
          break;
        case activities:
          await BoxAccessTracker.openBox<RunActivity>(activities);
          break;
        case cycling:
          await BoxAccessTracker.openBox<CyclingActivity>(cycling);
          break;
        case calendar:
          await BoxAccessTracker.openBox<CalendarEntry>(calendar);
          break;
        case strength:
          await BoxAccessTracker.openBox<StrengthWorkout>(strength);
          break;
        case settings:
          await BoxAccessTracker.openBox<dynamic>(settings);
          break;
        default:
          print('⚠️ BoxManager: неизвестный бокс "$name"');
      }
    }
  }

  /// 🔁 Полное открытие (если всё нужно)
  static Future<void> openAll() async {
    await openOnly(
        [workouts, activities, cycling, strength, calendar, settings]);
  }

  /// 📥 Получение типизированного бокса с логами
  static Box<T> get<T>(String name) {
    print('⏱ [BoxManager.get] 🟡 До получения бокса "$name" как Box<$T>');
    final box = Hive.box(name);
    print('⏱ [BoxManager.get] 🟢 Бокс "$name" получен как ${box.runtimeType}');

    if (box is! Box<T>) {
      throw HiveError('❌ "$name" не как Box<$T>. Получено: ${box.runtimeType}');
    }

    return box as Box<T>;
  }
}
