class FakeDataController {
  final bool useFake;

  FakeDataController({required this.useFake});

  double getSimulatedDistance(int gpsPoints) {
    return useFake ? (gpsPoints / 40).clamp(0.2, 50.0) : 0.0;
  }

  int getSimulatedPulse() {
    return useFake ? 125 : 0;
  }

  double getSimulatedSpeed(double distanceKm, int durationSec) {
    return useFake ? distanceKm / (durationSec / 60.0 / 60.0 + 0.1) : 0.0;
  }
}
