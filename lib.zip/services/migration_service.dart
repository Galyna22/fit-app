import 'package:hive/hive.dart';
import 'package:fitness_app/data/run_activity.dart';

class MigrationService {
  static Future<void> migrateToV2(
      Box<RunActivity> newBox, String oldBoxName) async {
    if (!await Hive.boxExists(oldBoxName)) return;

    final oldBox = await Hive.openBox<Map>(oldBoxName);

    for (final oldData in oldBox.values) {
      try {
        final newActivity = _convertActivity(oldData);
        await newBox.put(newActivity.id, newActivity);
      } catch (e) {
        print('Migration error: $e');
      }
    }

    await oldBox.close();
  }

  static Future<bool> needsMigration() async {
    return await Hive.boxExists(
        'old_activities'); // ✅ Проверка наличия старых данных
  }

  static RunActivity _convertActivity(Map oldData) {
    return RunActivity.fromV1({
      'id': oldData['id'],
      'date': oldData['date'],
      'steps': oldData['steps'],
      'distance': oldData['distance'],
      'durationSeconds': oldData['duration'],
      'caloriesBurned': oldData['calories'],
      'avgHeartRate': oldData['avgHeartRate'],
      'maxHeartRate': oldData['maxHeartRate'],
    });
  }
}
