import 'package:flutter/material.dart';

/// Безопасный конструктор маршрутов с автоматическим именованием
Route<T> namedRoute<T>(Widget screen, {String? name}) {
  return MaterialPageRoute<T>(
    builder: (_) => screen,
    settings: RouteSettings(name: name ?? screen.runtimeType.toString()),
  );
}
